<?php

/*

Plugin Name: Quick Order Table

Plugin URI: https://www.qualityhistology.com/

Description: This plugin provides quick order by adding products to this quick order table and direct checkout

Version: 1.00

Author: qualityhistology

Author URI: https://www.qualityhistology.com

Text Domain: quickorder

*/



/**

 * Basic plugin definitions

 *

 * @package Quick Order Table

 * @since 1.00

 **/



if (!defined('QOT_RIC_DIR')) {
    define('QOT_RIC_DIR', dirname(__FILE__));
}

if (!defined('QOT_RIC_VERSION')) {
    define('QOT_RIC_VERSION', '1.00');
}

if (!defined('QOT_RIC_URL')) {
    define('QOT_RIC_URL', plugin_dir_url(__FILE__));
}

if (!defined('QOT_RIC_INC_DIR')) {
    define('QOT_RIC_INC_DIR', QOT_RIC_DIR.'/includes');
}

if (!defined('QOT_RIC_INC_URL')) {
    define('QOT_RIC_INC_URL', QOT_RIC_URL.'includes');
}

if (!defined('QOT_RIC_ADMIN_DIR')) {
    define('QOT_RIC_ADMIN_DIR', QOT_RIC_INC_DIR.'/admin');
}

if (!defined('QOT_RIC_PREFIX')) {
    define('QOT_RIC_PREFIX', 'qot_ric');
}

if (!defined('QOT_RIC_VAR_PREFIX')) {
    define('QOT_RIC_VAR_PREFIX', '_qot_ric_');
}





/**

 * Load Text Domain

 *

 * This gets the plugin ready for translation.

 *

 * @package Quick Order Table

 * @since 1.00

 */

load_plugin_textdomain('quickorder', false, dirname(plugin_basename(__FILE__)) . '/languages/');



/**

 * Activation Hook

 *

 * Register plugin activation hook.

 *

 * @package Quick Order Table

 * @since 1.00

 */

register_activation_hook(__FILE__, 'qot_ric_install');





/**

 * Deactivation Hook

 *

 * Register plugin deactivation hook.

 *

 * @package Quick Order Table

 * @since 1.00

 */

register_deactivation_hook(__FILE__, 'qot_ric_uninstall');





function qot_ric_install()
{

    global $wpdb;



    //if plugin is first time going to activated then set all default options

    $qot_ric_options = get_option('qot_ric_options');



    if (empty($qot_ric_options)) {
        qot_ric_default_settings();
    }
}



/**

 * Plugin Setup (On Deactivation)

 *

 * Does the drop tables in the database and

 * delete  plugin options.

 *

 * @package QRT Settings

 * @since 1.0.0

 */



function qot_ric_uninstall()
{

    global $wpdb;
}



/**

 * Plugin default settings

 *

 * @package QRT Settings & Widget Page

 * @since 1.0.0

 */



function qot_ric_default_settings()
{

    $set_default_fields = qot_ric_default_fields();



    update_option('qot_ric_options', $set_default_fields);
}



function qot_ric_default_sorting_setting()
{

    $set_default_sorting = qot_ric_default_sorting();



    update_option('qot_ric_sorting', $set_default_sorting);
}



/* Default Table's Fields  */

function qot_ric_default_fields()
{

    global $default_fields;



    $default_fields = array(

    array('field' => 'Quick View','label' => esc_html__('Quick View', 'quickorder'),'position'=>'0'),



    array('field' => 'SKU','label' => esc_html__('SKU', 'quickorder'),'position'=>'1'),



    array('field' => 'Product Name', 'label' => esc_html__('Product Name', 'quickorder'),'position'=>'2'),



    array('field' => 'Quantity','label' =>esc_html__('Quantity In Stock', 'quickorder'),'position'=>'3' ),



    array('field' => 'Qty In-Process','label'=> esc_html__('Quantity In-Process', 'quickorder'),'position'=>'4'),



    array('field' => 'Expected Completion Date','label'=> esc_html__('Expected Completion Date', 'quickorder'),'position'=> '5'),



    array('field' => 'Standard Lead Time','label'=> esc_html__('Standard Lead Time', 'quickorder'),'position'=>'6'),



    array('field' => 'Qty to Order','label'=> esc_html__('Qty to Order', 'quickorder'),'position'=>'7'),



    array('field' => 'Unit Price','label'=> esc_html__('Unit Price', 'quickorder'),'position'=>'8'),



    array('field' => 'Total Price','label'=> esc_html__('Total Price', 'quickorder'),'position'=>'9'),



    array('field' => 'Shipping Date','label' => esc_html__('Shipping Date', 'quickorder'),'position'=>'10'),



    array('field' => 'Requested Date','label'=> esc_html__('Requested Date', 'quickorder'),'position'=>'11'),



    array('field' => 'Action','label'=> esc_html__('Action', 'quickorder'),'position'=>'12'));



    return $default_fields;
}



/**

 *

 * Default Table's Sorting - Default position */

function qot_ric_default_sorting()
{

    global $default_sorting;



    $default_sorting = array(

            array('field' => 'quickview','position'=>'0'),

            array('field' => 'sku','position'=>'1'),

            array('field' => 'product_name', 'position'=>'2'),

            array('field' => 'qty_stock','position'=>'3' ),

            array('field' => 'qty_inprocess','position'=>'4'),

            array('field' => 'exp_compl_date', 'quickorder','position'=>'5'),

            array('field' => 'lead_time','position'=>'6'),

            array('field' => 'qty_order','position'=>'7'),

            array('field' => 'unit_price','position'=>'8'),

            array('field' => 'total_price','position'=>'9'),

            array('field' => 'ship_date','position'=>'10'),

            array('field' => 'req_date','position'=>'11'),

            array('field' => 'action','position'=>'12')

        );



    return $default_sorting;
}



/* Load function when plugin activating */

function qot_ric_plugin_loaded()
{

    qot_ric_default_fields();
}



function qot_ric_default_styles_setting()
{

    

    $set_default_styles = array(

        'th_bg_color' =>'#fff',

        'th_text_color' =>'#000',

        'tr_odd_bg_color'  => '#fff',

        'tr_even_bg_color' => '#fff',

        'tbody_text_color' => '#000'

    );



    update_option('qot_ric_styles', $set_default_styles);
}





//add action to load plugin

add_action('plugins_loaded', 'qot_ric_plugin_loaded');

/**

 * Load Plugin

 *

 * Handles to load plugin after

 * dependent plugin is loaded

 * successfully

 *

 * @package QRT Settings

 * @since 1.0.0

 */





// Global variables

global $qot_ric_scripts, $qot_ric_model, $qot_ric_admin, $ric_wp_products, $field;



$field=array('qorder_quickview','qorder_sku','qorder_name','qorder_qty_stock','qorder_qip_stock','qorder_exp_comp_date','qorder_lead_time','qorder_qty_order_html','qorder_unit_price','qorder_total_price','qorder_eship_date','qorder_rship_date_html','action','qorder_qty_order','qorder_rship_date','qorder_id','qorder_did','qorder_qty_consider');



$ric_wp_products = get_posts(array('post_type' => 'product', 'numberposts' => -1, 'post_status' => 'publish', 'fields' => 'all'  ));

// Script class handles most of script functionalities of plugin



// Model class handles most of model functionalities of plugin

include_once(QOT_RIC_INC_DIR.'/class-qot-ric-model.php');

$qot_ric_model = new Qot_Ric_Model();



// Model class handles most of model functionalities of plugin

include_once(QOT_RIC_INC_DIR.'/class-qot-ric-scripts.php');

$qot_ric_scripts = new Qot_Ric_Scripts();

$qot_ric_scripts->add_hooks();



// Functions to manage quick order table
// include_once(QOT_RIC_INC_DIR.'/test.php');
include_once(QOT_RIC_INC_DIR.'/advance-custom-functions.php');
include_once(QOT_RIC_INC_DIR.'/class-qot-ric-functions.php');



include_once(QOT_RIC_INC_DIR.'/class-qot-ric-public.php');

$qot_ric_public = new Qot_Ric_Public();

$qot_ric_public->add_hooks();



// Admin class handles most of admin panel functionalities of plugin

include_once(QOT_RIC_ADMIN_DIR.'/class-qot-ric-admin.php');

$qot_ric_admin = new Qot_Ric_Admin();

$qot_ric_admin->add_hooks();
