<?php



// Exit if accessed directly

if (!defined('ABSPATH')) {

    exit;

}



/**

 * Plugin Model Class

 *

 * Handles generic functionailties

 *

 * @package Quick Order Table

 * @since 1.00

 */



class Qot_Ric_Model

{

    //class constructor

    public function __construct()

    {

    }



    /**

      * Escape Tags & Slashes

      *

      * Handles escapping the slashes and tags

      *

      * @package Quick Order Table

      * @since 1.00

      */



     public function qot_ric_escape_attr($data)

     {

         return esc_attr(stripslashes($data));

     }



     /**

      * Get Saturday Holidays

      *

      *

      * @package Quick Order Table

      * @since 1.00

      */

     public function qot_ric_get_saturday_dates($startDate, $endDate, $weekdayNumber=6)

     {

         $startDate = strtotime($startDate);

         $endDate = strtotime($endDate);



         $saturday_dates = array();



         do {

             if (date("w", $startDate) != $weekdayNumber) {

                 $startDate += (24 * 3600); // add 1 day

             }

         } while (date("w", $startDate) != $weekdayNumber);





         while ($startDate <= $endDate) {

             $saturday_dates[] = date('Y-m-d', $startDate);

             $startDate += (7 * 24 * 3600); // add 7 days

         }



         return $saturday_dates;

     }



     /**

      * Get Sunday Holidays between two dates

      *

      *

      * @package Quick Order Table

      * @since 1.00

      */

     public function qot_ric_get_sunday_dates($startDate, $endDate, $weekdayNumber=0)

     {

         $startDate = strtotime($startDate);

         $endDate = strtotime($endDate);



         $sunday_dates = array();



         do {

             if (date("w", $startDate) != $weekdayNumber) {

                 $startDate += (24 * 3600); // add 1 day

             }

         } while (date("w", $startDate) != $weekdayNumber);





         while ($startDate <= $endDate) {

             $sunday_dates[] = date('Y-m-d', $startDate);

             $startDate += (7 * 24 * 3600); // add 7 days

         }



         return $sunday_dates;

     }



     /**

      * Get Weekend Holidays between two dates

      *

      *

      * @package Quick Order Table

      * @since 1.00

      */

     public function qot_ric_get_weekend_dates($startDate, $endDate)

     {

         $weekend_dates = array();

         $saturday_dates = $this->qot_ric_get_saturday_dates($startDate, $endDate);

         $sunday_dates = $this->qot_ric_get_sunday_dates($startDate, $endDate);



         $weekend_dates = array_merge($saturday_dates, $sunday_dates);

         //print_r($weekend_dates);

         return $weekend_dates;

     }



     /**

      * Get All Holidays 

      *

      *

      * @package Quick Order Table

      * @since 1.00

      */

     public function qot_ric_get_holidays_date()

     {

         $qot_ric_holiday = get_option('qot_ric_holiday');

         $rangeHolidays='';

         $holidays=array();

         if (!empty($qot_ric_holiday)) {

             foreach ($qot_ric_holiday as $holiday) {

                 $start = $holiday['holiday_start_date'];

                 $end = $holiday['holiday_end_date'];





                 if ($start==$end) {

                     $holidays[]=$start;

                 } else {

                     $startdate = new DateTime($start);

                     $enddate = new DateTime($end);

                     $difference = $startdate->diff($enddate);

                     if ($difference->d==1) {

                         $holidays[]=$start;

                         $holidays[]=$end;

                     } else {

                         $rangeHolidays = $this->getDatesFromRange($start, $end);

                     }

                 }

             }

         }

         if ($rangeHolidays) {

             foreach ($rangeHolidays as $rangeHoliday) {

                 $holidays[]=$rangeHoliday;

             }

         }



         //print_r($holidays);

         return $holidays;

     }



     /**

      * Get Dates between range

      *

      *

      * @package Quick Order Table

      * @since 1.00

      */

     public function getDatesFromRange($start, $end, $format = 'Y-m-d')

     {

         $getRange = array();

         $interval = new DateInterval('P1D');



         $realEnd = new DateTime($end);

         $realEnd->add($interval);



         $period = new DatePeriod(new DateTime($start), $interval, $realEnd);



         foreach ($period as $date) {

             $getRange[] = $date->format($format);

         }



         return $getRange;

     }







     /**

       * Stripslashes

       *

       * It will strip slashes from the content

       *

       * @package Quick Order Table

       * @since 1.00

       */



     public function qot_ric_escape_slashes_deep($data = array(), $flag = false)

     {

         if ($flag != true) {

             $data = $this->qot_ric_nohtml_kses($data);

         }

         $data = stripslashes_deep($data);

         return $data;

     }

    /**

     * Strip Html Tags

     *

     * It will sanitize text input (strip html tags, and escape characters)

     *

     * @package Quick Order Table

     * @since 1.00

     */

    public function qot_ric_nohtml_kses($data = array())

    {

        if (is_array($data)) {

            $data = array_map(array($this,'qot_ric_nohtml_kses'), $data);

        } elseif (is_string($data)) {

            $data = wp_filter_nohtml_kses($data);

        }



        return $data;

    }



    /* Get Hidden product ids */

        public function get_hidden_product_id()

    {

           $hide_products = [];

            

            if ( is_user_logged_in() ) {

                

                $hide_products = get_user_meta( get_current_user_id(), 'cvf_hidden_products', true );



            } else {



                $hide_products =    get_option( 'cvf_hidden_products_non_logged_in' );



            }



            $hide_categories = get_user_meta (get_current_user_id(), 'cvf_hidden_categories',true);







            $product_term_args = array(

                'taxonomy' => 'product_cat',

                'include' => $hide_categories,

                'orderby'  => 'include'

            );

            $product_terms = get_terms($product_term_args);



            $product_term_slugs = [];

            foreach ($product_terms as $product_term) {

                $product_term_slugs[] = $product_term->slug;

            }



            $product_args = array(

                'post_status' => 'publish',

                'limit' => -1,

                'category' => $product_term_slugs,

                //more options according to wc_get_products() docs

            );

            $products = wc_get_products($product_args);

            foreach ($products as $product) {

                $product_id = $product->get_id();

                $hide_products[] = $product_id;

            }

            // echo "<pre>";print_r($hide_products);

            foreach ($products as $product) {

                

                $product_id = $product->get_id();

                

                $get_product_type = get_post_meta($product_id,'_virtual', true);

                if($get_product_type == 'yes'){

                    $get_product_status = get_post_meta($product_id,'_stock_status', true);

                    if($get_product_status == 'onbackorder'){

                        $hide_products[] = $product_id;

                    }

                }

                

                

            }



            return $hide_products;

        }

}

