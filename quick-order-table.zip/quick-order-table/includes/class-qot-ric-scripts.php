<?php
// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;

/**
 * Scripts Class
 *
 * Handles adding scripts functionality to the admin pages
 * as well as the front pages.
 *
 * @package Quick Order Table
 * @since 1.00
 */

class Qot_Ric_Scripts {

	public $model;
	//class constructor
	function __construct()
	{
		global $qot_ric_model;

		$this->model = $qot_ric_model;
	}
	
	/**
	 * Enqueue Scripts on Admin Side
	 * 
	 * @package Quick Order Table
	 * @since 1.00
	 */
	public function qot_ric_admin_scripts($hook_suffix){
		global $wp_version;
		
		$hook_suffix_pages	= array( 'toplevel_page_quick-order-settings','quick-order-settings_page_quick-order-styles','quick-order-settings_page_quick-order-holiday-date' );
		wp_register_script( 'qot-admin-script', QOT_RIC_URL.'includes/js/qot-admin-script.js', array(), null, true);
		wp_register_style( 'qot-admin-css', QOT_RIC_URL.'includes/css/qot-admin.css' );
		wp_register_script('qot-sortable-script', QOT_RIC_URL.'includes/js/qot-sortable.js',array('jquery', 'jquery-ui-sortable') , null, true );
    	wp_register_style( 'jquery-ui', QOT_RIC_URL.'includes/css/jquery-ui.css' );
    	wp_enqueue_style( 'qot-admin-css');
		if( in_array( $hook_suffix, $hook_suffix_pages ) ) { 
			$holidays = $this->model->qot_ric_get_holidays_date();	
			wp_enqueue_script('qot-sortable-script');
			wp_enqueue_script( 'postbox' );	
			wp_enqueue_script( 'qot-admin-script' );
			$newui = $wp_version >= '3.5' ? '1' : '0'; 
			wp_enqueue_script('jquery-ui-datepicker',array('jquery'));
			wp_enqueue_style( 'jquery-ui');
			
			wp_localize_script( 'qot-admin-script', 'QOTSettings', array('new_media_ui'	=>	$newui,'holidays'=>$holidays));

		    if ( $wp_version >= 3.5 ){
		        wp_enqueue_script( 'wp-color-picker' );
		    }
		    else {
		        wp_enqueue_script( 'farbtastic' );
		    }
		}

	}

	/**
	 * Register Style on Admin Side
	 * 
	 * @package Quick Order Table
	 * @since 1.0
	 */
	public function qot_ric_front_scripts(){
		
		wp_register_style( 'jquery-ui', QOT_RIC_URL.'includes/css/jquery-ui.css' );
		wp_register_style( 'ric-quick-order', QOT_RIC_URL.'includes/css/ric-quick-order.css',array(),time());
		wp_register_style( 'qot-ric-bootstrap-style', QOT_RIC_URL.'includes/css/bootstrap.min.css');
		wp_register_script( 'qot-ric-popper', QOT_RIC_URL.'includes/js/popper.min.js', '', null, true);
		wp_register_script( 'qot-ric-bootstrap', QOT_RIC_URL.'includes/js/bootstrap.min.js', '', null, true);

		wp_register_style( 'select2css',QOT_RIC_URL.'includes/css/select2.css', false, '1.0', 'all' );

	    wp_register_script( 'select2', QOT_RIC_URL.'includes/js/select2.js', array( 'jquery' ), '1.0', true);

	    wp_register_script( 'ric-quick-order-script', QOT_RIC_URL.'includes/js/ric-quick-order.js', array('select2'), time(), true);
	    
	    wp_register_style( 'qot-ric-common', QOT_RIC_URL.'includes/css/ric-common.css' );
	    wp_enqueue_style( 'qot-ric-common');

	    if(is_page( wc_get_page_id( 'cart' ) )){
	    	wp_enqueue_script('jquery-ui-datepicker',array('jquery'));
	    	wp_enqueue_style( 'jquery-ui');
	    	
	    	wp_enqueue_script( 'ric-quick-order-script' );
	   		wp_localize_script('ric-quick-order-script','Wp_Ajax',array(
	   			'ajaxurl' => admin_url( 'admin-ajax.php')
	   		));
	    }
	}
	
   	/**
	 * Enqueue Styles on Admin Side that will use shortcode
	 * 
	 * @package Quick Order Table
	 * @since 1.0
	 */   
	function qot_ric_scripts_styles(){

		$holidays = $this->model->qot_ric_get_holidays_date();	
			wp_enqueue_script('jquery-ui-datepicker',array('jquery'));
			wp_enqueue_style( 'jquery-ui');
			wp_enqueue_style( 'qot-ric-bootstrap-style');
			wp_enqueue_style( 'ric-quick-order');
			wp_enqueue_style( 'select2css' );
	   		wp_enqueue_script( 'select2' );
	   		wp_enqueue_script( 'qot-ric-bootstrap' );
	   		wp_enqueue_script( 'qot-ric-popper' );
	   		wp_enqueue_script( 'ric-quick-order-script' );
	   		wp_localize_script( 'ric-quick-order-script','Wp_Ajax',array('ajaxurl' => admin_url( 'admin-ajax.php', ( is_ssl() ? 'https' : 'http' )), 'holidays'=>$holidays ));
	}

	/**
	 * Adding Hooks
	 *
	 * Adding hooks for the styles and scripts.
	 *
	 * @package Quick Order Table
	 * @since 1.00
	 */
	function add_hooks(){
		
		add_action('admin_enqueue_scripts', array($this, 'qot_ric_admin_scripts'));
		add_action('wp_enqueue_scripts', array($this, 'qot_ric_front_scripts'));
	}
}
?>