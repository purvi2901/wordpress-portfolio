<?php if (!defined('ABSPATH')) {
    exit;
}

/**
 * QRT Settings Page
 *
 * Handle settings
 *
 * @package QRT Settings
 * @since 1.0.0
 */

global $qot_ric_model,$default_fields;

$model = $qot_ric_model;

    //all settings will reset as per default
if (isset($_POST['qot_ric_reset_settings']) && !empty($_POST['qot_ric_reset_settings']) && $_POST['qot_ric_reset_settings'] == esc_html__('Reset All Settings', 'quickorder')) { //check click of reset button
    qot_ric_default_settings(); // set default settings

    echo '<div class="updated" id="message">
			<p><strong>'. esc_html__("All Settings Reset Successfully.", 'quickorder') .'</strong></p>
		</div>';
}
//check settings updated or not
if (isset($_GET['settings-updated']) && $_GET['settings-updated'] == 'true') {
    echo '<div class="updated" id="message">
			<p><strong>'. esc_html__("Changes Saved Successfully.", 'quickorder') .'</strong></p>
		</div>';
}
?>
	<!-- . begining of wrap -->
	<div class="wrap">
		<?php
          echo "<h2>" . esc_html__('Quick Order Table', 'quickorder') . "</h2>"; ?>	
		<div class="qot-ric-reset-setting">
			<form method="post" action="">
				<input id="qot-ric-reset-all-options" type="submit" class="button-primary" name="qot_ric_reset_settings" value="<?php echo esc_html__('Reset All Settings', 'quickorder'); ?>" />
			</form>
		</div>
			
		<!-- beginning of the plugin options form -->
		<form  method="post" action="options.php">		
		
			<?php
        settings_fields('qot_ric_plugin_options');
		$qot_ric_options = get_option('qot_ric_options');
		$qotricoptions = (!empty($qot_ric_options)) ? $qot_ric_options : $default_fields;
		
?>

		<!-- beginning of the settings meta box -->	
			<div id="qot-ric-settings" class="post-box-container">
			
				<div class="metabox-holder">	
			
					<div class="meta-box-sortables ui-sortable">
			
						<div id="settings" class="postbox">	
			
						<div class="handlediv" title="<?php echo __('Click to toggle', 'quickorder') ?>"><br />
						</div>
						<h3 class="hndle">					
								<span style="vertical-align: top;"><?php echo __('Sorting Fields', 'quickorder') ?></span>					
							</h3>
							
			
								<div class="inside">	
									<!-- settings box title -->					
								<h2 class="settings-title">					
									<?php echo esc_html__('Quick Order Table Fields Setings', 'quickorder') ?>				
								</h2>		

									<table class="form-table qot-ric-settings-box"> 
										<tbody>
											<?php
                                foreach ($qotricoptions as $key => $qot_option) { ?>
											<tr class="qot-field-label" data-row-id=<?php echo $key;?>>
												<th scope="row">
													<label><strong><?php echo $qot_option['label']; ?></strong>
													</label>
												</th>
												<td><input type="text" id="qot-ric-settings-field" name="qot_ric_options[<?php echo $key;?>][field]" value="<?php echo $model->qot_ric_escape_attr($qot_option['field']); ?>" size="40" />
												<input type="hidden" id="qot-ric-settings-label" name="qot_ric_options[<?php echo $key;?>][label]" value="<?php echo $model->qot_ric_escape_attr($qot_option['label']); ?>" size="30" /><br />
													<i class="description"><?php echo esc_html__('Enter Name of '.$qot_option['label'], 'quickorder') ?></i>
												</td>
												<td>
													<input type="checkbox" id="qot-ric-settings-status" name="qot_ric_options[<?php echo $key;?>][status]" value="1" <?php echo checked($qot_option['status'], 1, false ); ?> size="10" />
													<i class="description"><?php echo esc_html__('Disable '.$qot_option['label'], 'quickorder') ?></i>
												</td>
											 </tr>
											<?php }
                                ?>
											
									
											<tr class="setting-btn">
												<td colspan="2">
													<input type="submit" class="button-primary qot-ric-settings-save" name="qot_ric_settings_save" class="" value="<?php echo esc_html__('Save Changes', 'quickorder') ?>" />
												</td>
											</tr>
									
							
										</tbody>
									</table>
						
							</div><!-- .inside -->
				
						</div><!-- #settings -->
			
					</div><!-- .meta-box-sortables ui-sortable -->
			
				</div><!-- .metabox-holder -->
			
			</div><!-- #wps-settings-general -->
			
		<!-- end of the settings meta box -->		

		</form><!-- end of the plugin options form -->
	
	</div><!-- .end of wrap -->