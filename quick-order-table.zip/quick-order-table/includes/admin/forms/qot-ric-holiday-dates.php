<?php
// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;

/**
 * holiday Date
 *
 * Handle holiday
 * 
 * @package QOT holiday Date
 * @since 1.0.0
 */

global $qot_ric_model;

$model = $qot_ric_model;
	

//check holiday updated or not
if(isset($_GET['holiday-updated']) && $_GET['holiday-updated'] == 'true') {
	
	echo '<div class="updated" id="message">
		<p><strong>'. __("Changes Saved Successfully.",'quickorder') .'</strong></p>
	</div>';
}	
?>
<!-- . begining of wrap -->
<div class="wrap">
		
	<!-- beginning of the plugin options form -->
	<form  method="post" action="options.php">		
	
		<?php
			settings_fields( 'qot_ric_plugin_holiday' );
			$qot_ric_holiday = get_option( 'qot_ric_holiday' );
			
			$option_keys = isset($qot_ric_holiday) ? $qot_ric_holiday : array();
			//echo "<pre>";print_r($option_keys);die;
		?>
	<!-- beginning of the holiday meta box -->	
		<div id="qot-ric-holiday" class="post-box-container">
		
			<div class="metabox-holder">	
		
				<div class="meta-box-sortables ui-sortable">
		
					<div id="holiday" class="postbox">	
		
					
		
							<!-- holiday box title -->					
							
		
							<div class="inside">	
								<h1 class="">					
								<?php echo __( 'Rushabh Holidays Date', 'quickorder' ) ?>	
							</h1>		

								<table class="form-table qot-ric-holiday-box-table"> 
									<thead>
										<tr>
											<th scope="row"><label><strong><?php echo __( 'Holiday Name', 'quickorder' ) ?></strong></label></th>
											<th scope="row"><label><strong><?php echo __( 'Holiday(s) Start From', 'quickorder' ) ?></strong></label></th>
											<th scope="row"><label><strong><?php echo __( 'Holiday(s) End To', 'quickorder' ) ?></strong></label></th>											
										
										</tr>
									</thead>
									<tbody>
										
										<?php
										if( !empty( $option_keys ) ) {											
											foreach ( $option_keys as $option_key => $option_value ) {																								
										?>
										<tr class="qot-ric-holiday-box-add-row" data-row-id="<?php echo $option_key; ?>">
											
											<td>
												<input type="text" class="qot-ric-holiday-title" name="qot_ric_holiday[<?php echo $option_key; ?>][holiday_name]" value="<?php echo $model->qot_ric_escape_attr(isset($option_value['holiday_name']) ? $option_value['holiday_name'] : '') ?>" size="30" />
												<p><small><?php _e( 'Enter Holiday Name.', 'quickorder' ); ?></small></p>  
											</td>											 
											<td>
												<input type="text"  name="qot_ric_holiday[<?php echo $option_key; ?>][holiday_start_date]" class="holiday_date regular-text qot-ric-holiday-start-date" cols="40" value="<?php
													echo $model->qot_ric_escape_attr(isset($option_value['holiday_start_date']) ? $option_value['holiday_start_date'] : '');?>" />
											<p><small><?php _e( 'Enter Holiday Start Date.', 'quickorder' ); ?></small></p>  
											</td>											
											<td>
												<input type="text" class="holiday_date qot-ric-holiday-end-date" name="qot_ric_holiday[<?php echo $option_key; ?>][holiday_end_date]" value="<?php echo $model->qot_ric_escape_attr(isset($option_value['holiday_end_date']) ? $option_value['holiday_end_date'] : '') ?>" size="15" />
												<p><small><?php _e( 'Enter Holiday End Date.', 'quickorder' ); ?></small></p>  
											</td>
											
											<td>												
												<a href="javascript:void(0);" id="qot_ric_holiday_data_remove" class="qot-ric-holiday-remove" title="<?php echo __( 'Delete', 'quickorder' ); ?>">
													<img src="<?php echo QOT_RIC_URL; ?>includes/images/remove.png" alt="<?php echo __( 'Delete', 'quickorder' ); ?>" />
												</a>
											</td>
										 </tr>										 
										 <?php 
											}
										} 
										else {
											
											?>
										<tr class="qot-ric-holiday-box-add-row" data-row-id="0">
											
											<td>
												<input type="text" class="qot-ric-holiday-title" name="qot_ric_holiday[0][holiday_name]" value="" size="30" />
												<p><small><?php _e( 'Enter Holiday Name.', 'quickorder' ); ?></small></p>   
											</td>											 
											<td>
												<input type="text"  name="qot_ric_holiday[0][holiday_start_date]" class="holiday_date qot-ric-holiday-start-date" cols="20" value="" />
												<p><small><?php _e( 'Enter Holiday Start Date.', 'quickorder' ); ?></small></p>   
											</td>
											<td>
												<input type="text" class="holiday_date qot-ric-holiday-end-date" name="qot_ric_holiday[0][holiday_end_date]" value="" size="20" />
												<p><small><?php _e( 'Enter Holiday End Date.', 'quickorder' ); ?></small></p>   
											</td>	
																				
											<td>												
												<a href="javascript:void(0);" id="qot_ric_holiday_data_remove" class="qot-ric-holiday-remove" title="<?php echo __( 'Delete', 'quickorder' ); ?>">
													<img src="<?php echo QOT_RIC_URL; ?>includes/images/remove.png" alt="<?php echo __( 'Delete', 'quickorder' ); ?>" />
												</a>
											</td>
										 </tr>										 
										 <?php 
										}
										?>
										 
										 <tr>
										 	<th colspan="5">
											 	<a href="javascript:void(0);" id="qot_ric_holiday_data_add" title="<?php echo __( 'Add Holiday', 'quickorder' ); ?>">
													<img src="<?php echo QOT_RIC_URL; ?>includes/images/add.png" alt="<?php echo __( 'Add', 'quickorder' ); ?>" class="qot_ric_options_img_add" />
												</a>
												<input type="submit" class="button-primary qot-ric-holiday-save" name="submit" class="" value="<?php echo __( 'Save Changes', 'quickorder' ) ?>" />
											</th>
										 </tr>		
										 								 
									</tbody>
								</table>
													
						</div><!-- .inside -->
			
					</div><!-- #holiday -->
		
				</div><!-- .meta-box-sortables ui-sortable -->
		
			</div><!-- .metabox-holder -->
		
		</div><!-- #wps-holiday-general -->
		
	<!-- end of the holiday meta box -->		

	</form><!-- end of the plugin options form -->

</div><!-- .end of wrap -->