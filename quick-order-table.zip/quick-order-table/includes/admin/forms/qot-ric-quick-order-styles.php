<?php

if (!defined('ABSPATH')) {
	exit;
}

/**
 * QRT Settings Page
 *
 * Handle settings
 *
 * @package QRT Settings
 * @since 1.0.0
 */

global $qot_ric_model;

$model = $qot_ric_model;

//all settings will reset as per default
if (isset($_POST['qot_ric_reset_styles']) && !empty($_POST['qot_ric_reset_styles']) && $_POST['qot_ric_reset_styles'] == esc_html__('Reset All styles', 'quickorder')) {
	qot_ric_default_styles_setting();

	echo '<div class="updated" id="message">
	<p><strong>'. esc_html__("All Settings Reset Successfully.", 'quickorder') .'</strong></p>
	</div>';
}
//check settings updated or not
if (isset($_GET['settings-updated']) && $_GET['settings-updated'] == 'true') {
	echo '<div class="updated" id="message">
	<p><strong>'. esc_html__("Changes Saved Successfully.", 'quickorder') .'</strong></p>
	</div>';
}
?>
<!-- . begining of wrap -->
<div class="wrap">
	<?php
	echo "<h2>" . esc_html__('Quick Order Table styles', 'quickorder') . "</h2>";?>	
	<div class="qot-ric-reset-setting">
		<form method="post" action="">
			<input id="qot-ric-reset-all-options" type="submit" class="button-primary" name="qot_ric_reset_styles" value="<?php echo esc_html__('Reset All styles', 'quickorder'); ?>" />
		</form>
	</div>
	
	<!-- beginning of the plugin options form -->
	<form  method="post" action="options.php">		
		
		<?php
		settings_fields('qot_ric_plugin_styles');
		$qot_ric_styles = get_option('qot_ric_styles');

		?>

		<!-- beginning of the settings meta box -->	
		<div id="qot-ric-settings" class="post-box-container">
			
			<div class="metabox-holder">	
				
				<div class="meta-box-sortables ui-sortable">
					
					<div id="settings" class="postbox">	
						
						<div class="inside">	
							
							<table class="form-table qot-ric-styles-box"> 
								<tbody>
									
									<tr>
										<th scope="row">
											<label><strong><?php echo esc_html__('Header Field Background(th)', 'quickorder') ?></strong></label>
										</th>
										<td>
											<?php
											global $wp_version;

											if ($wp_version >= 3.5) {
												echo '<input type="text" value="'.$qot_ric_styles['th_bg_color'].'" name="qot_ric_styles[th_bg_color]" class="qot-ric-color-box" data-default-color="#effeff" />';
											} else {
												echo '<div style="position:relative;">
												<input type="text" name="qot_ric_styles[th_bg_color]" value="'.$qot_ric_styles['th_bg_color'].'" id="qot_ric_styles" />
												<input type="button" class="qot-ric-color-box button-secondary" value="'.esc_html__('Select Color', 'quickorder').'">
												<div class="colorpicker" style="z-index:100; position:absolute; display:none;"></div>
												</div>';
											}
											?>													
											<br/><span class="description"><?php echo esc_html__('Choose color.', 'quickorder') ?></span>
										</td>
									</tr>

									<tr>
										<th scope="row">
											<label><strong><?php echo esc_html__('Header Field Text Color(th)', 'quickorder') ?></strong></label>
										</th>
										<td>
											<?php
											global $wp_version;

											if ($wp_version >= 3.5) {
												echo '<input type="text" value="'.$qot_ric_styles['th_text_color'].'" name="qot_ric_styles[th_text_color]" class="qot-ric-color-box" data-default-color="#000" />';
											} else {
												echo '<div style="position:relative;">
												<input type="text" name="qot_ric_styles[th_text_color]" value="'.$qot_ric_styles['th_text_color'].'" id="qot_ric_styles" />
												<input type="button" class="qot-ric-color-box button-secondary" value="'.esc_html__('Select Color', 'quickorder').'">
												<div class="colorpicker" style="z-index:100; position:absolute; display:none;"></div>
												</div>';
											}
											?>													
											<br/><span class="description"><?php echo esc_html__('Choose color.', 'quickorder') ?></span>
										</td>
									</tr>

									<tr>
										<th scope="row">
											<label><strong><?php echo esc_html__('Odd Row Fields Background(tr)', 'quickorder') ?></strong></label>
										</th>
										<td>
											<?php
											global $wp_version;

											if ($wp_version >= 3.5) {
												echo '<input type="text" value="'.$qot_ric_styles['tr_odd_bg_color'].'" name="qot_ric_styles[tr_odd_bg_color]" class="qot-ric-color-box" data-default-color="#effeff" />';
											} else {
												echo '<div style="position:relative;">
												<input type="text" name="qot_ric_styles[tr_odd_bg_color]" value="'.$qot_ric_styles['tr_odd_bg_color'].'" id="qot_ric_trodd_styles" />
												<input type="button" class="qot-ric-color-box button-secondary" value="'.esc_html__('Select Color', 'quickorder').'">
												<div class="colorpicker" style="z-index:100; position:absolute; display:none;"></div>
												</div>';
											}
											?>													
											<br/><span class="description"><?php echo esc_html__('Choose color.', 'quickorder') ?></span>
										</td>
									</tr>

									<tr>
										<th scope="row">
											<label><strong><?php echo esc_html__('Even Row Fields Background(tr)', 'quickorder') ?></strong></label>
										</th>
										<td>
											<?php
											global $wp_version;

											if ($wp_version >= 3.5) {
												echo '<input type="text" value="'.$qot_ric_styles['tr_even_bg_color'].'" name="qot_ric_styles[tr_even_bg_color]" class="qot-ric-color-box" data-default-color="#effeff" />';
											} else {
												echo '<div style="position:relative;">
												<input type="text" name="qot_ric_styles[tr_even_bg_color]" value="'.$qot_ric_styles['tr_even_bg_color'].'" id="qot_ric_styles" />
												<input type="button" class="qot-ric-color-box button-secondary" value="'.esc_html__('Select Color', 'quickorder').'">
												<div class="colorpicker" style="z-index:100; position:absolute; display:none;"></div>
												</div>';
											} ?>													
											<br/><span class="description"><?php echo esc_html__('Choose color.', 'quickorder') ?></span>
										</td>
									</tr>

									<tr>
										<th scope="row">
											<label><strong><?php echo esc_html__('Tbody Text Color(tr)', 'quickorder') ?></strong></label>
										</th>
										<td>
											<?php
											global $wp_version;

											if ($wp_version >= 3.5) {
												echo '<input type="text" value="'.$qot_ric_styles['tr_text_color'].'" name="qot_ric_styles[tr_text_color]" class="qot-ric-color-box" data-default-color="#effeff" />';
											} else {
												echo '<div style="position:relative;">
												<input type="text" name="qot_ric_styles[tr_text_color]" value="'.$qot_ric_styles['tr_text_color'].'" id="qot_ric_styles" />
												<input type="button" class="qot-ric-color-box button-secondary" value="'.esc_html__('Select Color', 'quickorder').'">
												<div class="colorpicker" style="z-index:100; position:absolute; display:none;"></div>
												</div>';
											}
											?>													
											<br/><span class="description"><?php echo esc_html__('Choose color.', 'quickorder') ?></span>
										</td>
									</tr>
									
									
									<tr >
										<td colspan="2">
											<input type="submit" class="button-primary qot-ric-settings-save" name="qot_ric_settings_save" class="" value="<?php echo esc_html__('Save Changes', 'quickorder') ?>" />
										</td>
									</tr>
									
									
								</tbody>
							</table>
							
						</div><!-- .inside -->
						
					</div><!-- #settings -->
					
				</div><!-- .meta-box-sortables ui-sortable -->
				
			</div><!-- .metabox-holder -->
			
		</div><!-- #wps-settings-general -->
		
		<!-- end of the settings meta box -->		

	</form><!-- end of the plugin options form -->
	
</div><!-- .end of wrap -->