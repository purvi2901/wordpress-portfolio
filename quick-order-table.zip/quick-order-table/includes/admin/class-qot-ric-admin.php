<?php

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Admin Class
 *
 * Manage Admin Panel Class
 *
 * @package Quick Order Table
 * @since 1.00
 */

class Qot_Ric_Admin
{
    public $model;
    public $scripts;

    public function __construct()
    {
        global $qot_ric_model, $qot_ric_scripts;

        $this->scripts = $qot_ric_scripts;
        $this->model = $qot_ric_model;
    }

    /**
     * Create menu page
     *
     * Adding required menu pages and submenu pages
     * to manage the plugin functionality
     *
     * @package Quick Order Table
     * @since 1.00
     */
     public function qot_ric_add_menu_page() {
        
         add_menu_page(__('Quick Order Settings', 'quickorder'), __('Quick Order Settings', 'quickorder'), 'manage_options', 'quick-order-settings', array( $this, 'qot_ric_quick_order_settings'), '', 30);

         add_submenu_page('quick-order-settings', __('Quick Order Table Styles', 'quickorder'), __('Table Field Styles', 'quickorder'), 'manage_options', 'quick-order-styles', array( $this, 'qot_ric_quick_order_styles'));

         add_submenu_page('quick-order-settings', __('Holiday By Rushabh ', 'quickorder'), __('Add Holiday Date', 'quickorder'), 'manage_options', 'quick-order-holiday-date', array( $this, 'qot_ric_holiday_dated'));
     }

     /**
     * Register Settings
     *
     * @package QOT Settings
     * @since 1.0.0
     */

    public function qot_ric_admin_init()  {
        register_setting('qot_ric_plugin_options', 'qot_ric_options', array($this, 'qot_ric_validate_options'));

        register_setting('qot_ric_plugin_styles', 'qot_ric_styles', array($this, 'qot_ric_validate_Styles'));

        register_setting('qot_ric_plugin_holiday', 'qot_ric_holiday', array($this, 'qot_ric_validate_holiday'));
    }

     /**
      * Input Validate Options
      *
      *
      * @package Quick Order Table
      * @since 1.00
      */
    public function qot_ric_validate_options($input)
    {
        /* Position */
        $input_fields=array();
        foreach ($input as $key => $inputvalue) {
            $input_fields[$key]['label']	=   $inputvalue['label'];
            $input_fields[$key]['position']	=   $inputvalue['position'];
            $input_fields[$key]['field']	=   $inputvalue['field'];
            $input_fields[$key]['status']    =   $inputvalue['status'];
        }

        $input = $input_fields;


        return $input;
    }

    public function qot_ric_validate_Styles($input)
    {
        return $input;
    }

     /**
      * Validate holidays
      *
      *
      * @package Quick Order Table
      * @since 1.00
      */
    public function qot_ric_validate_holiday($input)
    {
        $count = 0;
        $input_fields = array();

        foreach ($input as $input_key => $input_value) {
            $input_title = $input_value['holiday_name'];
            $input_sdate = $input_value['holiday_start_date'];
            $input_edate = $input_value['holiday_end_date'];


            if (!empty($input_title) || !empty($input_sdate) || !empty($input_edate)) {
                $input_fields[$count]['holiday_name'] 		= $input_title;
                $input_fields[$count]['holiday_start_date'] = $input_sdate;
                $input_fields[$count]['holiday_end_date'] 	= $input_edate;


                $count = $count + 1;
            }
        }
        $input = $input_fields;
        return $input;
    }


    /**
     * Including File for Quick Order Settings Menu
     *
     * @package Quick Order Table
     * @since 1.00
     */
    public function qot_ric_quick_order_settings()
    {
        include_once(QOT_RIC_ADMIN_DIR . '/forms/qot-ric-quick-order-settings.php');
    }
    public function qot_ric_quick_order_styles()
    {
        include_once(QOT_RIC_ADMIN_DIR . '/forms/qot-ric-quick-order-styles.php');
    }
    public function qot_ric_holiday_dated()
    {
        include_once(QOT_RIC_ADMIN_DIR . '/forms/qot-ric-holiday-dates.php');
    }



    /**
     * Adding Hooks
     *
     * @package Quick Order Table
     * @since 1.00
     */
    public function add_hooks()
    {
        add_action('admin_menu', array( $this, 'qot_ric_add_menu_page' ));
        add_action('admin_init', array($this, 'qot_ric_admin_init'));
    }
}
