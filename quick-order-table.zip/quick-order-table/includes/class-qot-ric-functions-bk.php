<?php
if (session_status() === PHP_SESSION_NONE) {
	    session_start();
	}


remove_action( 'pre_get_posts', array('B2BE_Catalogue_Visibility','modify_shortcode_query'), 20);	


function modify_shortcode_query_2( $query ) {

	global $qot_ric_model;
	if ( ! $q->is_main_query() ) return;
	if ( ! $q->is_post_type_archive() ) return;

	if ( ! is_admin() && is_shop() ) {
		if($query->query['post_type'] == 'product'){
			$exclude_ids = $qot_ric_model->get_hidden_product_id();

			$query->set( 'post__not_in',  $exclude_ids );
		}

	}

	
	
}
/* Shortcode of Quick order table */
add_shortcode('quick_order','ric_product_table');
function ric_product_table(){

	global $qot_ric_scripts, $ric_wp_products, $default_fields,$field, $qot_ric_model;

	$exclude_ids = $qot_ric_model->get_hidden_product_id();

	$qot_ric_options = get_option( 'qot_ric_options' );
	$qot_ric_styles = get_option( 'qot_ric_styles' );
	
	
	$qot_ric_scripts->qot_ric_scripts_styles();
	ob_start();
	
	// echo "<pre>";print_r($exclude_ids);
	$ric_shown_products  = new WP_Query(array(

	    'post_type' => 'product',
	    'post_status' => 'publish',
	    // 'fields' => 'all',
	    'posts_per_page' => -1,
	     'post__not_in' => $exclude_ids,
	));?>
	<?php ?>
	<div class="product dropdown_wrap">
		<?php if ( $ric_shown_products->have_posts() ) {?>
		<select id="search_quick_products">
			<option value=""><?php esc_html_e('Select Products');?></option>
			<?php

			while ($ric_shown_products->have_posts()) {
				$ric_shown_products->the_post();

				$product_id =  $ric_shown_products->post->ID;	?>
				<option value="<?php echo $product_id; ?>">
					<?php echo get_the_title(); ?>
				</option>

			<?php
			  // wp_reset_postdata();
			 }
			?>
			
			
		</select>	
		<button id="add_quick_order"><?php esc_html_e('Add Product'); ?></button>
	<?php } ?>
	</div>
	
<?php 
 // echo "<pre>";
 // print_r($_SESSION['quickorder']);
 // echo "</pre>";

 //  echo "<pre>";
 // print_r($_SESSION['quickorder_clone']);
 // echo "</pre>";
?>
<div class="qot-table-section">
	<div id="error_response"></div>
	<table class="qot">
		<thead>
			<tr>
			 	<?php 
			 	$body_row=array();
			 	foreach ($qot_ric_options as  $key => $options) { 
			 		$body_row[]=$key;?>

			 		<th style="background-color: <?php echo $qot_ric_styles['th_bg_color']; ?>; color:<?php echo $qot_ric_styles['th_text_color']; ?>;  "> <?php echo (!empty($options['field'])) ? $options['field']: $default_fields[$key]['field']; ?>
			 		</th>

			 		<?php } ?>
			 
			 </tr>
		</thead>
	<tbody id="list_quick_order">
		<div class="qot-ric-loader"><div id="loader_gif"></div></div>
		<?php

		if(isset($_SESSION['quickorder']) && is_array($_SESSION['quickorder']) && count($_SESSION['quickorder'])>0) {
		 echo qot_ric_tbody_data($_SESSION['quickorder']);
		}?>
		
	</tbody>
	</table>
	
</div>

<div class="qot_ric_checkout">
		<div class="wc-proceed-to-checkout"><button id="cart_to_checkout" class="checkout-button button alt wc-forward"><?php esc_html_e('Proceed to checkout');?></button>
		</div>
</div>

<div class="quick-view-modal">
	
	<div class="modal fade" id="qorder_quickview" tabindex="-1" role="dialog" aria-labelledby="qot_ric_modalTitle" aria-hidden="true">
	  <div class="modal-dialog modal-dialog-centered" role="document">
	    <div class="modal-content">
	      <div class="modal-header">
	        <h5 class="modal-title" id="exampleModalLongTitle"><?php esc_html_e('Quick View');?></h5>
	        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
	          <span aria-hidden="true">&times;</span>
	        </button>
	      </div>
	      <div class="modal-body" id="quickview_data">
	      	<div id="loader_gif_modal"></div>
	        <?php
	        //qot_ric_show_product_images($product_id);
	         ?>
	      </div>
	     
	    </div>
	  </div>
	</div>
</div>
	<?php 
	$output_string = ob_get_contents();
	ob_end_clean();
	return $output_string;
}

function qot_ric_tbody_data($data){
	global $field;
	$qot_ric_options = get_option( 'qot_ric_options' );
	$qot_ric_styles = get_option( 'qot_ric_styles' );
	$odd = $qot_ric_styles['tr_odd_bg_color'];
	$even = $qot_ric_styles['tr_even_bg_color'];

	$body_text = $qot_ric_styles['tr_text_color'];
	$body_row=array();
	foreach ($qot_ric_options as  $key => $options) { 
	 		$body_row[]=$key;
	 }
	$sort_array = array();
	$sort_order =array();
	foreach ($body_row as  $key) {
		$sort_array[$key]=$field[$key];
	}
	$result_data='';

	if(is_array($data) && count($data)>0) {
		
		$cnt=1;
		foreach ($data as $key=> $quickorder) {
			//print_r($quickorder);
			$currency = get_woocommerce_currency_symbol();	
			$bgcolor = ($cnt % 2 == 0)? $even : $odd;
			$result_data.='<tr id="row-'.$key.'" style="background-color:'.$bgcolor.';color: '.$body_text.'">';
				
				foreach ($body_row as  $key) {
					$sort_order[$key]=$quickorder[$key];
				}

				$i=0;
				foreach ($sort_order as  $key => $options) { 
				$field_name=$sort_array[$key];
					$result_data.='<td class="'.$field_name.'">'.$options[$field_name].'</td>';
				 $i++;
				} 
			 $result_data.='</tr>';	
			 $cnt++;
		}
	}
	return $result_data;
			
}

add_action( 'wp_ajax_ric_wp_get_quick_order', 'ric_wp_get_quick_order');
add_action( 'wp_ajax_nopriv_ric_wp_get_quick_order',  'ric_wp_get_quick_order');

function ric_wp_get_quick_order(){
	global $field;
	if(isset($_POST['get_id'])){
		$product_id =  $_POST['get_id'];
	}
		$resposnse=array();

	if(!isset($_SESSION))
	{
	session_start();
	}
	$product = wc_get_product( $product_id );
	$ric_wp_wip_qty 	= get_post_meta( $product_id, '_ric_wp_wip_qty', true);
	$ric_wp_wip_date	= get_post_meta( $product_id, '_ric_wp_wip_date', true );
	$ric_wp_wip_lead_time	= get_post_meta( $product_id, '_ric_wp_wip_lead_time', true );
	$ric_wp_availability= get_post_meta( $product_id,'_ric_wp_availability', true);
	$currency = get_woocommerce_currency_symbol();
	$unit_price = $product->get_price();
	$qot_ric_total_price = $unit_price;
	$quickorder=array();

	if(!empty($ric_wp_wip_lead_time)){
		$leadtime = ric_wp_daystoweek($ric_wp_wip_lead_time);
	}else{$leadtime='-';}
	
	$exist_order_id = get_exist_order_id();
	
	if(in_array($product_id,$exist_order_id)){
		$last_exist = get_last_exist_key_id();
			if (strpos($last_exist, '_') !== false) {
				$exist_key = substr($last_exist, strpos($last_exist, "_") + 1);  
				$exist_key = $exist_key + 1;
			}else{
				$exist_key = 0;
			}
			$productid = $product_id.'_'.$exist_key;
	}else{
		$productid = $product_id;
	}

	$quickorder['qorder_id']=$product_id;
	$quickorder['qorder_did']=$productid;
	$quickorder['qorder_quickview']='<button data-id="'.$productid.'" data-toggle="modal" data-target="#qorder_quickview" class="qorder_quickview">'.esc_html('Quick View').'</button>';
	$quickorder['qorder_name']=$product->get_name();
	$quickorder['qorder_sku'] =$product->get_sku();
	$quickorder['qorder_description'] = $product->get_short_description();
	$quickorder['qorder_qty_stock'] = $product->get_stock_quantity();
	$quickorder['qorder_qip_stock']= $ric_wp_wip_qty;
	$quickorder['qorder_exp_comp_date']=$ric_wp_wip_date;
	$quickorder['qorder_lead_time']= $leadtime;
	$quickorder['qorder_qty_order']= 1;
	$quickorder['qorder_qty_order_html']= qot_ric_qty_order_field($productid,$quickorder['qorder_qty_order']);
	$quickorder['qorder_unit_price']=$unit_price;
	$quickorder['qorder_currency']=$currency;
	$quickorder['qorder_total_price']=$qot_ric_total_price;
	$quickorder['qorder_eship_date']=qot_ric_date_cacl(2);;
	$quickorder['qorder_rship_date']='';
	$quickorder['qorder_rship_date_html']=qot_ric_rdate_field($productid, $unit_price, $quickorder['qorder_rship_date']);
	$quickorder['action']='<button class="delete_order"  data-id="'.$productid.'">X</button>';


//	$_SESSION['quickorder'][$product_id]= $quickorder;
	$exist_order_id = get_exist_order_id();
	
	if(in_array($product_id,$exist_order_id)){
		//if same item enter
		$last_exist = get_last_exist_key_id();
			if (strpos($last_exist, '_') !== false) {
				$exist_key = substr($last_exist, strpos($last_exist, "_") + 1);  
				$exist_key = $exist_key + 1;
			}else{
				$exist_key = 0;
			}
		for ($i=0; $i < count($field) ; $i++) { 
			$field_name=$field[$i];

			
			$_SESSION['quickorder'][$product_id.'_'.$exist_key][][$field_name]= $quickorder[$field_name];
		}
	}else{

		//if different item enter
		for ($i=0; $i < count($field) ; $i++) { 
			$field_name=$field[$i];

			$_SESSION['quickorder'][$product_id][][$field_name]= $quickorder[$field_name];
		}
	}	

	if(!empty($_SESSION['quickorder']) && !empty($_SESSION['quickorder_clone'])){
		$all_order = array_merge($_SESSION['quickorder'],$_SESSION['quickorder_clone']);	
	}else{
		$all_order = $_SESSION['quickorder'];
	}

	$_SESSION['quickorder'] = $all_order;
 	$resposnse['message']='success';
 	$resposnse['data']=  qot_ric_tbody_data($_SESSION['quickorder']);
 	$resposnse['all_order']=  $all_order;
 	

 	wp_send_json($resposnse);
 	exit;
}




function get_last_exist_key_id(){
	$data = $_SESSION['quickorder'];
	
	if(is_array($data) && count($data)>0) {
		$cnt=1;
		foreach ($data as $key=> $quickorder) {
			$exist_key_id=$key;
		 $cnt++;
		}
	}
	return $exist_key_id;
}

function get_exist_order_id(){
	$data = $_SESSION['quickorder'];
	$exist_order_id=array();
	if(is_array($data) && count($data)>0) {
		$cnt=1;
		foreach ($data as $key=> $quickorder) {
			$exist_order_id[]=$key;
		 $cnt++;
		}
	}
	return $exist_order_id;

}
function qot_ric_qty_order_field($order_id,$qty){
	
	
	$qty_order_field='<input type="number" min="1" data-id="'. $order_id.'" class="qorder_qty_order" value="'.$qty.'">';
	return $qty_order_field;
 }

function qot_ric_rdate_field($order_id, $price, $date){
	
	
	$rdate_field='<input type="text" data-id="'.$order_id.'" data-price="'.$price.'" class="qorder_rship_date" value="'.$date.'">';
	return $rdate_field;
 }



 //add_action('init','test_one');
 function test_one(){
	unset($_SESSION['quickorder']);
	unset($_SESSION['quickorder_clone']);
 	global $quick_order;
// 	print_r($quick_order);
 }

add_action( 'wp_ajax_ric_wp_delete_order', 'ric_wp_delete_order');
add_action( 'wp_ajax_nopriv_ric_wp_delete_order',  'ric_wp_delete_order');

function ric_wp_delete_order(){
	$resposnse=array();
	if(isset($_POST['prod_id'])) {

		$pro_id = $_POST['prod_id'];
		unset($_SESSION['quickorder'][$pro_id]);
		$response['message']='success';
		
	 wp_send_json($response);
	
	}
}


add_action( 'wp_ajax_ric_wp_qorder_quickview', 'ric_wp_qorder_quickview');
add_action( 'wp_ajax_nopriv_ric_wp_qorder_quickview',  'ric_wp_qorder_quickview');

function ric_wp_qorder_quickview(){
	$resposnse=array();
	global $post, $woocommerce;
	if(isset($_POST['prod_id'])) {

		$product_id = $_POST['prod_id'];
		$product = wc_get_product( $product_id );
		?>
		<div class="images">
		<?php 
			$get_image_id=$product->get_image_id();
      		if($get_image_id){
      			echo  get_the_post_thumbnail( $product_id, 'thumbnail' );	
      		}else{
      				echo apply_filters( 'woocommerce_single_product_image_html', sprintf( '<img src="%s" alt="%s" />', wc_placeholder_img_src(), __( 'Placeholder', 'woocommerce' ) ), $post->ID );		
      		}
		$attachment_ids = $product->get_gallery_image_ids();
		if ( $attachment_ids ) :
			$loop 		= 0;
			$columns 	= apply_filters( 'woocommerce_product_thumbnails_columns', 3 );
			?>
			<div class="thumbnails <?php echo 'columns-' . $columns; ?>"><?php
				foreach ( $attachment_ids as $attachment_id ) {
					$classes = array( 'thumbnail' );
					if ( $loop === 0 || $loop % $columns === 0 )
						$classes[] = 'first';
					if ( ( $loop + 1 ) % $columns === 0 )
						$classes[] = 'last';
					$image_link = wp_get_attachment_url( $attachment_id );
					if ( ! $image_link )
						continue;
					$image_title 	= esc_attr( get_the_title( $attachment_id ) );
					$image_caption 	= esc_attr( get_post_field( 'post_excerpt', $attachment_id ) );
					$image       = wp_get_attachment_image( $attachment_id, apply_filters( 'single_product_small_thumbnail_size', 'shop_thumbnail' ), 0, $attr = array(
						'title'	=> $image_title,
						'alt'	=> $image_title
						) );
					$image_class = esc_attr( implode( ' ', $classes ) );
					echo apply_filters( 'woocommerce_single_product_image_thumbnail_html', sprintf( '<a href="%s" class="%s" title="%s" >%s</a>', $image_link, $image_class, $image_caption, $image ), $attachment_id, $post->ID, $image_class );
					$loop++;
				}
			?>
				
			</div>
		<?php endif; ?>
		</div>
		<div class="summary entry-summary scrollable">
            <div class="summary-content">  
            	<?php
            		$ric_wp_wip_qty 	= get_post_meta( $product_id, '_ric_wp_wip_qty', true);
					$ric_wp_wip_date	= get_post_meta( $product_id, '_ric_wp_wip_date', true );
					$ric_wp_wip_lead_time	= get_post_meta( $product_id, '_ric_wp_wip_lead_time', true );
					
            	 ?>
					<h1 class="product_title entry-title"><?php echo $product->get_name();?></h1> 
						<strong class="price"><?php echo $product->get_price_html(); ?></strong>
					<div class="woocommerce-product-details__short-description">
						<p><?php echo $product->get_short_description();?></p>
					</div>


					<table>
					
							<tr class="quantity">
								<th>
										
							<?php if($product->get_stock_quantity()<0){?>
							<label class="" for=""><strong><?php esc_html_e('On backorder:')?> </strong></label>	
							<?php }else{?>
							<label class="" for=""><strong><?php esc_html_e('Quantity In Stock:')?> </strong></label>
							<?php } ?>
								</th>	
								<td><span><?php echo $product->get_stock_quantity();?></span></td>
							</tr>
					<?php if(!empty($ric_wp_wip_qty)){?>
						<tr class="wip_qty">
								<th>
							<label class="" for="">
								<strong> <?php esc_html_e('Work-In-Progress Qty: ');  ?></strong>
							</label>
							
				
							</th>	
							<td><span><?php echo $ric_wp_wip_qty;?></span></td>
							</tr>
					<?php } ?>

					<?php if(!empty($ric_wp_wip_date)){?>
						<tr class="wip_date">
							<th>
							<label class="" for="">
								<strong> <?php esc_html_e('Work-In-Progress');  ?><br/><?php esc_html_e(' Completion Date: ');?></strong>
							</label>
						
							</th>
							<td>	<span><?php echo $ric_wp_wip_date;?></span></td>	
						</tr>
					<?php } ?>

						
					<?php if(!empty($ric_wp_wip_lead_time)){?>
						<tr class="wip_date">
							<th>
								<label class="" for="">
									<strong> <?php esc_html_e('Lead time: ');  ?></strong>
								</label>
								
							</th>
							<td>
								<span><?php echo $ric_wp_wip_lead_time;?></span>
							</td>	
						</tr>
					<?php } ?>
					
					<?php if(!empty($product->get_sku())){?>
						<tr class="sku">
							<th>
							<label class="" for=""><strong><?php esc_html_e('SKU:'); ?> </strong></label>
							
							</th>
							<td><span><?php echo $product->get_sku();?></span></td>
						</tr>
					<?php } ?>
					
				</table>

            </div>
        </div>
		<?php
	// wp_send_json($response);
	
	}
	die();
}


add_action( 'wp_ajax_ric_wp_qorder_update_qty', 'ric_wp_qorder_update_qty');
add_action( 'wp_ajax_nopriv_ric_wp_qorder_update_qty',  'ric_wp_qorder_update_qty');

function ric_wp_qorder_update_qty(){
	global $field;

	$resposnse=array();
	if(isset($_POST['prod_id']) && isset($_POST['qty_updated'])) {

	$prod_id = $_POST['prod_id'];
	$product_id = qot_get_product_id($prod_id);
	$product = wc_get_product($product_id);

	$unit_price = $product->get_price();
	
	$qty_in_stock = $product->get_stock_quantity();
	$wip_qty 	= get_post_meta( $product_id, '_ric_wp_wip_qty', true);
	$qty_desired = $_POST['qty_updated'];
	$qot_ric_total_price = ($unit_price * $qty_desired);
	//If qty desired <= qty in stock,
	if($qty_desired<=$qty_in_stock)	{
		$ship_date = qot_ric_date_cacl(2);
	}

	//If qty desired > qty in stock but qty desired <= qty in stock + qty in process, the earliest ship date is the date of completion of qty in process
	if($qty_desired > $qty_in_stock && $qty_desired <=( $qty_in_stock + $wip_qty)){
		$ship_date = get_post_meta( $product_id, '_ric_wp_wip_date', true );
		if(!empty($ship_date)){
			$ship_date = date('Y-m-d', strtotime($ship_date));	
		}else{
			$ship_date='';
		}
		
		

	}

	//If qty desired > qty in stock + qty in process, the earliest ship date is today + standard lead time
	if($qty_desired > ($qty_in_stock + $wip_qty)){
		$wip_lead_time =  get_post_meta( $product_id, '_ric_wp_wip_lead_time', true );
		if(!empty($wip_lead_time)){
			$ship_date =  qot_ric_date_cacl($wip_lead_time);
			$ship_date =  date('Y-m-d', strtotime($ship_date));
		}else{
			$ship_date='';
		}
		
	}
	
	$i=0;
	foreach ($field as $key) {
		if($key=='qorder_total_price'){
			$_SESSION['quickorder'][$prod_id][$i]['qorder_total_price']=$qot_ric_total_price;
			
		}
		if($key=='qorder_qty_order'){
			$_SESSION['quickorder'][$prod_id][$i]['qorder_qty_order']=$qty_desired;
		}
		if($key=='qorder_eship_date'){
			$_SESSION['quickorder'][$prod_id][$i]['qorder_eship_date']= $ship_date;
		}
		if($key=='qorder_qty_order_html'){
			$_SESSION['quickorder'][$prod_id][$i]['qorder_qty_order_html']= qot_ric_qty_order_field($prod_id,$qty_desired);
		}
			
			
		$i++;
	}


	$response['ship_date']=$ship_date;
	$response['total_price']=$qot_ric_total_price;
	$response['message']='success';
	
	wp_send_json($response);
	exit();
	}
}

function qot_ric_date_cacl($date){
	
	$ShipDate=date('Y-m-d', strtotime('+'.$date.' days'));
	return $ShipDate;
}
function qot_get_product_id($prod_id){
	if (strpos($prod_id, '_') !== false) {
		$exist_key = explode("_", $prod_id);
		$product_id = $exist_key[0];
	}else{
		$product_id = $prod_id;
	}
	return $product_id;
}

add_action( 'wp_ajax_ric_wp_qorder_update_date', 'ric_wp_qorder_update_date');
add_action( 'wp_ajax_nopriv_ric_wp_qorder_update_date',  'ric_wp_qorder_update_date');



function ric_wp_qorder_update_date(){
	global $field;
	$resposnse=array();
	if(isset($_POST['prod_id']) && isset($_POST['date_updated'])) {

	$prod_id = $_POST['prod_id'];
	$product_id = qot_get_product_id($prod_id);
	$product = wc_get_product($product_id);
	$unit_price = $product->get_price();
	$date_updated = $_POST['date_updated'];

	$i=0;
	foreach ($field as $key) {
		if($key=='qorder_rship_date'){

			$_SESSION['quickorder'][$prod_id][$i]['qorder_rship_date']= $date_updated;
			
		}
		if($key=='qorder_rship_date_html'){

		$_SESSION['quickorder'][$prod_id][$i]['qorder_rship_date_html']= qot_ric_rdate_field($prod_id,$unit_price,$date_updated);
		}
	$i++;	
	}
		

	$response['message']='success';
		
	wp_send_json($response);
	exit();
	}
}
function qot_ric_individual_cart_items( $cart_item_data, $product_id ) {
  $unique_cart_item_key = md5( microtime() . rand() );
  $cart_item_data['unique_key'] = $unique_cart_item_key;

  return $cart_item_data;
}
add_filter( 'woocommerce_add_cart_item_data', 'qot_ric_individual_cart_items', 10, 2 );

/* Add to cart all Items of Qot */
add_action( 'wp_ajax_qot_ric_add_tocart', 'qot_ric_add_tocart');
add_action( 'wp_ajax_nopriv_qot_ric_add_tocart',  'qot_ric_add_tocart');

function qot_ric_add_tocart(){
	$resposnse=array();
	$quickorders=  $_SESSION['quickorder'];
	WC()->cart->empty_cart();
	$meta_data=array();
	foreach ($quickorders as $key=>  $quickorder) {
		foreach ($quickorder as  $order) {
			//print_r($order);
			$requested_date = $order['qorder_rship_date'];
			$earlier_ship_date = $order['qorder_eship_date'];

			if(strpos($key, '_') !== false) {
				$exist_key = explode("_", $key); 
				$exist_key = $exist_key[0];
			}else{
				$exist_key = $key;
			}

			WC()->cart->add_to_cart( $exist_key, $order['qorder_qty_order']);
			// if($order['qorder_eship_date']){
			// 	$meta_data['_qorder_eship_date'] = $order['qorder_eship_date'];
			// }
			// if($order['qorder_rship_date']){
			// 	$meta_data['_qorder_rship_date'] = $order['qorder_rship_date'];
			// }

		}
		//echo $earlier_ship_date; 
		// wc_add_order_item_meta($key, '_qorder_eship_date', $meta_data['_qorder_eship_date'] );
		// wc_add_order_item_meta($key, '_qorder_rship_date', $meta_data['_qorder_rship_date'] );
		
	}

	$response['message']='success';
	$response['url']=wc_get_checkout_url();
	// $response['quickorder']=$quickorders;

	wp_send_json($response);
	exit();
	
}



//add_filter( 'woocommerce_checkout_cart_item_quantity', 'custom_checkout_cart_item_name', 10, 3 );
function custom_checkout_cart_item_name( $item_qty, $cart_item, $cart_item_key ) {
 //  global $woocommerce,$post, $order;
   $product_id = $cart_item['product_id'];
  // echo "<pre>";
  // print_r($cart_item);
if(isset($cart_item['ric_wp_order_meta']) && !empty($cart_item['ric_wp_order_meta']) ){

	$qot_ric_order_meta = $cart_item['ric_wp_order_meta'];

	$ship_date = $req_date = '';
	foreach ($qot_ric_order_meta as $key => $value) {

		$get_rship_date = isset($qot_ric_order_meta[$key]['ric_wp_rship_date']) ? $qot_ric_order_meta[$key]['ric_wp_rship_date'] : '';
		$get_eship_date = isset($qot_ric_order_meta[$key]['ric_wp_eship_date']) ? $qot_ric_order_meta[$key]['ric_wp_eship_date'] : '';

		$req_date .= (!empty($get_rship_date)) ? '<div class="req-ship-meta-data"><strong>'.esc_html('Requested Ship Date:').'</strong><span> '.$get_rship_date.'</span></div>' : '';

		$ship_date .= (!empty($get_eship_date)) ? '<div class="req-ship-meta-data"><strong>'.esc_html('Earliest Possible Ship Date:').'</strong><span> '.$get_eship_date.'</span></div>' : '';
	}
}

  return $item_qty.$ship_date.$req_date;
}

function array_flatten($array) { 
  if (!is_array($array)) { 
    return FALSE; 
  } 
  $result = array(); 
  foreach ($array as $key => $value) { 
    if (is_array($value)) { 
      $result = array_merge($result, array_flatten($value)); 
    } 
    else { 
      $result[$key] = $value; 
    } 
  } 
  return $result; 
} 
// add_action('init','qot_ric_get_meta_data');
// function test_one_1(){
// 	$test = qot_ric_get_meta_data();	
// 	print_r($test);
// }

function qot_ric_get_meta_data() {
	
	$data = $_SESSION['quickorder'];
	$meta_data = array();
	$custom_data = array();


 
	if(is_array($data) && count($data)>0) {
		
		foreach ($data as $key=> $quickorder) {
		$meta_data[] = array_flatten($quickorder);

		}
	}
	
	foreach ($meta_data as  $meta_data) {
		
		if($meta_data['qorder_eship_date']){
			$custom_data[$meta_data['qorder_did']]['ric_wp_eship_date'] = $meta_data['qorder_eship_date'];
		}
		if($meta_data['qorder_rship_date']){
			$custom_data[$meta_data['qorder_did']]['ric_wp_rship_date'] = $meta_data['qorder_rship_date'];
		}
	}
	
//	print_r($custom_data);

	return $custom_data;

}

add_action( 'woocommerce_add_order_item_meta', 'qot_ric_order_item_meta', 10, 2 );

// $item_id – order item ID
// $cart_item[ 'product_id' ] – associated product ID (obviously)
function qot_ric_order_item_meta( $item_id, $values ) {
	
	// The corresponding Product Id for the item:
    $product_id = $values[ 'product_id' ];

	if ( isset( $values ['ric_wp_order_meta'])) {
			//echo $layout_option;
		$custom_data = $values[ 'ric_wp_order_meta' ];
	
		if(isset($custom_data[$product_id]['ric_wp_eship_date']) ) {

			wc_add_order_item_meta( $item_id, esc_html__('Earliest Possible Ship Date', 'quickorder' ), $custom_data[$product_id]['ric_wp_eship_date'] );
		}
		if(isset($custom_data[$product_id]['ric_wp_rship_date']) ) {

			wc_add_order_item_meta( $item_id, esc_html__( 'Requested Ship Date', 'quickorder' ),
			 $custom_data[$product_id]['ric_wp_rship_date'] );
		}
	}
}

//add_action( 'woocommerce_after_order_itemmeta', 'display_admin_order_item_custom_button', 10, 3 );
function display_admin_order_item_custom_button( $item_id, $item, $product ){
    // Only "line" items and backend order pages
    if( ! ( is_admin() && $item->is_type('line_item') ) )
        return;

     // $product_id = $item->get_product_id();

  $get_rship_date = wc_get_order_item_meta( $item_id, '_qorder_rship_date', true ); 
  $get_eship_date = wc_get_order_item_meta( $item_id, '_qorder_eship_date', true ); 

 $ship_date= (!empty($get_rship_date))? '<tr><th>'.esc_html('Requested Ship Date:').'</th><td><p>'.$get_rship_date.'</p></td>
	</tr>':'';

 $req_date= (!empty($get_eship_date))? '<tr><th>'.esc_html('Earliest Possible Ship Date:').'</th><td><p>'.$get_eship_date.'</p></td>
	</tr>':'';

  
echo '<div class="view">
<table class="display_meta qot_ric_order_meta" cellspacing="0">
	<tbody>'.$ship_date.$req_date.'</tbody>
	</table>
</div>';
    
}


add_filter( 'woocommerce_add_cart_item_data','ric_wp_add_cart_item_data', 90, 2 );
 function ric_wp_add_cart_item_data( $cart_item_meta, $product_id ) {
	$custom_data  = array();
	$productid =array();
	if(!empty($_SESSION['quickorder'])){

		$quickorders=  $_SESSION['quickorder'];
		//print_r($quickorders);
		
		
		$i=0;
		// foreach ($quickorders as $key => $quickorder) {
		// 		$productid[]=$product_id;
			// $qorder_did = $quickorders[$key][16]['qorder_did'];
			
			// if($key == $product_id){
			// 	$product_id = $product_id."_".$i;
			// }else{
			// 	$product_id = $product_id;
			// }
			// if($qorder_did == $product_id){
			 	/*foreach ($quickorders[$product_id] as  $order) {
				
					if($order['qorder_eship_date']){
						$custom_data[$product_id]['ric_wp_eship_date'] = $order['qorder_eship_date'];
					}
					if($order['qorder_rship_date']){
						$custom_data[$product_id]['ric_wp_rship_date'] = $order['qorder_rship_date'];
					}
				
				}*/

				foreach ($quickorders as $key => $order) {
					
					$order = array_flatten($order);

					if($order['qorder_eship_date']){
						$custom_data[$key]['ric_wp_eship_date'] = $order['qorder_eship_date'];
					}
					if($order['qorder_rship_date']){
						$custom_data[$key]['ric_wp_rship_date'] = $order['qorder_rship_date'];
					}
				
				}
			
				
			
			
		$i++;
		//}	
		
	}
	      
//	print_r($custom_data);
	$cart_item_meta['ric_wp_order_meta'] = $custom_data;
	return $cart_item_meta;
}

function action_woocommerce_checkout_order_processed( $order_id, $posted_data, $order ) {   
    // Get order currency
    $order_currency = $order->get_currency();

    // Get order payment method
    $order_payment_gateway = $order->get_payment_method();
    
    // Address
    $order_address = array(
        'first_name' => $order->get_billing_first_name(),
        'last_name'  => $order->get_billing_last_name(),
        'email'      => $order->get_billing_email(),
        'phone'      => $order->get_billing_phone(),
        'address_1'  => $order->get_billing_address_1(),
        'address_2'  => $order->get_billing_address_2(),
        'city'       => $order->get_billing_city(),
        'state'      => $order->get_billing_state(),
        'postcode'   => $order->get_billing_postcode(),
        'country'    => $order->get_billing_country()
    );

    // Shipping
    $order_shipping = array(
        'first_name' => $order->get_shipping_first_name(),
        'last_name'  => $order->get_shipping_last_name(),
        'address_1'  => $order->get_shipping_address_1(),
        'address_2'  => $order->get_shipping_address_2(),
        'city'       => $order->get_shipping_city(),
        'state'      => $order->get_shipping_state(),
        'postcode'   => $order->get_shipping_postcode(),
        'country'    => $order->get_shipping_country()
    );
    
    // Counter
    $counter = 1;

    // Loop through order items
    foreach ( $order->get_items() as $item_id => $item ) {
        // From the 2nd product
        if ( $counter >= 2 ) {
            // Get the WC_Product Object
            $product = $item->get_product();
            
            // Get product quantity
            $product_quantity = $item->get_quantity();
            
            // Create new order
            $new_order = wc_create_order();
            
            // Add product to new order
            $new_order->add_product( $product, $product_quantity );
            
            // Set addresses
            $new_order->set_address( $order_address, 'billing' );
            $new_order->set_address( $order_shipping, 'shipping' );

            // Set the correct currency and payment gateway
            $new_order->set_currency( $order_currency );
            $new_order->set_payment_method( $order_payment_gateway );

            // Calculate totals
            $new_order->calculate_totals();

            // Set order note with original ID
            $new_order->add_order_note( 'Automated order. Created from the original order ID: ' . $order_id );
            
            // Set correct status
            $new_order->update_status( 'on-hold' );

            // Delete product from original order
            $order->remove_item( $item_id );
        }
        
        // Counter = counter + 1
        $counter++;
    }
    
    // Re-calculate & save
    $order->calculate_totals();
    $order->save();
}
add_action( 'woocommerce_checkout_order_processed', 'action_woocommerce_checkout_order_processed', 10, 3 );