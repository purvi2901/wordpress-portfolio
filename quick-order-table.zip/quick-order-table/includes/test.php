<?php
// Include WordPress environment for testing purpose (if this is standalone, adjust the path to wp-load.php).
require_once(dirname(__FILE__) . '/wp-load.php');

// Include the delivery date function
// Ensure the function get_availability_data() is included or available in this file.

function calculate_delivery_date($product_id, $order_qty)
{
    $availability_data = get_availability_data($product_id);
    if (empty($availability_data)) {
        return 'No availability data found for this product.';
    }

    $total_qty = 0;
    $lead_time_date = null;

    foreach ($availability_data as $data) {
        if (isset($data['type'], $data['date_available'])) {
            if ($data['type'] === 'lead_time') {
                $lead_time_date = $data['date_available'];
            }

            if (isset($data['qty'])) {
                $total_qty += intval($data['qty']);

                if ($total_qty >= $order_qty) {
                    return "Delivery Date: " . $data['date_available'];
                }
            }
        }
    }

    return $lead_time_date ? "Delivery Date (Lead Time): " . $lead_time_date : 'Delivery date not available.';
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $product_id = isset($_POST['product_id']) ? intval($_POST['product_id']) : 0;
    $order_qty  = isset($_POST['order_qty']) ? intval($_POST['order_qty']) : 0;

    if ($product_id > 0 && $order_qty > 0) {
        $delivery_date = calculate_delivery_date($product_id, $order_qty);
    } else {
        $delivery_date = 'Please enter valid product ID and order quantity.';
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Delivery Date Tester</title>
</head>
<body>
    <h1>Delivery Date Tester</h1>
    <form method="POST">
        <label for="product_id">Product ID:</label>
        <input type="number" id="product_id" name="product_id" required>
        <br><br>
        <label for="order_qty">Order Quantity:</label>
        <input type="number" id="order_qty" name="order_qty" required>
        <br><br>
        <button type="submit">Calculate Delivery Date</button>
    </form>

    <?php if (isset($delivery_date)) : ?>
        <h2>Result:</h2>
        <p><?php echo esc_html($delivery_date); ?></p>
    <?php endif; ?>
</body>
</html>
