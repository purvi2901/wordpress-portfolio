"use strict";

jQuery(document).ready(function() {	
	jQuery(".holiday_date").datepicker({
 	  	dateFormat : "yy-mm-dd",
 	});

	if( QOTSettings.new_media_ui == '1' ) {
		jQuery('.qot-ric-color-box').wpColorPicker();
		jQuery('.qot-ric-trodd-box').wpColorPicker();
	} else {
		var inputcolor = jQuery('.qot-ric-color-box').prev('input').val();
		jQuery('.qot-ric-color-box').prev('input').css('background-color',inputcolor);
		
		jQuery( ".qot-ric-color-box" ).on( "click", function(e) {
			colorPicker = jQuery(this).next('div');
			input = jQuery(this).prev('input');
			jQuery.farbtastic(jQuery(colorPicker), function(a) { jQuery(input).val(a).css('background', a); });
			colorPicker.show();
			e.preventDefault();
			jQuery(document).mousedown( function() { jQuery(colorPicker).hide(); });
		});
	}

	//call on click reset options button from holiday page
	jQuery( document ).on('click', '#qot-ric-reset-all-options', function() {
		var ans;
		ans = confirm('Click OK to reset all options. All holiday will be lost!');
		
		if(ans){
			return true;
		} else {
			return false;
		}
	});

	/* Add New Holiday */
	jQuery( document ).on( "click", "#qot_ric_holiday_data_add", function() {		
		
		// find highest row id
		var highestRowId = 0;
		jQuery(this).parents('.qot-ric-holiday-box-table').find('.qot-ric-holiday-box-add-row').each(function (index, element) {
		   
		  var dataRowId = jQuery(this).data('rowId');
		  if(highestRowId < dataRowId) {
		  	highestRowId = dataRowId;
		  }       
		 });
		     
		var last_row_id = highestRowId + 1;
		var jQueryfirst = jQuery(this).parents('.qot-ric-holiday-box-table').find('.qot-ric-holiday-box-add-row:last');
  
		jQueryfirst.clone().insertAfter(jQueryfirst).show();
	 	jQuery(this).parents('.qot-ric-holiday-box-table').find('.qot-ric-holiday-box-add-row:last .qot-ric-holiday-title').attr( 'name', 'qot_ric_holiday['+last_row_id+'][holiday_name]' ).val('');	 	
	 	jQuery(this).parents('.qot-ric-holiday-box-table').find('.qot-ric-holiday-box-add-row:last .qot-ric-holiday-start-date').attr( 'name', 'qot_ric_holiday['+last_row_id+'][holiday_start_date]' ).val('');
	 	jQuery(this).parents('.qot-ric-holiday-box-table').find('.qot-ric-holiday-box-add-row:last .qot-ric-holiday-end-date').attr( 'name', 'qot_ric_holiday['+last_row_id+'][holiday_end_date]' ).val('');
	 	

	 	 	jQuery(this).parents('.qot-ric-holiday-box-table').find('.qot-ric-holiday-box-add-row:last .qot-ric-holiday-start-date').attr('id','').removeClass( 'hasDatepicker' ).val('');
	 	jQuery(this).parents('.qot-ric-holiday-box-table').find('.qot-ric-holiday-box-add-row:last .qot-ric-holiday-end-date').attr('id','').removeClass( 'hasDatepicker' ).val('');

	 	jQuery(this).parents('.qot-ric-holiday-box-table').find('.qot-ric-holiday-box-add-row:last .qot-ric-holiday-remove').show();
	 	jQuery(this).parents('.qot-ric-holiday-box-table').find('.qot-ric-holiday-box-add-row:last').attr( 'data-row-id', last_row_id );
	 	return false;
	 		 	
    });

     //delete table details for list table
	jQuery( document ).on( 'click', '#qot_ric_holiday_data_remove', function() {
						
		var rowCount = jQuery('.qot-ric-holiday-box-add-row').length;
		if(rowCount > 1) {
			
			var jQueryparent = jQuery(this).parents('.qot-ric-holiday-box-add-row');
			jQueryparent.remove();
						
		} else {
			alert('Must be at least 1 Records should be there');
		}		
		return false;
	});

});

 
jQuery('body').on('focus',".holiday_date", function(){
   jQuery(this).datepicker({
   	dateFormat : "yy-mm-dd",
   });
});