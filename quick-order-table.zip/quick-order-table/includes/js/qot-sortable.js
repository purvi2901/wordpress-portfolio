jQuery(document).ready( function(jQuery) {

	//sortable table
	jQuery('table.qot-ric-settings-box tbody').sortable({
		items:'tr',
		cursor:'move',
		axis:'y',
		handle: 'td',
		scrollSensitivity:40,
		helper:function(e,ui){
			ui.children().each(function(){
				jQuery(this).width(jQuery(this).width());
			});
			ui.css('left', '0');
			return ui;
		},
		start:function(event,ui){
			ui.item.css('background-color','#ddd');
		},
		stop:function(event,ui){
			var new_order = jQuery(this).sortable();
			console.log(new_order,'new_order');
			ui.item.removeAttr('style');
		}
	});
	
});