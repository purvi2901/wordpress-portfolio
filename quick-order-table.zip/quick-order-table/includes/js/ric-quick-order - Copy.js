var holidays = Wp_Ajax.holidays;
 
console.log(holidays,"holidays");
jQuery(document).ready(function($) {

	$('#update_cart').on('click', function (e) {

		$('#loader_gif').show();
	 	$('.qot-ric-loader').show();
	 	$('.qot-table-section').addClass('back-loader');

	 	var data_2 = { 
					action 	: 'ric_wp_qorder_consider_qty',
				
					
				};
		$('#list_quick_order tr').each(function(index) {

			var qty_updated = $(this).find('.qorder_qty_order').val();
 			var prod_id = $(this).find('.qorder_qty_order').data('id');
 			
 			if( qty_updated >= 1 ) {
	 		
		 		var ship_date_field = "#row-"+prod_id+' .qorder_eship_date'; 
		 		var total_price_field = "#row-"+prod_id+' .qorder_total_price'; 
		 		
	 			var data = { 
					action 	: 'ric_wp_qorder_update_qty',
					prod_id	: prod_id,
					qty_updated : qty_updated,
				};

		 		jQuery.post(Wp_Ajax.ajaxurl, data, function(response) {
			
					if(response) { 
						if(response.message == 'success') {

							console.log(response);
								//jQuery('#list_quick_order').html(response.data);
								
								checkout_btn();
							$(ship_date_field).text(response.ship_date);
							$(total_price_field).text(response.total_price);

							// jQuery.post(Wp_Ajax.ajaxurl, data_2, function(response2) {
							// 		if(response) { 
							// 			if(response.message == 'success') {
							// 					console.log(response);
											
											

							// 			}
							// 		}
							// }

						}
					}

					$('#loader_gif').hide();
					$('.qot-ric-loader').hide();
					$('.qot-table-section').removeClass('back-loader');
				});
		 	}
		 	else {

				$('#loader_gif').hide();
				$('.qot-ric-loader').hide();
				$('.qot-table-section').removeClass('back-loader');
		 	}

		 	var date_updated = $(this).find('.qorder_rship_date').val();
	 		
	 		//if( date_updated != '' ) {

		 		var data = { 
					action 	: 'ric_wp_qorder_update_date',
					prod_id	: prod_id,
					date_updated : date_updated,
				};
		 		jQuery.post(Wp_Ajax.ajaxurl, data, function(response) {
			
					console.log(response);
				});
	 		//}
		});
	});

	jQuery('.qorder_qty_order').on('keyup', function (e) {
   	 if (e.which === 46) return false;
		}).on('input', function () {
		    var self = this;
		    setTimeout(function () {
		        if (self.value.indexOf('.') != -1) self.value = parseInt(self.value, 10);
		    }, 0);
	 });

    jQuery('#search_quick_products').select2({		
		data: [],
        query: function (q) {

            jQuery.ajax({
                url: Wp_Ajax.ajaxurl,
                data: {action : 'ric_wp_qorder_custom_search_products', search_text: q.term},
                dataType: 'json',
                type: 'POST',
                success: function (data) {
                	
                	if( data.length !== 0 ) {
                		 q.callback({results: data.results});
                	}
                },       
            });
        },
        width: '500px',
        placeholder: 'Select Product'
	});
   
   	checkout_btn();

    jQuery(".qorder_rship_date").datepicker({
     	dateFormat: 'yy-mm-dd',
     	minDate: 1,
      	showButtonPanel: true,
	    closeText: 'Clear',
	    onClose: function (dateText, inst) {
	        if ($(window.event.srcElement).hasClass('ui-datepicker-close'))
	        {
	            document.getElementById(this.id).value = '';
	        }
	    },
 		beforeShowDay:  function(date){
	    	var string = jQuery.datepicker.formatDate('yy-mm-dd', date);
	    	var noWeekend = jQuery.datepicker.noWeekends(date);

		    var min_date = $(this).parents('.qorder_rship_date_html').prev('.qorder_eship_date').text();
		    var end_date = new Date(min_date);

		    if( end_date > date ) {
		    	return true;
		    }

	        if (noWeekend[0]) {
	        	return [jQuery.inArray(string, holidays) == -1];
	        }
	        else
	        	return noWeekend;
	    }/*,
 	    onSelect: function(date, instance) {

   			var date_updated = jQuery(this).val();
	 		var prod_id= jQuery(this).data('id');
	 			 	
	 		var data = { 
						action 	:	'ric_wp_qorder_update_date',
						prod_id	:	prod_id,
						date_updated: date_updated,

					 };
	 		jQuery.post(Wp_Ajax.ajaxurl,data,function(response) {
		
				if(response) { 
					console.log(response,'Response');
					
				
				}else{
					console.log(response);
				}
			});
	     }*/
	});



 	jQuery('#add_quick_order').click(function(){
	 	var get_id = jQuery('#search_quick_products').val();
	 	if(get_id==''){
	 		alert('Please select Product');
	 		return false;

	 	}
	 	jQuery('#loader_gif').show();
	 	jQuery('.qot-ric-loader').show();

		var data = {
					action 	: 'ric_wp_get_quick_order',
					get_id	: get_id,
				 };
			
		jQuery.post(Wp_Ajax.ajaxurl,data,function(response) {
		
		//	jQuery('#loader_gif').hide();
 		
			if(response) { 
			
				if(response.message=='success'){
						console.log(response);
					var currency = response.qorder_currency
					jQuery('#list_quick_order').html(response.data);
					jQuery('#loader_gif').hide();
					jQuery('.qot-ric-loader').hide();
					checkout_btn();
 					jQuery("#search_quick_products").select2('val', 'Select Products');
					jQuery("#search_quick_products")[0].selectedIndex = 0; 
				}else{
					jQuery('#list_quick_order').append('<tr><td colspan="12" style="text-align: center;">Not found</td></tr>');
				}
			
			}
		});
 	});

 	jQuery(document).on('click','.delete_order',function(){

 		var prod_id= jQuery(this).data('id');
 		// console.log(prod_id);
 		jQuery(this).parent('td').parent('tr').remove();
 		var data = { 
					action 	:	'ric_wp_delete_order',
					prod_id	:	prod_id,
				 };
 		jQuery.post(Wp_Ajax.ajaxurl,data,function(response) {
	
			if(response) { 
				
				if(response.message=='success'){
					checkout_btn();
					jQuery('#error_response').html('<p style="text-align: center;">Item is deleted... </p>');
					
					setTimeout(function(){

						jQuery('#error_response').html('');
					},1500);
				}
			
			}else{
				console.log(response);
			}
		});
 	});

 	
 	jQuery("#qorder_quickview").on('shown.bs.modal', function (e) {
	   jQuery('#loader_gif_modal').show();
	   	var prod_id = jQuery(e.relatedTarget).data('id');
 		
 		var data = { 
					action 	: 'ric_wp_qorder_quickview',
					prod_id	: prod_id,
				 };
 		jQuery.post(Wp_Ajax.ajaxurl,data,function(response) {
	
			if(response) { 
				jQuery('#loader_gif_modal').hide();
				jQuery('#quickview_data').html(response);

			
			}else{
				console.log(response);
				jQuery('#loader_gif_modal').hide();
			}
		});
	});
 	
 	// jQuery(document).on('click','.qorder_quickview',function(){

 	// 	var prod_id= jQuery(this).data('id');
 	// 	// console.log(prod_id);
 		
 	// 	var data = { 
		// 			action 	:	'ric_wp_qorder_quickview',
		// 			prod_id	:	prod_id,
		// 		 };
 	// 	jQuery.post(Wp_Ajax.ajaxurl,data,function(response) {
	
		// 	if(response) { 
		// 		//console.log(response,'Response');
		// 	//	jQuery('#quickview_data').html(response);
			
		// 	}else{
		// 		console.log(response);
		// 	}
		// });
 	// });

 	/*jQuery(document).on('change','.qorder_qty_order',function(){
 		
 		var qty_updated = jQuery(this).val();
 		if(qty_updated>=1){

	 		jQuery('#loader_gif').show();
		 	jQuery('.qot-ric-loader').show();
		 	jQuery('.qot-table-section').addClass('back-loader');
	 		var prod_id= jQuery(this).data('id');
	 		var unti_price= jQuery(this).data('price');
	 		var ship_date_field = "#row-"+prod_id+' .qorder_eship_date'; 
	 		var total_price_field = "#row-"+prod_id+' .qorder_total_price'; 
	 		// console.log(jQuery(ship_date_field).text());
	 		var total_price = parseInt(unti_price) * parseInt(qty_updated);
	 		// console.log(total_price,"total_qot_price");
 		
 		
	 		var data = { 
						action 	:	'ric_wp_qorder_update_qty',
						prod_id	:	prod_id,
						qty_updated: qty_updated,

					 };
		 		jQuery.post(Wp_Ajax.ajaxurl,data,function(response) {
			
					if(response) { 
						if(response.message=='success'){
						// console.log(response);
						jQuery(ship_date_field).text(response.ship_date);
						jQuery(total_price_field).text(response.total_price);
						jQuery('#loader_gif').hide();
			 			jQuery('.qot-ric-loader').hide();
			 			jQuery('.qot-table-section').removeClass('back-loader');
						}
						
					}else{
						// console.log(response);
						jQuery('#loader_gif').hide();
			 			jQuery('.qot-ric-loader').hide();
			 			jQuery('.qot-table-section').removeClass('back-loader');
					}
				});
		 	}
 	});*/

 	jQuery('#cart_to_checkout').click(function(){
 		
 		jQuery('#loader_gif').show();
 		jQuery('.qot-ric-loader').show();
 		
 		var data = { 
					action 	:	'qot_ric_add_tocart',
				 };
 		jQuery.post(Wp_Ajax.ajaxurl,data,function(response) {
	
			if(response) { 
				console.log(window.location.protocol + "//" + window.location.host + "/");
				if(response.message=='success'){
						jQuery('#loader_gif').hide();
						jQuery('.qot-ric-loader').hide();
					window.location.href=response.url;
				}
				
			}else{
				console.log(response);
			}
		});
 	});


 	function checkout_btn(){
 		var rowCount = jQuery('tbody#list_quick_order tr').length;
		if(rowCount==0){
			jQuery('.qot_ric_checkout').hide();
		}else{
			jQuery('.qot_ric_checkout').show();
		}

	}

	jQuery(document).on('click', '.ui-datepicker-close', function(){
	});
});

jQuery( "#qorder_quickview" ).on('show', function(){
 		alert('test');
		var prod_id= jQuery(this).data('id');
 		// console.log(prod_id);
 		
 		var data = { 
					action 	:	'ric_wp_qorder_quickview',
					prod_id	:	prod_id,
				 };
 		jQuery.post(Wp_Ajax.ajaxurl,data,function(response) {
	
			if(response) { 
				//console.log(response,'Response');
			//	jQuery('#quickview_data').html(response);
			
			}else{
				console.log(response);
			}
		});
	});

jQuery('.qorder_qty_order').each(function(e,i){
	//currentValOld[e] = jQuery(this).val();
	
	jQuery(this).change(function(){
		currentVal = jQuery(this).val();
	
		 if(currentVal == 0){
		 	jQuery(this).val(1);
		 	return false;
		 }
	});
});
// jQuery(document).on(".qorder_rship_date").datepicker({
//  	  dateFormat : "yy-mm-dd"
// 	});

jQuery('body').on('focus',".qorder_rship_date", function(){
    jQuery(this).datepicker({
      	dateFormat: 'yy-mm-dd',
      	minDate: 1,
      	showButtonPanel: true,
	    closeText: 'Clear',
	    onClose: function (dateText, inst) {
	        if ($(window.event.srcElement).hasClass('ui-datepicker-close'))
	        {
	            document.getElementById(this.id).value = '';
	        }
	    },
 	  	beforeShowDay:  function(date) {
		    var string = jQuery.datepicker.formatDate('yy-mm-dd', date);
		    var noWeekend = jQuery.datepicker.noWeekends(date);

		    var min_date = jQuery(this).parents('.qorder_rship_date_html').prev('.qorder_eship_date').text();
		    var end_date = new Date(min_date);

		    if( end_date > date ) {
		    	return true;
		    }

	        if (noWeekend[0]) {
	        	return [jQuery.inArray(string, holidays) == -1];
	        }
	        else
	        	return noWeekend;
	    }/*,
       	onSelect: function(date, instance) {

   			var date_updated = jQuery(this).val();
	 		var prod_id= jQuery(this).data('id');
	 		console.log(prod_id);
	 		console.log(date,"Date");
	 	
	 		var data = { 
						action 	:	'ric_wp_qorder_update_date',
						prod_id	:	prod_id,
						date_updated: date_updated,
					};
	 		jQuery.post(Wp_Ajax.ajaxurl,data,function(response) {
		
				if(response) { 
					console.log(response,'Response');
				}else{
					console.log(response);
				}
			});
	    }*/
    });
});