

var holidays = Wp_Ajax.holidays;

var formSubmitting = true;

var start='';

window.addEventListener("beforeunload", function (e) {

	if( formSubmitting == true){ return;}		

    var confirmationMessage = 'It looks like you have been editing something. ';

                          

           

    (e || window.event).returnValue = confirmationMessage; 

    return confirmationMessage; 

});

// console.log(holidays,"holidays");

jQuery(document).ready(function($) {

   // Check if quick order table exists
	// if (jQuery('.quickorder-page').length > 0) {
	// console.log('Quick order table exists.');
	// var $shipmentRadios = $('input[name="select_shipment"]');

	//    if ($shipmentRadios.length === 1) {
    //    	 $shipmentRadios.prop('checked', true);
    // 	}
	// 	var selectedValue = $('input[name="select_shipment"]:checked').val();
	// 	console.log(selectedValue, 'selectedValue');
	
	// 	// Call shipment function on page load
	// 	if (selectedValue !== undefined) {
	// 		qot_shipment_call(selectedValue);
	// 	}
	// }



	$('#search_quick_products').change(function(){

		var element = $(this).find('option:selected'); 

        var type = element.attr("data-type"); 

		var product_get_id = jQuery('#search_quick_products').val();

	 	var product_get_require_qty = jQuery('#qty_order_required').val();



		if(type === 'virtual'){

			$('#qty_order_required').val(1).prop('disabled', true); 

		} else {

			$('#qty_order_required').val('').prop('disabled', false); 

		}

		let total_qt = 0;

	    jQuery('.quickorder-row .qorder_qty_order_html input[data-id^="'+product_get_id+'"]').each(function() {

	        // Get the data-id attribute value

	        let dataId = $(this).data('id');

	        // Get the quantity from the input field

	        let qty = parseFloat($(this).val());

	        // Ensure the values are valid numbers

	        if (!isNaN(qty)) {

	        	total_qt += qty;

	        }

	    });

	 	var data = {

					action 	: 'ric_wp_get_total_quantity',

					product_get_id	: product_get_id,

					product_get_require_qty: product_get_require_qty,

					total_qt : total_qt,

				 };

			

		jQuery('#loader_gif').show();

	 	jQuery('.qot-ric-loader').show();

		jQuery.post(Wp_Ajax.ajaxurl,data,function(response) {

		

		 	if(response) { 

				if(response.message === 'no_price'){
					alert(response.message_txt);
					jQuery('#loader_gif').hide();
					jQuery('.qot-ric-loader').hide();
					return false;
				}

				if(response.message=='success' && response.total_qty != 0){

						jQuery('.max-qty-wrap-total').css('display','block');

						jQuery('strong.max-qty-wrap-count-total').html(response.total_qty);

						jQuery('#loader_gif').hide();

	 					jQuery('.qot-ric-loader').hide();

				}else{

					    // if(response.message=='error' && response.total_qty != 0){

					    // 		jQuery('#qty_order_required').val('');

					    // 		alert(response.message_txt);

					    // 		jQuery('.max-qty-wrap-total').css('display','none');

							  //   jQuery('strong.max-qty-wrap-count-total').html('');

							  //   jQuery('#loader_gif').hide();

			 					// jQuery('.qot-ric-loader').hide();

	 							// return false;

					    // }



					    jQuery('.max-qty-wrap-total').css('display','none');

					    jQuery('strong.max-qty-wrap-count-total').html('');

					    jQuery('#loader_gif').hide();

	 					jQuery('.qot-ric-loader').hide();

					//jQuery('#list_quick_order').append('<tr><td colspan="12" style="text-align: center;">Not found</td></tr>');

				}

				

			}

		});



	});



	jQuery('button#place_order').click(function(){

		jQuery('div#payment').append('<div class="loader-checkout">Please wait<span class="loader__dot">.</span><span class="loader__dot">.</span><span class="loader__dot">.</span></div>');

	});

    var selectedValue = jQuery('input[name="select_shipment"]:checked').val();
	console.log(selectedValue,'selectedValue');
	    // var selectedValue = jQuery('input[name="select_shipment"]:checked').val();
	// console.log(selectedValue,'selectedValue');
	  if($('#list_quick_order tr').length > 0){

	  	qot_shipment_call(selectedValue);

	  }

	

	

	$('.shipping-list .quickorder_shipment').each(function(e){



		$(this).click(function(){

			var currentShipment = $(this).val();

			qot_shipment_call(currentShipment);



		});

		

	});



	$('.cart-collaterals .quickorder_shipment').each(function(e){



		$(this).click(function(){

			var currentShipment = $(this).val();

			qot_shipment_call_cart(currentShipment);



		});

		

	});



	$('#cart_to_checkout').attr

	var qty_updated	= [];

	var prod_id     = [];

	var rship_date  = [];

	var row_changed = [];

	function updateQuickOrderCartTotals(response) {
		if (!response || !response.cart_totals_html) {
			return;
		}

		var $cartTotalSection = jQuery('.cart-total-section');
		var $cartTotals = $cartTotalSection.find('.cart_totals');

		if ($cartTotals.length) {
			$cartTotals.replaceWith(response.cart_totals_html);
		} else {
			$cartTotalSection.prepend(response.cart_totals_html);
		}
	}

	



	var window_height = $(document).height();



	//If table does not load due to slow network

	jQuery('#quick_order_table_rushabh').fadeIn(2000);

	setTimeout(function(){

		jQuery('body.quickorder-page .hfe-before-footer-wrap, .site-footer').fadeIn(1500);

	},600);

	

	$('#update_cart').on('click', function (e) {

		

		formSubmitting = true;

		var shipment_choice =  jQuery('input.quickorder_shipment:checked').val();

		$('#loader_gif').show();

	 	$('.qot-ric-loader').show();

	 	$('.qot-table-section').addClass('back-loader');



		qty_updated = [];

		prod_id = [];

		rship_date = [];

		row_changed = [];

		var i=0;

		$('#list_quick_order tr.quickorder-row ').each(function(index) {

			 var $qtyInput = $(this).find('.qorder_qty_order');
			 var currentQty = $qtyInput.val();
			 var oldQty = $qtyInput.attr('data-old-qty');

			 qty_updated[i] = currentQty;

 			 prod_id[i] 	= $(this).attr('id');

 			 rship_date[i]  = $(this).find('.qorder_rship_date').val();

			 row_changed[i] = String(currentQty) !== String(oldQty) ? 1 : 0;

 		i++;

		});

		console.log(prod_id);

		var data = { 

			action 	: 'ric_wp_qorder_update_qty',

			prod_id	: prod_id,

			qty_updated : qty_updated,

			rship_date : rship_date,

			row_changed : row_changed,

			shipment_choice : shipment_choice

		};



		jQuery.post(Wp_Ajax.ajaxurl, data, function(response) {

			if(response) { 



				if(response.message == 'success') {

					console.log(response,'response');

					if (response.data) {
						jQuery('#list_quick_order').html(response.data);
					}

					updateQuickOrderCartTotals(response);

					$('#loader_gif').hide();

					$('.qot-ric-loader').hide();

					$('.qot-table-section').removeClass('back-loader');

					jQuery('#cart_to_checkout').show();
					jQuery('.shipping-selection').show();



					// $('#loader_gif').hide();

					// $('.qot-ric-loader').hide();

					// $('.qot-table-section').removeClass('back-loader');

					// jQuery('#cart_to_checkout').show();

					// location.reload();

				}

			}

		});

		 	

	});



		jQuery(document).on('keyup', '.qorder_qty_order', function (e) {



	 jQuery('#cart_to_checkout').hide();

	 jQuery('.shipping-selection').hide();

   	  if (e.which === 46) return false;

			}).on('input', '.qorder_qty_order', function () {

		    var self = this;

		    setTimeout(function () {

		        if (self.value.indexOf('.') != -1) self.value = parseInt(self.value, 10);

		    }, 0);

	 });



    jQuery('#search_quick_products').select2({		



		data: [],

        query: function (q) {



            jQuery.ajax({

                url: Wp_Ajax.ajaxurl,

                data: {action : 'ric_wp_qorder_custom_search_products', search_text: q.term},

                dataType: 'json',

                type: 'POST',

                success: function (data) {

                	formSubmitting = false;

                	if( data.length !== 0 ) {

                		 q.callback({results: data.results});

                	}

                },       

            });

        },

        width: '500px',

        placeholder: 'Select Product'

	});

   

   	checkout_btn();



    jQuery(".qorder_rship_date").datepicker({

     	dateFormat: 'yy-mm-dd',

     	minDate: 1,

      	showButtonPanel: true,

	    closeText: 'Clear',

	    onClose: function (dateText, inst) {

	        if ($(window.event.srcElement).hasClass('ui-datepicker-close'))

	        {

	            document.getElementById(this.id).value = '';

	        }

	        jQuery('#cart_to_checkout').hide();

	    },

 		beforeShowDay:  function(date){

 			

	    	var string = jQuery.datepicker.formatDate('yy-mm-dd', date);

	    	var noWeekend = jQuery.datepicker.noWeekends(date);



		    var min_date = $(this).parents('.qorder_rship_date_html').prev('.qorder_eship_date').text();

		    var end_date = new Date(min_date);



		    if( end_date > date ) {

		    	return true;

		    }



	        if (noWeekend[0]) {

	        	return [jQuery.inArray(string, holidays) == -1];

	        }

	        else

	        	return noWeekend;

	    },

 	    onSelect: function(date, instance) {

 	    	formSubmitting = false;

 	    	jQuery('#cart_to_checkout').hide();

 	    	jQuery('.shipping-selection').hide();

	     }

	});







 	// jQuery('.split_qty').each(function(index) {



 	// 	jQuery(this).click(function(){



		// 	var get_qty = jQuery(this).parent().parent().parent().find('.qorder_qty_order').val();

		// 	var product_id = jQuery(this).parent().parent().parent().find('.qorder_qty_order').attr('data-id');



		 

		//  	jQuery('#loader_gif').show();

		//  	jQuery('.qot-ric-loader').show();



		// 	var data = {

		// 				action 	: 'ric_wp_split_qty_quick_order',

		// 				get_qty	: get_qty,

		// 				product_id: product_id,

						

		// 			 };

				

		// 	jQuery.post(Wp_Ajax.ajaxurl,data,function(response) {

			

		// 	console.log(response,'response');



		// 		if(response) { 

				

		// 			if(response.message=='success'){

		// 				console.log(response);

		// 				var currency = response.qorder_currency

		// 				jQuery('#list_quick_order').html(response.data);



		// 				jQuery('#loader_gif').hide();

		// 				jQuery('.qot-ric-loader').hide();



		// 			}else{

		// 				jQuery('#list_quick_order').append('<tr><td colspan="12" style="text-align: center;">Not found</td></tr>');

		// 			}

				

		// 		}

		// 	});

 	// 	});



 	// });





 	jQuery(document).on('click', '.split_qty',function(index) {



 	

			var $row = jQuery(this).closest('.quickorder-row');

			var get_qty = $row.find('.qorder_qty_order').val();

			var product_id = $row.find('.qorder_qty_order').attr('data-id');
			var split_product_parent_id = String(product_id).split('_')[0];

			

			console.log(product_id,'product_id');

			jQuery('#quickview_data1-'+product_id).show();

			jQuery('.cng-btn-btn-wrap-'+product_id).attr({

			    'data-qty': get_qty,

			    'data-product-parent-id':split_product_parent_id,

			    'data-id': product_id // Add more attributes if needed

			});



		 	

		 // 	jQuery('#loader_gif').show();

		 // 	jQuery('.qot-ric-loader').show();



			// var data = {

			// 			action 	: 'ric_wp_split_qty_quick_order',

			// 			get_qty	: get_qty,

			// 			product_id: product_id,

			// 		 };

				

			// jQuery.post(Wp_Ajax.ajaxurl,data,function(response) {



			// 	if(response) { 

			// 		if(response.message=='success'){

			// 			var currency = response.qorder_currency

			// 			jQuery('#list_quick_order').html(response.data);



			// 			jQuery('#loader_gif').hide();

			// 			jQuery('.qot-ric-loader').hide();



			// 		}else{

			// 			jQuery('#list_quick_order').append('<tr><td colspan="12" style="text-align: center;">Not found</td></tr>');

			// 			jQuery('#loader_gif').hide();

			// 			jQuery('.qot-ric-loader').hide();

			// 		}

				

			// 	}

			// });

 	



 	});



 	jQuery(document).on('click', '.popup-spilt-dsg-wrap-con',function(index) {

 		jQuery('#qorder_spilt_orderdata .close').trigger('click');

 		jQuery(this).parent('modal-body').hide();

 		 var currunt_id = jQuery(this).attr('data-id');

 		 var split_quantity = jQuery(this).siblings('#split-quantity').val();

 		 split_quantity = parseInt(split_quantity, 10);



 			//var split_quantity = jQuery('#split-quantity').val();

 			var data_product_parent_id = jQuery(this).attr('data-product-parent-id');

 			var data_qty = jQuery(this).attr('data-qty');

 			data_qty = parseInt(data_qty, 10);

 			var child_data_id = jQuery(this).attr('data-id');

 			var parentId  = jQuery(this).attr('data-product-parent-id');

 			 // Find all input elements with data-id starting with parentProductId but not exactly equal to parentProductId

		    // jQuery('input.qorder_qty_order').each(function() {

		    //     var dataId = jQuery(this).attr('data-id');

		        

		    //     // Check if the data-id starts with the parentProductId but is not exactly the same

		    //     if (dataId !== parentProductId && dataId.startsWith(parentProductId)) {

		    //         var qtyValue = jQuery(this).val(); // Get the value of this input

		    //         console.log('ID: ' + dataId + ' - Quantity: ' + qtyValue); // Output for testing purposes

		    //         // You can now process or use this value as needed

		    //     }

		    // });

		    let orderData = [];



		    // Loop through all inputs with the class 'qorder_qty_order'

		    $('#list_quick_order .qorder_qty_order').each(function() {

		        // Get the data-id and quantity from the input field

		        let dataId = $(this).data('id');

		        let qty = $(this).val();



		        // Convert dataId to string to avoid the split error

		        dataId = String(dataId);



		        // Get the parent id from the data-id by splitting the data-id on underscore '_'

		        let currentParentId = String(dataId).split('_')[0];



		        // If the currentParentId matches the clicked parentId, add it to the array

		        if (currentParentId === parentId) {

		            orderData.push({

		                id: dataId,

		                quantity: qty

		            });

		        }

		    });

		     const idToRemove = child_data_id;

		    orderData = orderData.filter(item => item.id !== idToRemove);

			

 			if (!split_quantity && split_quantity !== 0) {

			    alert('Please enter quantity.');

			    return false;

			}

			if(split_quantity <= 0){

				alert('Please enter feasible quantity value.');
				return false;
			}

			

			if (data_qty <= split_quantity){

			    alert('Please enter value less then quantity value.');

			    return false;

			}

			

 			jQuery('#loader_gif').show();

		 	jQuery('.qot-ric-loader').show();



			var data = {

						action 	: 'ric_wp_split_qty_quick_order',

						get_qty	: split_quantity,

						product_id: child_data_id,

						old_qty : data_qty,

						qucik_orders_qty: orderData,

					 };

					// console.log(data,"DATA");

			jQuery.post(Wp_Ajax.ajaxurl,data,function(response) {



				if(response) { 

					jQuery('#qorder_spilt_orderdata .close').trigger('click');

					if(response.message=='success'){

						jQuery('#qorder_spilt_orderdata .close').trigger('click');

						var currency = response.qorder_currency

						jQuery('#list_quick_order').html(response.data);



						jQuery('#loader_gif').hide();

						jQuery('.qot-ric-loader').hide();



					}else{

						jQuery('#qorder_spilt_orderdata .close').trigger('click');

						jQuery('#list_quick_order').append('<tr><td colspan="12" style="text-align: center;">Not found</td></tr>');

						jQuery('#loader_gif').hide();

						jQuery('.qot-ric-loader').hide();

					}

				

				}

			});

 	});		



 	jQuery(document).on('click',"button.close.close-btn-btn-ctm", function(index){

 				

 		 var targetId = jQuery(this).attr('data-target');

    console.log(targetId,"targetId")

    	jQuery('#quickview_data1-' + targetId).hide();



 	});



 	

 	jQuery(document).on('click', '.split_qty_undo',function(index) {



			var $row = jQuery(this).closest('.quickorder-row');

			var get_qty = $row.find('.qorder_qty_order').val();

			var product_id = $row.find('.qorder_qty_order').attr('data-id');
			var oldRowid = jQuery(this).attr('data-old-row-id');

			var splitId = product_id.split('_');

			var o_id = splitId[0];

			

			var p_qty = jQuery('#row-'+o_id).find('.qorder_qty_order').val();

			

			// t_qty=p_qty;

			// var product_chunk=[];

			// jQuery("tr[id^='row-"+o_id+"_']").each(function (index){

			// 	var qty = jQuery(this).find('.qorder_qty_order').val();

			// 	t_qty = parseInt(t_qty) + parseInt(qty);

			// 	product_chunk[index] = o_id+'_'+index;

			// });

				var t_qty = 0;
				var product_chunk = [];

				jQuery("tr[id^='row-"+o_id+"']").each(function (index){

					var rowId = jQuery(this).attr('id').replace('row-', '');

					if (rowId !== o_id && rowId.indexOf(o_id + '_') !== 0) {
						return;
					}

					var qty = Number(jQuery(this).find('.qorder_qty_order').val()) || 0;

					t_qty += qty;

					product_chunk.push(rowId);
				});



			console.log(product_chunk);

		 

		 	jQuery('#loader_gif').show();

		 	jQuery('.qot-ric-loader').show();



			var data = {

						action 	: 'ric_wp_split_undo_quick_order',

						get_qty	: get_qty,

						product_id: product_id,

						t_qty: t_qty,

						o_id: o_id,

						product_id: product_id,
						
						oldRowid: oldRowid,

						product_chunk: product_chunk

					 };

				

			jQuery.post(Wp_Ajax.ajaxurl,data,function(response) {



				if(response) { 

				

					if(response.message=='success'){

						

						var currency = response.qorder_currency

						jQuery('#list_quick_order').html(response.data);

						jQuery('#loader_gif').hide();

						jQuery('.qot-ric-loader').hide();



					}else{

						jQuery('#list_quick_order').append('<tr><td colspan="12" style="text-align: center;">Not found</td></tr>');

					}

				

				}

			});

 	



 	});



 	/* Split Quantity */

		jQuery('#add_quick_order').click(function(){



			var get_id = jQuery('#search_quick_products').val();

			var get_require_qty = jQuery('#qty_order_required').val();

			var require_qty = parseFloat(jQuery('#qty_order_required').val());

			var max_qty = jQuery('.max-qty-wrap-count-total').text();

			if(get_id==''){

				alert('Please select Product');

				return false;

			}



			if(get_require_qty==''){

				alert('Please select Quantity');

				return false;

			}

			let total_qt = 0;

			jQuery('.quickorder-row .qorder_qty_order_html input[data-id^="'+get_id+'"]').each(function() {

				// Get the data-id attribute value

				let dataId = $(this).data('id');

				// Get the quantity from the input field

				let qty = parseFloat($(this).val());

				// Ensure the values are valid numbers

				if (!isNaN(qty)) {

					total_qt += qty;

				}

			});

			total_qt += require_qty;
			

			// if(max_qty != ''){

			//     if( (max_qty < get_require_qty && total_qt == 0) || ( total_qt != 0 && total_qt > max_qty)){

			//     	jQuery('#qty_order_required').val('');

			//  		alert('Please enter value less then maximum Quantity');

			//  		return false;

			//  	}

			// }else{

			// 		jQuery('#qty_order_required').val('');

			//  		alert('Sorry, this product quantity not available.');

			//  		return false;

			// }

			jQuery('#loader_gif').show();

			jQuery('.qot-ric-loader').show();

			var data = {

						action 	: 'ric_wp_get_quick_order',

						get_id	: get_id,

						get_require_qty: get_require_qty,

					};

				

			jQuery.post(Wp_Ajax.ajaxurl,data,function(response) {

					

				if(response) { 

					

					if(response.message=='success'){

						// console.log(response);




						var currency = response.qorder_currency

						jQuery('#list_quick_order').html(response.data);

						updateQuickOrderCartTotals(response);

						

						checkout_btn();


						
							// jQuery("#search_quick_products").select2('val', 'Select Products');

						// jQuery("#search_quick_products")[0].selectedIndex = 0; 

						var quick_order=jQuery('#list_quick_order tr.quickorder-row').length;



						if( quick_order > 0 ){

							jQuery('.shipping-section').show();

						}

						var shipment_choice =  jQuery('input.quickorder_shipment:checked').val();

					

						if(quick_order && shipment_choice){

							// if(shipment_choice != 'custom-shipment'){

								

								qot_shipment_call(shipment_choice);	

							// }	

							jQuery('#cart_to_checkout').show();

						}else{

							jQuery('#cart_to_checkout').hide();

						}

						jQuery('#loader_gif').hide();

						jQuery('.qot-ric-loader').hide();

						

						jQuery('.shipping-list').show();

						jQuery('.cart-total-section').show();

						jQuery(document.body).trigger('wc_fragment_refresh');


					}else{

						jQuery('#list_quick_order').append('<tr><td colspan="12" style="text-align: center;">Not found</td></tr>');

					}
					
					

				}

			});

		});







 	jQuery(document).on('click','.delete_order',function(){

 		

 		var rowId = $(this).closest('.quickorder-row').attr('id');

 		var modifiedId = rowId.replace('row-', '');

 		jQuery('#loader_gif').show();

	 	jQuery('.qot-ric-loader').show();

 		var prod_id= jQuery(this).data('id');
 		var prod_qty= jQuery(this).parents('.quickorder-row').find('.qorder_qty_order_html .qorder_qty_order').val();
		console.log('prod_qty',prod_qty);

 		if(modifiedId != prod_id){

 			    var prod_id = modifiedId; 

 		}

 		var data = { 

					action 	:	'ric_wp_delete_order',

					prod_id	:	prod_id,

					prod_qty :	prod_qty,

				 };

 		jQuery.post(Wp_Ajax.ajaxurl,data,function(response) {

	

			if(response) { 

				

				if(response.message=='success'){

					checkout_btn();

					jQuery('#error_response').html('<p style="text-align: center;">Item is deleted... </p>');

					 // console.log(response.data);

					// jQuery('#update_cart').trigger('click');

					 

					setTimeout(function(){

					//jQuery('#update_cart').click();

						// jQuery('#error_response').html('');

						// jQuery('#list_quick_order').html(response.data);

						// jQuery('#loader_gif').hide();

	 				// 	jQuery('.qot-ric-loader').hide();

					},1500);

					location.reload();

				}

			

			}else{

				// console.log(response);

				jQuery('#loader_gif').hide();

				jQuery('.qot-ric-loader').hide();

			}

		});

 	});



 	

 	jQuery("#qorder_quickview").on('shown.bs.modal', function (e) {

	   jQuery('#loader_gif_modal').show();

	   	var prod_id = jQuery(e.relatedTarget).data('id');

 		

 		var data = { 

					action 	: 'ric_wp_qorder_quickview',

					prod_id	: prod_id,

				 };

 		jQuery.post(Wp_Ajax.ajaxurl,data,function(response) {

	

			if(response) { 

				jQuery('#loader_gif_modal').hide();

				jQuery('#quickview_data').html(response);



			

			}else{

				// console.log(response);

				jQuery('#loader_gif_modal').hide();

			}

		});

	});





 	jQuery(document).on('change','.qorder_qty_order',function(){

 		formSubmitting = false;

 		jQuery('#cart_to_checkout').hide();

 		jQuery('.shipping-selection').hide();

 		

 	});



 	jQuery('#cart_to_checkout').click(function(){

 		var auth_status = jQuery('#auth_status').val();

 		var total_rows  = jQuery('tbody#list_quick_order tr').length;

 		

 		if(auth_status == true){

 			// var proc_time = ( 20 / total_rows);

			var proc_time = 1.5;

 		

 		}else{

			var proc_time = 5;

 			//  if(total_rows <= 3){

 			//  	var proc_time = ( 50 / total_rows);

 			//  }else{

 			//  	var proc_time = ( 100 / total_rows);

 			//  } 			

 		}

 		

 		// if(total_rows > 3){

 		// 	proc_time = proc_time - (total_rows-1);

 		// }

 		

  

 		// for (var i = 0; i < proc_time; i++) {

 			// var percent = ( i / proc_time * 100) +"%";

			

 			var progression = 0, progress = setInterval(function() 

		  	{

		  		// $('#progress .progress-text').text(Math.round(progression) + '%');

		  		// $('.progress-bar').css({'width':Math.round(progression)+'%'});



		  		if( progression >= 0 && progression <= 12.5 ){

					jQuery('.progress-bar').css({'width': '12.5%'});

					jQuery('.step-1').addClass('active');

		  			var step_1 = jQuery('.step-1').attr('data-process');

		  			jQuery('.step-1').text(step_1);

		  			jQuery('.step-1').addClass('checkicon');

				}



				if( progression > 12.5 && progression <= 25 ){

					jQuery('.progress-bar').css({'width': '25%'});

				}



				if( progression > 25 && progression <= 37.5 ){

					jQuery('.progress-bar').css({'width': '37.5%'});

					jQuery('.step-2').addClass('active');

					var step_2 = jQuery('.step-2').attr('data-process');

					jQuery('.step-2').text(step_2);

				 	jQuery('.step-2').addClass('checkicon');

				} 



				if( progression > 37.5 &&progression <= 50 ){

					jQuery('.progress-bar').css({'width': '50%'});

				

				}



				if( progression > 50 && progression <= 62.5 ){

					jQuery('.progress-bar').css({'width': '62.5%'});

					jQuery('.step-3').addClass('active');

		  			var step_3 = jQuery('.step-3').attr('data-process');

		  			jQuery('.step-3').text(step_3);

					jQuery('.step-3').addClass('checkicon');

				}



				if( progression > 62.5 && progression <= 75.5 ){

					jQuery('.progress-bar').css({'width': '75.5%'});

					

				} 

				

				if( progression > 75.5 && progression <= 87.5 ){

					jQuery('.progress-bar').css({'width': '87.5%'});

					jQuery('.step-4').addClass('active');

		  			var step_4 = jQuery('.step-4').attr('data-process');

		  			jQuery('.step-4').text(step_4);

		  			jQuery('li.steps.step-4').html(step_4+'<span class="loader__dot"></span><span class="loader__dot"></span><span class="loader__dot"></span>');

					jQuery('.step-4').addClass('checkicon');

				}

				

				if( progression > 87.5 && progression <= 100 ){

					jQuery('.progress-bar').css({'width': '100%'});

				}



		  		// if(progression >= 5 && progression <= 15){

		  			

		  		// }



		  		// if(progression >= 20 && progression <= 35){







		  		// }



		  		// if(progression >= 40 && progression <= 60){

		  			

		  							

				// }

				// if(progression >= 60 && progression <= 70){

		  			

		  			



		  		// }



		  		if(Math.round(progression) == 100 || Math.round(progression) >= 100) {

		  			

		  			clearInterval(progress);

		  			

		  		} else{

		  			progression += proc_time;	

		  		}

		  		



		  	}, 50);

			

 			

 		//}

 		

 		

 		

		start = Date.now();

		jQuery('.container-progressbar').show();

 		formSubmitting = true;

 		var shipment_choice =  jQuery('input.quickorder_shipment:checked').val();



 		// jQuery('#loader_gif').show();

 		// jQuery('.qot-ric-loader').show();

 		

 		var data = { 

					action: 'qot_ric_add_tocart',

					'shipment_choice': shipment_choice

				   };



		// jQuery.post(Wp_Ajax.ajaxurl,data,function(response) {

		//     var progression = 0,

		   



		// 	if(response) { 

				

		// 		if(response.message=='success'){



		// 			jQuery('#loader_gif').hide();

		// 			jQuery('.qot-ric-loader').hide();



		// 			window.location.href = response.url;

		// 		}

				

		// 	}else{

		// 		// console.log(response);

		// 	}



		// });



		/* Progress bar*/

				   

		$.ajax({

			  type: 'POST',

			  url: Wp_Ajax.ajaxurl,

			  data:{ 

					action: 'qot_ric_add_tocart',

					'shipment_choice': shipment_choice

				   },

			  beforeSend: function(XMLHttpRequest)

			  {

			  	

			  },

			  success: function(response){

				if(response) { 

						if(response.message=='success'){





							console.log('end');

							console.log( "Request took: " + ( Date.now() - start ) );

							setTimeout(function(){

								window.location.href = response.url;

							},2000);

						}

					}

			  }

		});





 	});





 	function checkout_btn(){

 		var rowCount = jQuery('tbody#list_quick_order tr').length;

		if(rowCount==0){

			jQuery('.qot_ric_checkout').hide();

		}else{

			jQuery('.qot_ric_checkout').show();

		}



	}



	jQuery(document).on('click', '.ui-datepicker-close', function(){

	});





	jQuery(document).on('change', '.qorder_qty_order', function() {

    var maxQuantity = parseFloat(jQuery(this).attr('data-max-qty')); // Get the max quantity

    var parentId = String(jQuery(this).data('id')).split('_')[0]; // Get only the parent ID (before _)

    var data_qty = parseFloat(jQuery(this).val()); // Current input value

    var data_old_qty = parseFloat(jQuery(this).attr('data-old-qty'));

    var totalQty = 0;



    // Find all input fields with data-id that start with the parentId

    jQuery('input.qorder_qty_order[data-id^="'+parentId+'"]').each(function() {

        // Get the quantity from the input field

        let qty = parseFloat(jQuery(this).val());



        // Ensure the values are valid numbers

        if (!isNaN(qty)) {

            totalQty += qty;

        }

    });



    // Check if the total quantity exceeds the maximum allowed

    if (maxQuantity < data_qty || totalQty > maxQuantity) {

        // alert('Error: Total quantity exceeds the maximum allowed limit of ' + maxQuantity);



        // Optionally revert the last change

        // jQuery(this).val(data_old_qty);
        jQuery(this).val(data_qty);

        // return false;

    }

});







});



jQuery( "#qorder_quickview" ).on('show', function(){



	var prod_id= jQuery(this).data('id');

 		// console.log(prod_id);

 		

 		var data = { 

 			action 	:	'ric_wp_qorder_quickview',

 			prod_id	:	prod_id,

 		};

 		jQuery.post(Wp_Ajax.ajaxurl,data,function(response) {



 			if(response) { 

				//console.log(response,'Response');

			//	jQuery('#quickview_data').html(response);

			

		}else{

				// console.log(response);

			}

		});

 	});



jQuery('.qorder_qty_order').each(function(e,i){

	//currentValOld[e] = jQuery(this).val();

	

	jQuery(this).change(function(){

		currentVal = jQuery(this).val();

	

		 if(currentVal == 0){

		 	jQuery(this).val(1);

		 	return false;

		 }

		

	});

});



// jQuery(document).on(".qorder_rship_date").datepicker({

//  	  dateFormat : "yy-mm-dd"

// 	});



jQuery(document).on('keyup', '.qorder_qty_order', function(e) {

	

	 jQuery('#cart_to_checkout').hide();

	 jQuery('.shipping-selection').hide();

  });



jQuery('body').on('focus',".qorder_rship_date", function(){

    jQuery(this).datepicker({

      	dateFormat: 'yy-mm-dd',

      	minDate: 1,

      	showButtonPanel: true,

	    closeText: 'Clear',

	    onClose: function (dateText, inst) {

	    	jQuery('#cart_to_checkout').hide();

	        if (jQuery(window.event.srcElement).hasClass('ui-datepicker-close'))

	        {

	            document.getElementById(this.id).value = '';

	        }

	         jQuery('#cart_to_checkout').hide();

	    },

 	  	beforeShowDay:  function(date) {



		    var string = jQuery.datepicker.formatDate('yy-mm-dd', date);

		    var noWeekend = jQuery.datepicker.noWeekends(date);



		    var min_date = jQuery(this).parents('.qorder_rship_date_html').prev('.qorder_eship_date').text();

		    var end_date = new Date(min_date);



		    if( end_date > date ) {

		    	return true;

		    }



	        if (noWeekend[0]) {

	        	return [jQuery.inArray(string, holidays) == -1];

	        }

	        else

	        	return noWeekend;

	    },

       	onSelect: function(date, instance) {

       		formSubmitting = false;

 		jQuery('#cart_to_checkout').hide();

 		jQuery('.shipping-selection').hide();

   // 			var date_updated = jQuery(this).val();

	 	// 	var prod_id= jQuery(this).data('id');

	 	// 	console.log(prod_id);

	 	// 	console.log(date,"Date");

	 	

	 	// 	var data = { 

			// 			action 	:	'ric_wp_qorder_update_date',

			// 			prod_id	:	prod_id,

			// 			date_updated: date_updated,

			// 		};

	 	// 	jQuery.post(Wp_Ajax.ajaxurl,data,function(response) {

		

			// 	if(response) { 

			// 		console.log(response,'Response');

			// 	}else{

			// 		console.log(response);

			// 	}

			// });

	    }

    });



});





function qot_shipment_call(currentShipment) {

	console.log('test...');

	jQuery('.steps').removeClass('active');

	jQuery('.step-1').addClass('active');

	jQuery('#loader_gif').show();

 	jQuery('.qot-ric-loader').show();



 	if(currentShipment == 'custom-shipment'){

 		// jQuery('#loader_gif').hide();

 	    // jQuery('.qot-ric-loader').hide();

		jQuery('.qorder_rship_date').removeClass('readOnly');

		jQuery('.split_qty').removeClass('readOnly');

		jQuery('.split_qty').prop('disabled', false);

	//	return false;



	}else{

		// jQuery('#loader_gif').hide();

 	    // jQuery('.qot-ric-loader').hide();

		jQuery('.split_qty').prop('disabled', true);

		jQuery('.split_qty').addClass('readOnly');

		jQuery('.qorder_rship_date').addClass('readOnly');

	}

	

	var parentData = {};



// Loop through each row that matches the pattern `row-<id>` and its related rows

	jQuery("tr[id^='row-']").each(function() {

		// Get the full row ID, e.g., "row-19272", "row-19272_0"

		var rowId = jQuery(this).attr('id');



		// Extract the parent ID from the row ID, e.g., "19272" from "row-19272" and "row-19272_0"

		var parentId = rowId.split("_")[0].replace('row-', '');  // This extracts the main part before '_', e.g., "19272"



		// Get the quantity input for this row

		var quantity = parseFloat(jQuery(this).find(".qorder_qty_order").val()) || 0;



		// If the parentId is not yet in the object, initialize it

		if (!parentData[parentId]) {

			parentData[parentId] = {

				totalQuantity: 0,    // To store the total quantity

				childRowIds: []      // To store the child row IDs

			};

		}



		// Add the quantity to the total for this parent ID

		parentData[parentId].totalQuantity += quantity;



		// Store the child row IDs (if any)

		if (rowId.includes("_")) {

			// Extract only the child part, e.g., "19272_0", without the "row-" prefix

			var childRowId = rowId.replace('row-', '');

			parentData[parentId].childRowIds.push(childRowId);  // Push the child row ID to the array

		}

	});



// Now `parentData` holds the total quantity and child rows for each parent ID

	var data = { 

		action 	: 'ric_wp_qorder_shipment',

		selectedShipment	: currentShipment,

		parentData : parentData,



	};



	jQuery.post(Wp_Ajax.ajaxurl, data, function(response) {

		

		if(response.message == 'success') { 

		console.log(response,"RES..");

			jQuery('#list_quick_order').html(response.data);

			jQuery('#loader_gif').hide();

			jQuery('.qot-ric-loader').hide();



			var shipment_choice =  jQuery('input.quickorder_shipment:checked').val();

			if(shipment_choice){

				jQuery('#cart_to_checkout').show();

			}



			}

		});

}



function qot_shipment_call_cart(currentShipment) {

		

	jQuery('#loader_gif').show();

 	jQuery('.qot-ric-loader').show();





	var data = { 

		action 	: 'ric_wp_qorder_shipment_cart',

		selectedShipment	: currentShipment,



	};



	jQuery.post(Wp_Ajax.ajaxurl, data, function(response) {

		

		 if(response.message == 'success') { 
		 	jQuery(document.body).trigger('wc_fragment_refresh');
		 	location.reload();

		// 	jQuery('#list_quick_order').html(response.data);

		// 	jQuery('#loader_gif').hide();

		// 	jQuery('.qot-ric-loader').hide();



		// 	var shipment_choice =  jQuery('input.quickorder_shipment:checked').val();

		// 	if(shipment_choice){

		// 		jQuery('#cart_to_checkout').show();

		// 	}



		 }

	});

}
