<?php
if (session_status() === PHP_SESSION_NONE) {
    $lifetime = 86400;
    session_set_cookie_params($lifetime);
    //  setcookie('quickorder',$_SESSION['quickorder'],time()+$lifetime);
    session_start();
}


//remove_action( 'pre_get_posts', array('B2BE_Catalogue_Visibility','modify_shortcode_query'), 20);


function modify_shortcode_query_2($query)
{
    global $qot_ric_model;
    if (! $q->is_main_query()) {
        return;
    }
    if (! $q->is_post_type_archive()) {
        return;
    }

    if (! is_admin() && is_shop()) {
        if ($query->query['post_type'] == 'product') {
            $exclude_ids = $qot_ric_model->get_hidden_product_id();
            $query->set('post__not_in', $exclude_ids);
        }
    }
}

/**
 * Shortcode of Quick order table
 *
 *
 * @package Quick Order Table
 * @since 1.0.0
 */
add_shortcode('quick_order', 'ric_product_table');
function ric_product_table()
{
    if (is_admin()) return;

    global $wpdb, $qot_ric_scripts, $ric_wp_products, $default_fields, $field, $qot_ric_model;

    $exclude_ids = $qot_ric_model->get_hidden_product_id();
    $exclude_ids = array_unique($exclude_ids);
    $qot_ric_options = get_option('qot_ric_options');
    $qot_ric_styles  = get_option('qot_ric_styles');
    $qot_ric_scripts->qot_ric_scripts_styles();

    ob_start();


    // Prepare the SQL query
    $query = $wpdb->prepare(
        "SELECT * FROM {$wpdb->posts} WHERE post_type = 'product' AND ID NOT IN (%s)",
        implode(',', $exclude_ids)
    );
    // Run the query
    $ric_shown_products = $wpdb->get_results($query);



    if (isset($_SESSION['steps']) && !empty($_SESSION['steps'])) {
        $steps = $_SESSION['steps'];
    } else {
        $steps = 1;
    } ?>

    <div class="container">

        <div id="quick_order_table_rushabh" style="display:none">
            <div class="product dropdown_wrap">
                <div class="max-qty-wrap-total" style="display:none"><strong><?php esc_html_e('Max Qty :'); ?></strong> <strong class="max-qty-wrap-count-total"></strong></div>
                <?php if (!empty($ric_shown_products)) { ?>
                    <select id="search_quick_products">
                        <option value=""><?php esc_html_e('Select Product'); ?></option>
                        <?php

                        foreach ($ric_shown_products as $key => $ric_shown_product) {

                            // $ric_shown_products->the_post();

                            $product_id =  $ric_shown_product->ID;
                            $product = wc_get_product($product_id);
                            $sku = $product->get_sku();
                            $get_product_type = get_post_meta($product_id, '_virtual', true);
                            $virtual_product = 'physical';
                            if ($get_product_type == 'yes') {
                                $virtual_product = 'virtual';
                            }
                        ?>

                            <option data-type="<?php echo $virtual_product; ?>" value="<?php echo $product_id; ?>">
                                <?php echo '[' . $sku . '] ' . get_the_title($product_id); ?>
                            </option>

                        <?php
                            // wp_reset_postdata();
                        } ?>


                    </select>
                    <div class="qorder_qty_order_wrap">
                        <input type="number" id="qty_order_required" placeholder="Qty" name="qty-order-required" min="1" onkeypress="return event.charCode >= 48" class="qty_order_required" value="">
                    </div>
                    <button id="add_quick_order"><?php esc_html_e('Add Product'); ?></button>
                <?php } ?>
            </div>
        </div>
        <div class="qot-table-section">
            <div id="error_response"></div>
            <table class="qot">
                <thead>
                    <tr>
                        <?php
                        $body_row = array();
                        $class = '';
                        foreach ($qot_ric_options as $key => $options) {
                            if (isset($options['status']) && $options['status'] == 1) {
                                $class = 'hide-rows';
                            } else {
                                $class = '';
                            }
                            // if(in_array($key,[3,4,5,6]) ){
                            //     $class = 'hide-rows';
                            // }else{
                            //     $class = '';
                            // }

                            $body_row[] = $key; ?>

                            <th class="<?php echo $class; ?>" style="<?php echo isset($qot_ric_styles['th_bg_color']) ? 'background-color: ' . $qot_ric_styles['th_bg_color'] . ';' : ''; ?><?php echo isset($qot_ric_styles['th_text_color']) ? 'color: ' . $qot_ric_styles['th_text_color'] . ';' : ''; ?>"> <?php

                                                                                                                                                                                                                                                                                                        if (!empty($options['field'])) {

                                                                                                                                                                                                                                                                                                            if ($options['label'] == 'Action') {
                                                                                                                                                                                                                                                                                                        ?>
                                        <ul class="qot-split-delivery">
                                            <li>
                                                <?php esc_html_e('Split for Early Delivery'); ?>
                                            </li>
                                            <li><?php echo $options['field']; ?></li>
                                        </ul>
                                    <?php
                                                                                                                                                                                                                                                                                                            } else {
                                                                                                                                                                                                                                                                                                                echo $options['field'];
                                                                                                                                                                                                                                                                                                            }
                                                                                                                                                                                                                                                                                                        } else {

                                                                                                                                                                                                                                                                                                            if ($default_fields[$key]['label'] == 'Action') {
                                    ?>
                                        <ul class="qot-split-delivery">
                                            <li>
                                                <?php esc_html_e('Split for Early Delivery'); ?>
                                            </li>
                                            <li><?php $default_fields[$key]['field']; ?></li>
                                        </ul>
                                <?php
                                                                                                                                                                                                                                                                                                            } else {
                                                                                                                                                                                                                                                                                                                echo $default_fields[$key]['field'];
                                                                                                                                                                                                                                                                                                            }
                                                                                                                                                                                                                                                                                                        }
                                ?>
                            </th>

                        <?php }  ?>

                    </tr>
                </thead>
                <tbody id="list_quick_order">
                    <div class="qot-ric-loader">
                        <div id="loader_gif"></div>
                    </div>
                    <?php



                    if (isset($_SESSION['quickorder']) && is_array($_SESSION['quickorder']) && count($_SESSION['quickorder']) > 0) {
                        $tempOrder = array();
                        $qorder_eship_date = '';
                        $qorder_rship_date = '';

                        $j = 0;
                        $exist_order_id = array();

                        $noOfRows = count($_SESSION['quickorder']);

                        foreach ($_SESSION['quickorder'] as $prod_id => $qorder) {
                            global $field;
                            $req_date = false;
                            $product_id = qot_get_product_id($prod_id);
                            $product    = wc_get_product($product_id);
                            if ($product) {


                                $qorder_qty_stock = $product->get_stock_quantity();
                                $qty_order = qot_ric_get_product_qty($prod_id);
                                $qorder_qty_consider = qot_ric_get_exist_consider_qty($prod_id);

                                $ric_wp_wip_qty = get_post_meta($product_id, '_ric_wp_wip_qty', true);
                                $ric_wp_wip_date = get_post_meta($product_id, '_ric_wp_wip_date', true);
                                //$unit_price = $product->get_price();

                                if ($product->is_on_sale()) {
                                    $unit_price = $product->get_sale_price();
                                } else {
                                    if (!empty($product->get_regular_price())) {
                                        $unit_price = $product->get_regular_price();
                                    } else {
                                        $unit_price = 0;
                                    }
                                }

                                $i = 0;
                                foreach ($field as $key) {
                                    if ($key == 'qorder_lead_time') {
                                        $_SESSION['quickorder'][$prod_id][$i]['qorder_lead_time'] = qot_get_lead_time($product_id);
                                    }

                                    if ($key == 'qorder_qty_stock') {
                                        $_SESSION['quickorder'][$prod_id][$i]['qorder_qty_stock'] = $qorder_qty_stock;
                                    }

                                    if ($key == 'qorder_qip_stock') {
                                        $_SESSION['quickorder'][$prod_id][$i]['qorder_qip_stock'] = (!empty($ric_wp_wip_qty)) ? $ric_wp_wip_qty : 0;
                                    }
                                    if ($key == 'qorder_exp_comp_date') {
                                        $_SESSION['quickorder'][$prod_id][$i]['qorder_exp_comp_date'] = $ric_wp_wip_date;
                                    }


                                    // if ($key=='qorder_eship_date') {
                                    //     $qorder_eship_date = qot_ric_date_cacl($product_id, $qorder_qty_stock, $qorder_qty_consider);


                                    //     if (empty($qorder_eship_date)) {
                                    //         $qorder_eship_date=date('Y-m-d', strtotime('+2 days'));
                                    //     }

                                    //     $_SESSION['quickorder'][$prod_id][$i]['qorder_eship_date'] = $qorder_eship_date;
                                    // }


                                    // if ($key=='qorder_rship_date') {
                                    //     $qorder_rship_date=$_SESSION['quickorder'][$prod_id][$i]['qorder_rship_date'];


                                    //     if ($qorder_eship_date > $qorder_rship_date && !empty($qorder_rship_date)) {
                                    //         //  $_SESSION['qorder_rship_date'][$prod_id] = $qorder_rship_date;

                                    //         $_SESSION['quickorder'][$prod_id][$i]['qorder_rship_date']=$qorder_eship_date;
                                    //         qot_update_rship_date_html($prod_id, $unit_price, $qorder_eship_date);
                                    //     }
                                    // }


                                    $i++;
                                }

                                $j++;
                            }
                        }
                        //exit();
                        echo qot_ric_tbody_data($_SESSION['quickorder']);
                    } ?>

                </tbody>
                <tfoot>
                    <tr>
                        <td colspan="10">
                            <div class="qot_ric_checkout">
                                <div class="wc-proceed-to-checkout">
                                    <button id="update_cart" class="checkout-button button alt wc-forward"><?php esc_html_e('Update Quick-Order Table'); ?></button>

                                </div>
                            </div>
                        </td>
                    </tr>
                </tfoot>
            </table>
        </div>
        <div class="shipping-selection">

            <?php

            $shipment_status = 'none';
            if (!empty($_SESSION['quickorder'])) {
                $shipment_status = 'block';
            } else {
                // unset($_SESSION['shipment_choice']);
            }

            ?>
            <div class="shipping-list" style="display:<?php echo $shipment_status; ?>">

                <?php

                $shipping_type = array(
                    'single-shipment'   => 'One shipment when all items are ready',
                    'two-shipment'      => 'Two shipments - as one in-stock & backorder',
                    'multiple-shipment' => 'Multiple shipments as individual parts become available',
                    'custom-shipment'   => 'Custom ship dates according to Quick Order Table'
                );


                ?>
                <div class="shipping-section" style="display:<?php echo $shipment_status; ?>">
                    <div class="shipping-sel-title">
                        <h5>
                            <?php esc_html_e('Select Shipment Method', 'quickorder') ?></h5>
                    </div>
                    <ul>
                        <?php
                        $selected_shipment_choice = $_SESSION['shipment_choice'] ?? ($_SESSION['cart_shipment_choice'] ?? '');
                        foreach ($shipping_type as $key => $shipment) {
                            $selected_item = '';
                            if (!empty($selected_shipment_choice)) {
                                if ($selected_shipment_choice == $key) {
                                    $selected_item = 'checked';
                                }
                            } else {
                                if ($key == 'single-shipment') {
                                    $selected_item = 'checked';
                                } else {
                                    $selected_item = '';
                                }
                            }
                        ?>

                            <li>
                                <input type="radio" id="<?php echo $key ?>" name="select_shipment" class="quickorder_shipment" value="<?php echo $key; ?>" <?php echo $selected_item; ?>>

                                <label for="<?php echo $key ?>"><?php esc_html_e($shipment, 'quickorder'); ?></label>
                            </li>

                        <?php }


                        ?>
                    </ul>
                </div>
            </div>

            <div class="cart-total-section" style="display:<?php echo $shipment_status; ?>">
                <?php
                //if(!wp_admin()){
                wc_get_template('cart/cart-totals.php');
                //}

                ?>
                <div class="qot_ric_checkout">
                    <div class="wc-proceed-to-checkout">

                        <button id="cart_to_checkout" class="checkout-button button alt wc-forward"><?php esc_html_e('Proceed to checkout'); ?></button>
                        <?php if (is_user_logged_in()) {
                            $auth_status = 1;
                        } else {
                            $auth_status = 0;
                        } ?>
                        <input type="hidden" name="auth_status" id="auth_status" value="<?php echo $auth_status; ?>">
                    </div>
                </div>
            </div>


        </div>



        <div class="quick-view-modal">

            <div class="modal fade" id="qorder_quickview" tabindex="-1" role="dialog" aria-labelledby="qot_ric_modalTitle" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLongTitle"><?php esc_html_e('Quick View'); ?></h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body" id="quickview_data">
                            <div id="loader_gif_modal"></div>
                            <?php
                            //qot_ric_show_product_images($product_id);
                            ?>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>


    <div class="container-progressbar" style="display:none">
        <div class="bg-bar">
            <div class="bar-title"><?php echo esc_html('Proceeding to Checkout', 'quickorder'); ?></div>
            <!-- <div id="progress"> -->
            <!-- <span class="progress-text"></span> -->
            <div class="progress-bar"></div>
            <!-- </div> -->

            <?php if (!empty($noOfRows) && $noOfRows == 1 && $auth_status == 0) { ?>

                <ul class="progressbar">
                    <li class="steps step-4 single-progress" data-process="Please wait, Redirecting to Checkout">.<span class="loader__dot">.</span><span class="loader__dot">.</span><span class="loader__dot">.</span></li>
                </ul>

            <?php } else { ?>

                <ul class="progressbar">
                    <li class="steps step-1" data-process="Updated the Items">.</li>
                    <li class="steps step-2" data-process="Updated Shipping Method">.</li>
                    <li class="steps step-3" data-process="Sorted The Items">.</li>
                    <li class="steps step-4" data-process="Complete"><span class="loader__dot"></span><span class="loader__dot"></span><span class="loader__dot"></span></li>
                </ul>

            <?php } ?>
        </div>
    </div>

    <?php
    $output_string = ob_get_contents();
    ob_end_clean();
    return $output_string;
}

/**
 * Function to get input hrml with requested ship date value
 *
 *
 * @package Quick Order Table
 * @since 1.0.0
 */
function qot_update_rship_date_html($prod_id, $unit_price, $qorder_eship_date)
{
    global $field;

    $i = 0;
    foreach ($field as $key) {
        if ($key == 'qorder_rship_date_html') {
            $_SESSION['quickorder'][$prod_id][$i]['qorder_rship_date_html'] =  qot_ric_rdate_field($prod_id, $unit_price, $qorder_eship_date);
        }

        if ($key == 'qorder_rship_date') {
            $_SESSION['quickorder'][$prod_id][$i]['qorder_rship_date'] = $qorder_eship_date;
        }

        $i++;
    }
}

/**
 * Function to get of current date
 *
 *
 * @package Quick Order Table
 * @since 1.0.0
 */
function qot_ric_tbody_data($data)
{
    global $field;
    $qot_ric_options = get_option('qot_ric_options');
    $qot_ric_styles  = get_option('qot_ric_styles');

    $odd  = !empty($qot_ric_styles['tr_odd_bg_color']) ? $qot_ric_styles['tr_odd_bg_color'] : '';
    $even = !empty($qot_ric_styles['tr_even_bg_color']) ? $qot_ric_styles['tr_even_bg_color'] : '';

    $body_text = !empty($qot_ric_styles['tr_text_color']) ? $qot_ric_styles['tr_text_color'] : '';
    $body_row  = array();

    foreach ($qot_ric_options as $key => $options) {

        if (!isset($options['status']) && $options['status'] != 1) {
            $body_row[] = $key;
        }
    }

    $sort_array = array();
    $sort_order = array();

    foreach ($body_row as $key) {
        // if(!in_array($key,[3,4,5,6]) ){
        $sort_array[$key] = $field[$key];
        // }
    }

    $result_data = '';

    if (is_array($data) && count($data) > 0) {
        $cnt = 1;
        $class = '';
        foreach ($data as $key => $quickorder) {
            $currency = get_woocommerce_currency_symbol();
            $bgcolor  = ($cnt % 2 == 0) ? $even : $odd;
            $result_data .= '<tr class="quickorder-row" id="row-' . $key . '" style="background-color:' . $bgcolor . ';color: ' . $body_text . '">';

            foreach ($body_row as $key) {
                $sort_order[$key] = $quickorder[$key];
            }

            $i = 0;
            foreach ($sort_order as $key => $options) {

                $field_name = $sort_array[$key];
                $result_data .= '<td class="' . $class . ' ' . $field_name . '">' . $options[$field_name] . '</td>';
                $i++;
            }

            $result_data .= '</tr>';
            $cnt++;
        }
    }
    return $result_data;
}

/**
 * Get quickorder raws by Ajax call
 *
 *
 * @package Quick Order Table
 * @since 1.0.0
 */
add_action('wp_ajax_ric_wp_get_quick_order', 'ric_wp_get_quick_order');
add_action('wp_ajax_nopriv_ric_wp_get_quick_order', 'ric_wp_get_quick_order');


function ric_wp_get_quick_order()
{
    if (!session_id()) {
        session_start();
    }

    if (!isset($_POST['get_id'])) {
        wp_send_json_error(['message' => 'Invalid product']);
    }

    $product_id = intval($_POST['get_id']);
    $get_qty    = !empty($_POST['get_require_qty']) ? intval($_POST['get_require_qty']) : 1;

    if (null === WC()->cart) {
        wc_load_cart();
    }

    $product = wc_get_product($product_id);
    if (!$product) {
        wp_send_json_error(['message' => 'Product not found']);
    }

    /*
    |--------------------------------------------------------------------------
    | UPDATE / ADD TO CART FIRST
    |--------------------------------------------------------------------------
    */

    $found = false;

    foreach (WC()->cart->get_cart() as $cart_item_key => $cart_item) {
        if ((int)$cart_item['product_id'] === (int)$product_id) {

            WC()->cart->set_quantity(
                $cart_item_key,
                $cart_item['quantity'] + $get_qty,
                true
            );

            $found = true;
            break;
        }
    }

    if (!$found) {
        WC()->cart->add_to_cart($product_id, $get_qty);
    }

    WC()->cart->calculate_totals();


    /*
    |--------------------------------------------------------------------------
    |Default shipment choice
    |--------------------------------------------------------------------------
    */

    if (!isset($_SESSION['shipment_choice'])) {
        $_SESSION['shipment_choice'] = 'custom-shipment';
    }

    /*
    |--------------------------------------------------------------------------
    |  Prepare response
    |--------------------------------------------------------------------------
    */

    $response = array();
    $response['message']    = 'success';
    $response['data']       = qot_ric_tbody_data($_SESSION['quickorder']);
    $response['all_order']  = $_SESSION['quickorder'];
    $response['cart_total'] = WC()->cart->get_cart_total();
    $response['cart_count'] = WC()->cart->get_cart_contents_count();
    $response['cart_totals_html'] = ric_wp_get_cart_totals_html();

    wp_send_json($response);
    exit;
}


if (!function_exists('ric_wp_get_cart_totals_html')) {
    function ric_wp_get_cart_totals_html()
    {
        if (null === WC()->cart) {
            wc_load_cart();
        }

        ob_start();
        wc_get_template('cart/cart-totals.php');
        return ob_get_clean();
    }
}


function getDateBasedOnDemand($quantities, $userDemand)
{
    $totalQty = 0;


    foreach ($quantities as $item) {
        $totalQty += $item['qty'];


        if ($totalQty >= $userDemand) {
            return $item['date'];
        }
    }

    return null; // Return null if demand is not met
}
/**
 * checking the product id
 * @package Quick Order Table
 * @since 1.0.0 
 */
function check_product_id($productid)
{
    // Check if the product ID contains an underscore (i.e., if it has a suffix)
    if (strpos($productid, '_') !== false) {
        // Split the product ID by the underscore
        $parts = explode('_', $productid);

        // The first part is the base product ID
        $base_product_id = $parts[0];
        // The second part is the suffix (e.g., '0', '1')
        $suffix = $parts[1];

        // Return a message indicating this is a suffixed product ID
        return true;
    } else {
        // If no underscore is found, it's a regular product ID
        return false;
    }
}

/**
 * Get quickorder raws by Ajax call
 *
 *
 * @package Quick Order Table
 * @since 1.0.0
 */
add_action('wp_ajax_ric_wp_split_qty_quick_order', 'ric_wp_split_qty_quick_order');
add_action('wp_ajax_nopriv_ric_wp_split_qty_quick_order', 'ric_wp_split_qty_quick_order');

function ric_wp_split_qty_quick_order()
{
    global $field;

    $quickorder = [];
    $response = [];
    $split_qty = [];

    // Ensure necessary POST variables are set
    if (empty($_POST['old_qty']) || empty($_POST['get_qty']) || empty($_POST['product_id'])) {
        wp_send_json_error('Missing required parameters');
        return;
    }

    $row_id = $_POST['product_id'];

    $old_qty = intval($_POST['old_qty']);
    $get_qty = intval($_POST['get_qty']);
    if (check_product_id($_POST['product_id'])) {
        $product_id = $_POST['product_id'];
    } else {
        $product_id = intval($_POST['product_id']);
    }


    // Fetch product
    $product = wc_get_product($product_id);
    if (!$product) {
        $product_id = qot_get_product_id($product_id);
        $product = wc_get_product($product_id);
        if (!$product) {
            wp_send_json_error('Invalid product');
            return;
        }
    }

    // Calculate new quantity after splitting
    $new_quantity = $old_qty - $get_qty;

    $split_qty_data[] = $new_quantity;



    $qucik_orders_qty = $_POST['qucik_orders_qty'];
    if (!empty($qucik_orders_qty)) {
        foreach ($qucik_orders_qty as $order) {
            // Access the id and quantity
            $id = $order['id'];
            $split_qty_data[] = $order['quantity'];
            // Perform your logic here (e.g., save to the database)
        }
    }
    $split_qty_data[] = $get_qty;
    // Get availability table
    $availability_table = function_exists('rtcwp_get_adjusted_capacity')
        ? rtcwp_get_adjusted_capacity($product_id)
        : get_post_meta($product_id, 'availability_table', true);

    // Set default availability if not found
    if (empty($availability_table) || !isset($availability_table['get_capacity'])) {
        $availability_table[0] = [
            'type' => 'work_order',
            'qty' => get_post_meta($product_id, '_ric_wp_wip_qty', true),
            'date_available' => get_post_meta($product_id, '_ric_wp_wip_date', true),
        ];

        $wip_lead_time = get_post_meta($product_id, '_ric_wp_wip_lead_time', true);
        $ship_date = date('Y-m-d', strtotime('+' . $wip_lead_time . ' days'));

        $availability_table[1] = [
            'type' => 'lead_time',
            'date_available' => $ship_date,
        ];
    } else {
        $availability_table = $availability_table['get_capacity'];
    }

    $quantities = array();

    $qty_total = 0;
    foreach ($availability_table as $item) {

        if (isset($item['qty'])) {

            $quantities[] = array(
                'qty' => $item['qty'],
                'date' => $item['date_available']
            );
            $qty_total += $item['qty'];
        }
    }
    if (!empty($split_qty_data)) {
        foreach ($split_qty_data as $quantity_val) {
            // Get the date based on the demand
            $split_qty_date = getDateBasedOnDemand($quantities, $quantity_val);

            // Create an associative array for this quantity
            $splt = [
                'qty' => $quantity_val,
                'date' => $split_qty_date
            ];

            // Append the associative array to the split_qty array
            $split_qty[] = $splt;
        }
    }
    // $split_qty_date  =    getDateBasedOnDemand($quantities, $new_quantity);
    // $splt1['qty'] = $new_quantity;
    // $splt1['date'] = $split_qty_date;
    // $split_qty[]= $splt1;

    // $split_qty_date2  =    getDateBasedOnDemand($quantities, $get_qty);
    // $splt2['qty'] = $get_qty;
    // $splt2['date'] = $split_qty_date2;
    // $split_qty[] = $splt2;



    $quickorder =  split_quick_order_table($split_qty, $product_id, $get_qty, $new_quantity, 'custom-shipment', $row_id);

    $resposnse['message'] = 'success';
    $resposnse['data'] = qot_ric_tbody_data($quickorder);

    $resposnse['all_order'] = $all_order;

    wp_send_json($resposnse);
    exit;
}



function ric_get_existing_split_id_and_qty($product_id)
{
    if (empty($_SESSION['quickorder'])) {
        return false;
    }

    global $field;

    $qty_index = array_search('qorder_qty_order', $field, true);
    if ($qty_index === false) return false;

    $results = [];

    foreach ($_SESSION['quickorder'] as $key => $rows) {

        // Match split keys like: 17021_0, 17021_1, etc.
        if (strpos($key, $product_id . '_') === 0) {

            $qty = isset($rows[$qty_index]['qorder_qty_order'])
                ? (int) $rows[$qty_index]['qorder_qty_order']
                : 0;

            $results[] = [
                'id'  => $key,
                'qty' => $qty
            ];
        }
    }

    return !empty($results) ? $results : false;
}

function split_quick_order_table($split_qty, $product_id, $get_qty, $new_quantity, $type, $row_id = '')
{
    global $field;

    $product = wc_get_product($product_id);


    if (!$product || empty($_SESSION['quickorder'])) {
        return false;
    }

    global $field;

    $idx_qty      = array_search('qorder_qty_order', $field, true);
    $idx_consider = array_search('qorder_qty_consider', $field, true);
    $idx_total    = array_search('qorder_total_price', $field, true);
    $idx_html     = array_search('qorder_qty_order_html', $field, true);
    $idx_action    = array_search('action', $field, true);
    $idx_eship    = array_search('qorder_eship_date', $field, true);
    $idx_rship    = array_search('qorder_rship_date', $field, true);
    $idx_rship_html = array_search('qorder_rship_date_html', $field, true);

    $_SESSION['shipment_choice'] = $type;


    $product     = wc_get_product($product_id);
    $stock_qty   = (int) $product->get_stock_quantity();
    $unit_price  = (float) $product->get_price();
    $currency    = get_woocommerce_currency_symbol();

    $splited_row_id = $row_id;
    $existing = ric_get_existing_split_id_and_qty($product_id);
    // echo '<pre>';
    // print_r($idx_qty);
    // echo '</pre>';
    // $old_qty= isset($_POST['old_qty']) ?? '';

    // if(!empty($existing) && !empty( $old_qty)){
    //     $_SESSION['quickorder_undo'][$product_id] = [
    //         'product_id' => $product_id,
    //         'row_id'     => $splited_row_id,
    //         'qty'        => $old_qty,
    //         'timestamp'  => time(),
    //     ];
    // }

    if ($type == 'custom-shipment') {
        $clicked_row_id = !empty($row_id) ? $row_id : $product_id;
        $remaining_qty  = max(0, (int) $new_quantity);
        $split_qty_out  = max(0, (int) $get_qty);

        if (!isset($_SESSION['quickorder'][$clicked_row_id]) || $remaining_qty <= 0 || $split_qty_out <= 0) {
            return $_SESSION['quickorder'];
        }

        $remaining_date = qot_ric_date_cacl($product_id, $stock_qty, $remaining_qty);
        $split_date     = qot_ric_date_cacl($product_id, $stock_qty, $split_qty_out);
        if (!empty($split_qty)) {
            $first_split = reset($split_qty);
            $last_split  = end($split_qty);
            $remaining_date = !empty($first_split['date']) ? $first_split['date'] : $remaining_date;
            $split_date     = !empty($last_split['date']) ? $last_split['date'] : $split_date;
        }

        $old_qty = (int) $_SESSION['quickorder'][$clicked_row_id][$idx_qty]['qorder_qty_order'];

        $_SESSION['quickorder'][$clicked_row_id][$idx_qty]['qorder_qty_order'] = $remaining_qty;
        $_SESSION['quickorder'][$clicked_row_id][$idx_consider]['qorder_qty_consider'] = $remaining_qty;
        $_SESSION['quickorder'][$clicked_row_id][$idx_total]['qorder_total_price'] = $remaining_qty * $unit_price;
        $_SESSION['quickorder'][$clicked_row_id][$idx_html]['qorder_qty_order_html'] = qot_ric_qty_order_field($clicked_row_id, $remaining_qty);
        $_SESSION['quickorder'][$clicked_row_id][$idx_eship]['qorder_eship_date'] = $remaining_date;
        $_SESSION['quickorder'][$clicked_row_id][$idx_rship]['qorder_rship_date'] = $remaining_date;
        $_SESSION['quickorder'][$clicked_row_id][$idx_rship_html]['qorder_rship_date_html'] = qot_ric_rdate_field($clicked_row_id, $unit_price, $remaining_date);
        $_SESSION['quickorder'][$clicked_row_id][$idx_action]['action'] = qot_ric_delete_order($clicked_row_id, true, true);

        $max_index = -1;
        foreach ($_SESSION['quickorder'] as $rid => $row) {
            if (preg_match('/^' . preg_quote((string) $product_id, '/') . '_(\d+)$/', (string) $rid, $matches)) {
                $max_index = max($max_index, (int) $matches[1]);
            }
        }

        $new_row_id = $product_id . '_' . ($max_index + 1);

        $quickorder = [
            'qorder_id'             => $product_id,
            'qorder_did'            => $new_row_id,
            'qorder_quickview'      => '<button data-id="' . $new_row_id . '" class="qorder_quickview"><i class="fa fa-info-circle"></i></button>',
            'qorder_name'           => $product->get_name(),
            'qorder_sku'            => $product->get_sku(),
            'qorder_qty_stock'      => $stock_qty,
            'qorder_qty_order'      => $split_qty_out,
            'qorder_qty_consider'   => $split_qty_out,
            'qorder_qty_order_html' => qot_ric_qty_order_field($new_row_id, $split_qty_out),
            'qorder_unit_price'     => $unit_price,
            'qorder_currency'       => $currency,
            'qorder_total_price'    => $split_qty_out * $unit_price,
            'qorder_eship_date'     => $split_date,
            'qorder_rship_date'     => $split_date,
            'qorder_rship_date_html' => qot_ric_rdate_field($new_row_id, $unit_price, $split_date),
            'action'                => qot_ric_delete_order($new_row_id, true, false)
        ];

        foreach ($field as $index => $fname) {
            $_SESSION['quickorder'][$new_row_id][$index][$fname] = $quickorder[$fname] ?? '';
        }

        $_SESSION['quickorder_undo'][$new_row_id] = [
            'product_id' => $product_id,
            'row_id'     => $clicked_row_id,
            'old_qty'    => $old_qty,
            'new_qty'    => $remaining_qty,
            'new_row_id' => $new_row_id,
            'timestamp'  => time(),
        ];

        $_SESSION['quickorder_original'] = $_SESSION['quickorder'];

        return $_SESSION['quickorder'];
    }

    if ($type != 'custom-shipment') {


        unset($_SESSION['quickorder_undo']);

        if (!empty($_SESSION['quickorder_original'])) {
            foreach ($_SESSION['quickorder'] as $rid => $row) {
                if (!array_key_exists($rid, $_SESSION['quickorder_original'])) {
                    unset($_SESSION['quickorder'][$rid]);
                }
            }
        }
    }


    $max_index = -1;

    /* Find current max index once */
    foreach ($_SESSION['quickorder'] as $rid => $row) {
        if (preg_match('/^' . $product_id . '_(\d+)$/', $rid, $matches)) {
            $idx = (int) $matches[1];
            if ($idx > $max_index) {
                $max_index = $idx;
            }
        }
    }

    $i = 0;

    foreach ($split_qty as $data) {

        $qty  = (int) $data['qty'];
        $date = $data['date'];
        $calculated_date = !empty($date) ? $date : qot_ric_date_cacl($product_id, $stock_qty, $qty);

        if ($qty <= 0) {
            continue;
        }

        $target_row_id = $product_id . '_' . $i;

        /* ---------------- UPDATE IF EXISTS ---------------- */
        if (isset($_SESSION['quickorder'][$target_row_id])) {

            $old_qty = (int) $_SESSION['quickorder'][$target_row_id][$idx_qty]['qorder_qty_order'];

            if ($type == 'custom-shipment') {
                if (!isset($_SESSION['quickorder_undo'][$target_row_id])) {
                    $_SESSION['quickorder_undo'][$target_row_id] = [
                        'product_id' => $product_id,
                        'row_id'     => $target_row_id,
                        'old_qty'        => $old_qty,
                        'new_qty'        => $qty,
                        'timestamp'  => time(),
                    ];
                }
            } else {
                unset($_SESSION['quickorder_undo']);
            }


            $_SESSION['quickorder'][$target_row_id][$idx_qty]['qorder_qty_order'] = $qty;
            $_SESSION['quickorder'][$target_row_id][$idx_consider]['qorder_qty_consider'] = $qty;
            $_SESSION['quickorder'][$target_row_id][$idx_total]['qorder_total_price'] = $qty * $unit_price;
            $_SESSION['quickorder'][$target_row_id][$idx_html]['qorder_qty_order_html'] =
                qot_ric_qty_order_field($target_row_id, $qty);

            $_SESSION['quickorder'][$target_row_id][array_search('qorder_eship_date', $field, true)]['qorder_eship_date'] = $calculated_date;
            $_SESSION['quickorder'][$target_row_id][array_search('qorder_rship_date', $field, true)]['qorder_rship_date'] = $calculated_date;
            if ($type != 'custom-shipment') {
                $_SESSION['quickorder'][$target_row_id][$idx_action]['action'] = qot_ric_delete_order($product_id, false, false);
            } else {
                $_SESSION['quickorder'][$target_row_id][$idx_action]['action'] = qot_ric_delete_order($product_id, true, false, $target_row_id);
            }
        }
        /* ---------------- CREATE NEW IF NOT EXISTS ---------------- */ else {

            $max_index++;
            $new_row_id = $product_id . '_' . $max_index;

            $quickorder = [
                'qorder_id'             => $product_id,
                'qorder_did'            => $new_row_id,
                'qorder_quickview'      => '<button data-id="' . $new_row_id . '" class="qorder_quickview"><i class="fa fa-info-circle"></i></button>',
                'qorder_name'           => $product->get_name(),
                'qorder_sku'            => $product->get_sku(),
                'qorder_qty_stock'      => $stock_qty,
                'qorder_qty_order'      => $qty,
                'qorder_qty_consider'   => $qty,
                'qorder_qty_order_html' => qot_ric_qty_order_field($new_row_id, $qty),
                'qorder_unit_price'     => $unit_price,
                'qorder_currency'       => $currency,
                'qorder_total_price'    => $qty * $unit_price,
                'qorder_eship_date'     => $calculated_date,
                'qorder_rship_date'     => $calculated_date,
                'qorder_rship_date_html' => qot_ric_rdate_field($new_row_id, $unit_price, $calculated_date),
            ];

            if (!isset($_SESSION['quickorder_undo'][$target_row_id])) {
                $_SESSION['quickorder_undo'][$target_row_id] = [
                    'product_id' => $product_id,
                    'row_id'     => $target_row_id,
                    'old_qty'        => $old_qty,
                    'new_qty'        => $qty,
                    'new_row_id'     => $new_row_id,
                    'timestamp'  => time(),
                ];
            }


            foreach ($field as $index => $fname) {

                $_SESSION['quickorder'][$new_row_id][$index][$fname] = $quickorder[$fname] ?? '';

                if ($fname === 'action') {
                    if ($type != 'custom-shipment') {
                        $_SESSION['quickorder'][$new_row_id][$index]['action'] =
                            qot_ric_delete_order($new_row_id, false, false);
                    } else {
                        $_SESSION['quickorder'][$new_row_id][$index]['action'] =
                            qot_ric_delete_order($new_row_id, true, false);
                    }
                }
            }
        }

        $i++;
    }

    return $_SESSION['quickorder'];
}

/**
 * Get quickorder raws by Ajax call
 *
 *
 * @package Quick Order Table
 * @since 1.0.0
 */
add_action('wp_ajax_ric_wp_split_undo_quick_order', 'ric_wp_split_undo_quick_order');
add_action('wp_ajax_nopriv_ric_wp_split_undo_quick_order', 'ric_wp_split_undo_quick_order');

function ric_wp_split_undo_quick_order()
{

    global $field;

    $resposnse = array();
    $split_qty = array();
    $quickorder = [];

    if (isset($_POST['get_qty'])) {
        $get_qty = $_POST['get_qty'];
    }

    if (isset($_POST['t_qty'])) {
        $t_qty = $_POST['t_qty'];
    }

    if (isset($_POST['o_id'])) {
        $o_id = $_POST['o_id'];
    }

    if (isset($_POST['product_id'])) {
        $product_id = $_POST['product_id'];
    }
    // if(isset($_POST['oldRowid'])) {
    //     $target_row_id = $_POST['oldRowid'];
    // }else{
    //     $target_row_id = '';
    // }

    $target_row_id = '';

    // if (!isset($_SESSION['quickorder_undo'][$target_row_id])) {
    //     $_SESSION['quickorder_undo'][$target_row_id] = [
    //         'product_id' => $product_id,
    //         'row_id'     => $target_row_id,
    //         'old_qty'        => $old_qty,
    //         'new_qty'        => $qty,
    //         'new_row_id'     => $new_row_id,
    //         'timestamp'  => time(),
    //     ];
    // }


    if (isset($_POST['product_chunk'])) {
        $product_chunk = $_POST['product_chunk'];
    }

    foreach ($product_chunk as $key => $pro_id) {
        if (isset($_SESSION['quickorder_undo'][$pro_id])) {
            $target_row_id = $pro_id;
            $existing_old_row_id = $_SESSION['quickorder_undo'][$pro_id]['row_id'];
            $existing_old_qty = $_SESSION['quickorder_undo'][$pro_id]['old_qty'];
            $qty_index = array_search('qorder_qty_order', $field, true);
            $qorder_qty_order_html_index = array_search('qorder_qty_order_html', $field, true);
            $action_index = array_search('action', $field, true);

            $_SESSION['quickorder'][$existing_old_row_id][$qty_index]['qorder_qty_order'] = $existing_old_qty;
            $_SESSION['quickorder'][$existing_old_row_id][$qorder_qty_order_html_index]['qorder_qty_order_html']
                = qot_ric_qty_order_field($existing_old_row_id, $existing_old_qty);

            $_SESSION['quickorder'][$existing_old_row_id][$action_index]['action'] = qot_ric_delete_order($existing_old_row_id, true, true);

            $new_row_id = $_SESSION['quickorder_undo'][$pro_id]['new_row_id'];
            unset($_SESSION['quickorder'][$new_row_id]);
        }
    }



    if (isset($_SESSION['quickorder_undo'][$target_row_id])) {
        unset($_SESSION['quickorder_undo'][$target_row_id]);
    }


    $resposnse['message'] = 'success';
    $resposnse['data'] = qot_ric_tbody_data($_SESSION['quickorder']);


    wp_send_json($resposnse);
    exit;
}

/**
 * Get Lead time from product post meta
 *
 *
 * @package Quick Order Table
 * @since 1.0.0
 */
function qot_get_lead_time($product_id)
{
    $ric_wp_wip_lead_time   = get_post_meta($product_id, '_ric_wp_wip_lead_time', true);

    if (!empty($ric_wp_wip_lead_time)) {
        /* from rushabh-instruments-customization plugin */
        $leadtime = ric_wp_daystoweek($ric_wp_wip_lead_time);
    } else {
        $leadtime = '-';
    }

    return $leadtime;
}

/**
 * Function to get last key of id to add to exist by new one
 *
 *
 * @package Quick Order Table
 * @since 1.0.0
 */
function get_last_exist_key_id($prod_id = '')
{
    $data = $_SESSION['quickorder'];

    if (is_array($data) && count($data) > 0) {
        $cnt = 1;
        foreach ($data as $key => $quickorder) {
            if (isset($prod_id) && !empty($prod_id)) {
                $product_id = qot_get_product_id($prod_id);
                if ($product_id == $key) {
                    $exist_key_id = $key;
                }
            } else {
                $exist_key_id = $key;
            }


            $cnt++;
        }
    }
    return $exist_key_id;
}

/**
 * Function to get exist order id
 *
 *
 * @package Quick Order Table
 * @since 1.0.0
 */
function get_exist_order_id()
{
    if (!empty($_SESSION['quickorder'])) {
        $data = $_SESSION['quickorder'];
        $exist_order_id = array();

        if (is_array($data) && count($data) > 0) {
            $cnt = 1;
            foreach ($data as $key => $quickorder) {
                $exist_order_id[] = $key;
                $cnt++;
            }
        }
        return $exist_order_id;
    }
    return array();
}

/**
 * Function to get all products id
 *
 *
 * @package Quick Order Table
 * @since 1.0.0
 */
function get_exist_original_product_ids()
{
    if (!empty($_SESSION['quickorder'])) {
        $data = $_SESSION['quickorder'];
        $exist_product_ids = array();

        if (is_array($data) && count($data) > 0) {
            foreach ($data as $key => $quickorder) {
                if (strpos($key, '_') !== false) {
                    $exist_key = explode("_", $key);
                    $product_id = $exist_key[0];
                } else {
                    $product_id = $key;
                }

                $exist_product_ids[] = $product_id;
            }
        }
        return $exist_product_ids;
    }
}

/**
 * Function to get quanity order input field
 *
 *
 * @package Quick Order Table
 * @since 1.0.0
 */
function qot_ric_qty_order_field($order_id, $qty)
{
    $product_id = $order_id;
    $parts = explode('_', $product_id);
    $pro_parent_id = $parts[0];
    $get_availability_table  = get_post_meta($pro_parent_id, 'availability_table', true);
    $product            = wc_get_product($pro_parent_id);
    if (!empty($get_availability_table['get_capacity'])) {
        $availability_table  = $get_availability_table['get_capacity'];
    } else {
        $availability_table  = array();
    }
    if (!empty($availability_table)) {
        $total_qty = 0;
        foreach ($availability_table as $availability) {
            if (isset($availability['qty']) && is_numeric($availability['qty'])) {
                $total_qty += $availability['qty'];
            }
        }
        $total_max_qty = $total_qty;
    } else {
        $total_qty = 0;
        if (!empty(get_post_meta($pro_parent_id, '_ric_wp_wip_qty', true))) {
            $total_qty      = get_post_meta($pro_parent_id, '_ric_wp_wip_qty', true);
        } else {
            $total_qty      = $total_qty + $product->get_stock_quantity();
        }
        $total_max_qty = $total_qty;
    }

    $get_product_type = get_post_meta($order_id, '_virtual', true);
    if ($get_product_type == 'yes') {
        $disabled = 'disabled';
    } else {
        $disabled = '';
    }

    $qty_order_field = '<input type="number" min="1" onkeypress="return event.charCode >= 48" data-id="' . $order_id . '" data-max-qty="' . $total_max_qty . '" class="qorder_qty_order" data-old-qty="' . $qty . '" value="' . $qty . '" ' . $disabled . '>';

    return $qty_order_field;
}


/**
 * Function to add button to split items
 *
 *
 * @package Quick Order Table
 * @since 1.0.0
 */
function qot_ric_delete_order($productid, $btn_status, $split = false, $old_row_id = '')
{

    $get_product_type = get_post_meta($productid, '_virtual', true);
    if ($get_product_type == 'yes') {
        $btn_status = false;
        $split = false;
    }
    $readonly = 'readOnly';


    if (isset($_SESSION['shipment_choice'])) {
        if ($_SESSION['shipment_choice'] == 'custom-shipment') {
            $custom_class = '';
            $disabled = '';
        } else {
            $disabled = 'disabled';
            $custom_class = 'cdtm-hide-readOnly';
        }
    }
    if ($btn_status && $split  && $_SESSION['shipment_choice'] == 'custom-shipment') {



        $split_btn = ' <button id="" data-toggle="modal" data-target="#qorder_spilt_orderdata" class="split_qty ' . $custom_class . '"  data-id="' . $productid . '" ' . $disabled . ' ' . $selectedShipment_methods . '><span>' . esc_html('Split Delivery', 'quickorder') . '</span><i class="fa fa-angle-double-down" aria-hidden="true"></i></button>

                    <div class="modal-body" id="quickview_data1-' . $productid . '" class="quick-view-spilt-popup current-popup-ctm-wrap-' . $productid . '" style="display:none;">
                    <button type="button" class="close close-btn-btn-ctm" data-target="' . $productid . '" data-dismiss="modal" aria-label="Close">
                      <span aria-hidden="true">&times;</span>
                    </button>
                        <div id="loader_gif_modal1"></div>
                        <div class="quantity-split-container">
                            <h3>' . esc_html__('Enter Qty to Split', 'quickorder') . '</h3>
                            <input type="number" id="split-quantity" min="1" placeholder="' . esc_html__('Qty', 'quickorder') . '">
                            <button id="confirm-button" class="popup-spilt-dsg-wrap-con cng-btn-btn-wrap-' . $productid . '" data-qty="" data-id="" data-product-parent-id="">
                                ' . esc_html__('Confirm', 'quickorder') . '
                            </button>
                        </div>
                    </div>
        ';

        $wide_td = 'wide-td';
    } else if ($btn_status && $_SESSION['shipment_choice'] == 'custom-shipment') {
        $split_btn = ' <button id="" class="split_qty_undo"  data-id="' . $productid . '" data-old-row-id="' . $old_row_id . '">' . esc_html('Undo Split', 'quickorder') . '</button>';
        $wide_td = 'wide-td';
    } else {
        $split_btn = '';
        $wide_td = '';
    }
    $qot_ric_delete_order = '
    <div class="qot_action_column qot_split_btn ' . $wide_td . '">
       ' . $split_btn . '
        <button class="delete_order"  data-id="' . $productid . '"><img src="' . QOT_RIC_INC_URL . '/images/cancel.svg"></button>
    </div>';

    return $qot_ric_delete_order;
}



/**
 * Function to get request date input
 *
 *
 * @package Quick Order Table
 * @since 1.0.0
 */
function qot_ric_rdate_field($order_id, $price, $date)
{
    $readonly = 'readOnly';

    if (isset($_SESSION['shipment_choice'])) {
        if ($_SESSION['shipment_choice'] == 'custom-shipment') {
            $readonly = '';
        } else {
            $readonly = 'readOnly';
        }
    }

    $get_product_type = get_post_meta($order_id, '_virtual', true);

    if ($get_product_type == 'yes') {
        $rdate_field = 'Virtual';
    } else {
        $rdate_field = '<input type="text" placeholder="Select Date" data-id="' . $order_id . '" data-price="' . $price . '" class="qorder_rship_date ' . $readonly . '" value="' . $date . '" readonly="readonly">';
    }

    return $rdate_field;
}

/**
 * Return true if date is weekend day
 *
 *
 * @package Quick Order Table
 * @since 1.0.0
 */
function isWeekend($date)
{
    $weekDay = date('w', strtotime($date));
    if ($weekDay == 6) {
        return 2;
    }
    if ($weekDay == 0) {
        return 1;
    }

    return 0;
}

/**
 * Function return dates of holidays
 *
 *
 * @package Quick Order Table
 * @since 1.0.0
 */
function isHolidays($date, $product_id, $ship_case)
{
    global $qot_ric_model;
    $today = date('Y-m-d', strtotime('+1 day'));
    $offDayInStart  = isWeekend($today);
    if ($offDayInStart > 0) {
        $offDayInStart = (int)$offDayInStart + 1;

        $today = date('Y-m-d', strtotime('+' . $offDayInStart . ' days'));
    }

    if ($ship_case == 1) {
        $end_date = $date;
    } elseif ($ship_case == 2) {
        $today =  $end_date = $date;
    } elseif ($ship_case == 3) {
        if (!empty($date)) {
            $today =  $end_date = $date;
        } else {
            $ric_wp_wip_lead_time   = get_post_meta($product_id, '_ric_wp_wip_lead_time', true);

            if ($offDayInStart > 0) {
                $offDayInStart = (int)$offDayInStart;

                $ric_wp_wip_lead_time =  (int)$ric_wp_wip_lead_time + (int)$offDayInStart;
            }
            $end_date = date('Y-m-d', strtotime('+' . $ric_wp_wip_lead_time . ' days'));
        }
    }

    $weekend_dates = $qot_ric_model->qot_ric_get_weekend_dates($today, $end_date);

    $allholidays = $qot_ric_model->qot_ric_get_holidays_date();

    $holidays = array_merge($weekend_dates, $allholidays);
    if (empty($date) || $date == '') {
        return $date;
    }

    $returnDate = date_move_from_holidays_range($today, $end_date, $holidays);
    //if return date is again holidays from out of range - start to end
    // if moved date is weekend
    $getDays = isWeekend($returnDate);

    $returnDate = date('Y-m-d', strtotime($returnDate . ' +' . $getDays . ' days'));

    // if moved date is again holidays with weekend
    if (in_array($returnDate, $allholidays)) {
        $_returnDate = is_moved_date_holidays($returnDate, $allholidays);
    } else {
        $_returnDate = $returnDate;
    }

    return $_returnDate;
}

/**
 * Function returns dates of holidays between two dates
 *
 *
 * @package Quick Order Table
 * @since 1.0.0
 */
function date_move_from_holidays_range($today, $end_date, $holidays)
{
    global $qot_ric_model;

    $getDays_return = 0;

    if (count($holidays) == 1) {
        if (in_array($date, $holidays)) {
            $returnDate = date('Y-m-d', strtotime($date . ' +1 day'));
        }
    }

    $startDate = date('Y-m-d', strtotime($today));

    $endDate = date('Y-m-d', strtotime($end_date));

    $noOfDays = array();
    if (count($holidays) > 1) {
        $i = 0;
        foreach ($holidays as $holiday) {
            if (($holiday >= $startDate) && ($holiday <= $endDate)) {
                $noOfDays[] = $holiday;
            }
            $i++;
        }
    }

    $noOfDays = array_unique($noOfDays);
    $getDays_return = count($noOfDays);

    $returnDate = date('Y-m-d', strtotime($end_date . ' +' . $getDays_return . ' days'));

    $weekend_dates = $qot_ric_model->qot_ric_get_weekend_dates($end_date, $returnDate);

    $holidays = array_merge($weekend_dates, $holidays);
    if (in_array($returnDate, $holidays)) {
        $_returnDate = date_move_from_holidays_range($end_date, $returnDate, $holidays);
    } else {
        $_returnDate = $returnDate;
    }
    return $_returnDate;
}

/**
 * Function returns holidays date from given date
 *
 *
 * @package Quick Order Table
 * @since 1.0.0
 */
function is_moved_date_holidays($returnDate, $allholidays)
{
    if (in_array($returnDate, $allholidays)) {
        $final_date = date('Y-m-d', strtotime($returnDate . ' +1 day'));
    }


    //get return date moved to next date again holdays until working day

    if (in_array($final_date, $allholidays)) {
        $_returnDate = is_moved_date_holidays($final_date, $allholidays);
    } else {
        $_returnDate = $final_date;
    }

    //if get date from working days is again weekend
    $getDays = isWeekend($_returnDate);

    $returnDate = date('Y-m-d', strtotime($_returnDate . ' +' . $getDays . ' days'));
    return $returnDate;
}

/**
 * Ajax Function to delete item fro quick order table
 *
 *
 * @package Quick Order Table
 * @since 1.0.0
 */
add_action('wp_ajax_ric_wp_delete_order', 'ric_wp_delete_order');
add_action('wp_ajax_nopriv_ric_wp_delete_order', 'ric_wp_delete_order');

function ric_wp_delete_order()
{
    global $field;
    $resposnse_delete = [];


    if (isset($_POST['prod_id'])) {
        $pro_id = $_POST['prod_id'];
        $remove_qty = $_POST['prod_qty'];

        if (strpos($pro_id, '_') !== false) {
            // Split the product ID by the underscore
            $parts = explode('_', $pro_id);
            $base_product_id = $parts[0];
        } else {
            $base_product_id = $pro_id;
        }

        // foreach (WC()->cart->get_cart() as $cart_item_key => $cart_item) {
        //     if ((int) $cart_item['product_id'] === (int) $pro_id) {
        //         WC()->cart->remove_cart_item($cart_item_key);
        //     }
        // }

        foreach (WC()->cart->get_cart() as $cart_key => $item) {

            if ((int) $item['product_id'] === (int) $base_product_id) {
                $current_qty = (int) $item['quantity'];
                $new_qty     = $current_qty - (int) $remove_qty;
                if ($new_qty <= 0) {
                    // WC()->cart->remove_cart_item($cart_key);
                    WC()->cart->set_quantity($cart_key, $new_qty, true);
                } else {
                    WC()->cart->set_quantity($cart_key, $new_qty, true);
                }
            }
        }

        unset($_SESSION['quickorder'][$pro_id]);
        unset($_SESSION['qorder_rship_date'][$pro_id]);

        $child_keys = array_keys($_SESSION['quickorder']);
        $child_candidates = preg_grep('/^' . preg_quote($pro_id . '_', '/') . '/', $child_keys);

        if (!empty($child_candidates)) {
            $first_child = reset($child_candidates); // e.g., 20443_0
            $_SESSION['quickorder'][$pro_id] = $_SESSION['quickorder'][$first_child];
            unset($_SESSION['quickorder'][$first_child]);

            // Also move its shipping date if exists
            if (isset($_SESSION['qorder_rship_date'][$first_child])) {
                $_SESSION['qorder_rship_date'][$pro_id] = $_SESSION['qorder_rship_date'][$first_child];
                unset($_SESSION['qorder_rship_date'][$first_child]);
            }
        }

        // sleep(3);
        $qot_get_consider_total_qty = qot_get_consider_total_qty();

        $prod_ids = get_exist_order_id();

        foreach ($prod_ids as $prod_id) {
            $product_id = qot_get_product_id($prod_id);

            $total_qty = $qot_get_consider_total_qty[$prod_id]['consider_qty'];
            if ($total_qty) {
                $total_consider = $total_qty;
            } else {
                $total_consider = qot_ric_get_exist_consider_qty($prod_id);
            }

            //echo $total_consider." total_consider ";
            $i = 0;
            foreach ($field as $key) {
                if ($key == 'qorder_qty_consider') {
                    $_SESSION['quickorder'][$prod_id][$i]['qorder_qty_consider'] = $total_consider;
                    //echo $_SESSION['quickorder'][$prod_id][$i]['qorder_qty_consider'];
                }
                if ($key == 'qorder_eship_date') {
                    // echo " ".$total_consider." ";
                    $ship_date = qot_ric_date_cacl($product_id, $qty_in_stock, $total_consider);

                    $_SESSION['quickorder'][$prod_id][$i]['qorder_eship_date'] = $ship_date;
                }

                $i++;
            }
        }
        $_SESSION['quickorder_original'] = $_SESSION['quickorder'];
        $resposnse_delete['message'] = 'success';
        $resposnse_delete['data'] =  qot_ric_tbody_data($_SESSION['quickorder']);


        wp_send_json($resposnse_delete);
        die();
    }
}

/**
 * Ajax Function to show quick view
 *
 *
 * @package Quick Order Table
 * @since 1.0.0
 */
add_action('wp_ajax_ric_wp_qorder_quickview', 'ric_wp_qorder_quickview');
add_action('wp_ajax_nopriv_ric_wp_qorder_quickview', 'ric_wp_qorder_quickview');

function ric_wp_qorder_quickview()
{
    $resposnse = array();
    global $post, $woocommerce;
    if (isset($_POST['prod_id'])) {
        $product_id = $_POST['prod_id'];
        $product_id = qot_get_product_id($product_id);
        $product = wc_get_product($product_id);
        ?>
        <div class="images">
            <?php

            $get_image_id = $product->get_image_id();
            if ($get_image_id) {
                echo  get_the_post_thumbnail($product_id, 'thumbnail');
            } else {
                echo apply_filters('woocommerce_single_product_image_html', sprintf('<img src="%s" alt="%s" />', wc_placeholder_img_src(), __('Placeholder', 'woocommerce')), $post->ID);
            }

            $attachment_ids = $product->get_gallery_image_ids();
            if ($attachment_ids) :
                $loop       = 0;
                $columns    = apply_filters('woocommerce_product_thumbnails_columns', 3);
            ?>
                <div class="thumbnails <?php echo 'columns-' . $columns; ?>"><?php
                                                                                foreach ($attachment_ids as $attachment_id) {
                                                                                    $classes = array('thumbnail');
                                                                                    if ($loop === 0 || $loop % $columns === 0) {
                                                                                        $classes[] = 'first';
                                                                                    }
                                                                                    if (($loop + 1) % $columns === 0) {
                                                                                        $classes[] = 'last';
                                                                                    }
                                                                                    $image_link = wp_get_attachment_url($attachment_id);
                                                                                    if (! $image_link) {
                                                                                        continue;
                                                                                    }
                                                                                    $image_title    = esc_attr(get_the_title($attachment_id));
                                                                                    $image_caption  = esc_attr(get_post_field('post_excerpt', $attachment_id));
                                                                                    $image       = wp_get_attachment_image($attachment_id, apply_filters('single_product_small_thumbnail_size', 'shop_thumbnail'), 0, $attr = array(
                                                                                        'title' => $image_title,
                                                                                        'alt'   => $image_title
                                                                                    ));
                                                                                    $image_class = esc_attr(implode(' ', $classes));
                                                                                    echo apply_filters('woocommerce_single_product_image_thumbnail_html', sprintf('<a href="%s" class="%s" title="%s" >%s</a>', $image_link, $image_class, $image_caption, $image), $attachment_id, $post->ID, $image_class);
                                                                                    $loop++;
                                                                                }
                                                                                ?>

                </div>
            <?php endif; ?>
        </div>
        <div class="summary entry-summary scrollable">
            <div class="summary-content">
                <?php
                $ric_wp_wip_qty     = get_post_meta($product_id, '_ric_wp_wip_qty', true);
                $ric_wp_wip_date    = get_post_meta($product_id, '_ric_wp_wip_date', true);
                $ric_wp_wip_lead_time   = get_post_meta($product_id, '_ric_wp_wip_lead_time', true);
                ?>
                <h1 class="product_title entry-title"><?php echo $product->get_name(); ?></h1>
                <strong class="price"><?php echo $product->get_price_html(); ?></strong>
                <div class="woocommerce-product-details__short-description">
                    <p><?php echo $product->get_short_description(); ?></p>
                </div>


                <table>

                    <tr class="quantity">
                        <th>

                            <?php if ($product->get_stock_quantity() < 0) { ?>
                                <label class="" for=""><strong><?php esc_html_e('On backorder:') ?> </strong></label>
                            <?php } else { ?>
                                <label class="" for=""><strong><?php esc_html_e('Quantity In Stock:') ?> </strong></label>
                            <?php } ?>
                        </th>
                        <td><span><?php echo $product->get_stock_quantity(); ?></span></td>
                    </tr>
                    <?php if (!empty($ric_wp_wip_qty)) { ?>
                        <tr class="wip_qty">
                            <th>
                                <label class="" for="">
                                    <strong> <?php esc_html_e('Work-In-Progress Qty: ');  ?></strong>
                                </label>


                            </th>
                            <td><span><?php echo $ric_wp_wip_qty; ?></span></td>
                        </tr>
                    <?php } ?>

                    <?php if (!empty($ric_wp_wip_date)) { ?>
                        <tr class="wip_date">
                            <th>
                                <label class="" for="">
                                    <strong> <?php esc_html_e('Work-In-Progress');  ?><br /><?php esc_html_e(' Completion Date: '); ?></strong>
                                </label>

                            </th>
                            <td> <span><?php echo $ric_wp_wip_date; ?></span></td>
                        </tr>
                    <?php } ?>


                    <?php if (!empty($ric_wp_wip_lead_time)) { ?>
                        <tr class="wip_date">
                            <th>
                                <label class="" for="">
                                    <strong> <?php esc_html_e('Lead time: ');  ?></strong>
                                </label>

                            </th>
                            <td>
                                <span><?php echo $ric_wp_wip_lead_time; ?></span>
                            </td>
                        </tr>
                    <?php } ?>

                    <?php if (!empty($product->get_sku())) { ?>
                        <tr class="sku">
                            <th>
                                <label class="" for=""><strong><?php esc_html_e('SKU:'); ?> </strong></label>

                            </th>
                            <td><span><?php echo $product->get_sku(); ?></span></td>
                        </tr>
                    <?php } ?>

                </table>

                <a href="<?php echo $product->get_permalink(); ?>" target="_blank"><?php esc_html_e('View More'); ?></a>

            </div>
        </div>
    <?php
            $resposnse['message'] = 'success';
            $resposnse['data'] = ob_get_clean();
            wp_send_json($resposnse);

    }
    die();
}

/**
 *  get cart item key from product id
 */

function ric_wp_get_cart_item_key_by_product_id($product_id)
{
    foreach (WC()->cart->get_cart() as $cart_item_key => $cart_item) {
        if ($cart_item['product_id'] == $product_id) {
            return $cart_item_key;
        }
    }
    return false;
}
if (!function_exists('ric_wp_get_quickorder_row_value')) {
    function ric_wp_get_quickorder_row_value($row, $field_name, $default = '')
    {
        if (!is_array($row)) {
            return $default;
        }

        if (array_key_exists($field_name, $row)) {
            return $row[$field_name];
        }

        foreach ($row as $field_data) {
            if (is_array($field_data) && array_key_exists($field_name, $field_data)) {
                return $field_data[$field_name];
            }
        }

        return $default;
    }
}

if (!function_exists('ric_wp_set_quickorder_row_value')) {
    function ric_wp_set_quickorder_row_value(&$row, $field_name, $value)
    {
        if (!is_array($row)) {
            $row = [];
        }

        if (array_key_exists($field_name, $row)) {
            $row[$field_name] = $value;
            return;
        }

        foreach ($row as $index => $field_data) {
            if (is_array($field_data) && array_key_exists($field_name, $field_data)) {
                $row[$index][$field_name] = $value;
                return;
            }
        }

        $row[] = [$field_name => $value];
    }
}

if (!function_exists('ric_wp_is_quickorder_backorder_row')) {
    function ric_wp_is_quickorder_backorder_row($row)
    {
        $row_qty = (int) ric_wp_get_quickorder_row_value($row, 'qorder_qty_order', 0);
        $stock_qty = (int) ric_wp_get_quickorder_row_value($row, 'qorder_qty_stock', 0);

        return $row_qty > 0 && $stock_qty <= 0;
    }
}

if (!function_exists('ric_wp_apply_two_shipment_backorder_max_date')) {
    function ric_wp_apply_two_shipment_backorder_max_date(&$quickorder_rows = null)
    {
        if ($quickorder_rows === null) {
            if (empty($_SESSION['quickorder']) || !is_array($_SESSION['quickorder'])) {
                return '';
            }

            $quickorder_rows = &$_SESSION['quickorder'];
        }

        if (empty($quickorder_rows) || !is_array($quickorder_rows)) {
            return '';
        }

        $max_backorder_date = '';
        $max_backorder_time = 0;

        foreach ($quickorder_rows as $row) {
            if (!ric_wp_is_quickorder_backorder_row($row)) {
                continue;
            }

            $ship_date = ric_wp_get_quickorder_row_value($row, 'qorder_eship_date', '');
            $ship_time = !empty($ship_date) ? strtotime($ship_date) : false;

            if ($ship_time && $ship_time > $max_backorder_time) {
                $max_backorder_time = $ship_time;
                $max_backorder_date = date('Y-m-d', $ship_time);
            }
        }

        if (empty($max_backorder_date)) {
            return '';
        }

        foreach ($quickorder_rows as &$row) {
            if (!ric_wp_is_quickorder_backorder_row($row)) {
                continue;
            }

            ric_wp_set_quickorder_row_value($row, 'qorder_eship_date', $max_backorder_date);
            ric_wp_set_quickorder_row_value($row, 'qorder_rship_date', '');
            ric_wp_set_quickorder_row_value($row, 'qorder_rship_date_html', '');
        }
        unset($row);

        return $max_backorder_date;
    }
}

if (!function_exists('ric_wp_apply_single_shipment_max_date')) {
    function ric_wp_apply_single_shipment_max_date(&$quickorder_rows = null)
    {
        if ($quickorder_rows === null) {
            if (empty($_SESSION['quickorder']) || !is_array($_SESSION['quickorder'])) {
                return '';
            }

            $quickorder_rows = &$_SESSION['quickorder'];
        }

        if (empty($quickorder_rows) || !is_array($quickorder_rows)) {
            return '';
        }

        $max_ship_date = '';
        $max_ship_time = 0;

        foreach ($quickorder_rows as $row) {
            $ship_date = ric_wp_get_quickorder_row_value($row, 'qorder_eship_date', '');
            $ship_time = !empty($ship_date) ? strtotime($ship_date) : false;

            if ($ship_time && $ship_time > $max_ship_time) {
                $max_ship_time = $ship_time;
                $max_ship_date = date('Y-m-d', $ship_time);
            }
        }

        if (empty($max_ship_date)) {
            return '';
        }

        foreach ($quickorder_rows as &$row) {
            ric_wp_set_quickorder_row_value($row, 'qorder_eship_date', $max_ship_date);
            ric_wp_set_quickorder_row_value($row, 'qorder_rship_date', '');
            ric_wp_set_quickorder_row_value($row, 'qorder_rship_date_html', '');
        }
        unset($row);

        return $max_ship_date;
    }
}


/**
 * Ajax Function to update quantity in QOT
 *
 *
 * @package Quick Order Table
 * @since 1.0.0
 */
add_action('wp_ajax_ric_wp_qorder_update_qty', 'ric_wp_qorder_update_qty');
add_action('wp_ajax_nopriv_ric_wp_qorder_update_qty', 'ric_wp_qorder_update_qty');

function ric_wp_qorder_update_qty()
{

    if (!session_id()) {
        session_start();
    }

    if (!isset($_POST['prod_id']) || !isset($_POST['qty_updated'])) {
        wp_send_json_error(['message' => 'Invalid request']);
    }

    $prod_ids        = isset($_POST['prod_id']) && is_array($_POST['prod_id']) ? array_map('sanitize_text_field', wp_unslash($_POST['prod_id'])) : [];
    $qty_updated     = isset($_POST['qty_updated']) && is_array($_POST['qty_updated']) ? array_map('sanitize_text_field', wp_unslash($_POST['qty_updated'])) : [];
    $rship_dates     = isset($_POST['rship_date']) && is_array($_POST['rship_date']) ? array_map('sanitize_text_field', wp_unslash($_POST['rship_date'])) : [];
    $row_changed_raw = isset($_POST['row_changed']) && is_array($_POST['row_changed']) ? array_map('absint', wp_unslash($_POST['row_changed'])) : [];
    $shipment_choice = !empty($_POST['shipment_choice'])
        ? sanitize_text_field(wp_unslash($_POST['shipment_choice']))
        : ($_SESSION['shipment_choice'] ?? 'single-shipment');
    if (empty($_POST['shipment_choice']) && function_exists('rushabh_get_current_shipment_choice')) {
        $shipment_choice = rushabh_get_current_shipment_choice();
    }
    $is_custom_shipment = ($shipment_choice === 'custom-shipment');

    $uniq_pro_ids = [];
    $qty_by_row = [];
    $rship_by_row = [];
    $rship_by_product = [];
    $qty_values_by_product = [];
    $row_changed = [];

    $_SESSION['shipment_choice'] = $shipment_choice;
    $_SESSION['cart_shipment_choice'] = $shipment_choice;

    if (function_exists('WC') && WC()->session) {
        WC()->session->set('shipment_choice', $shipment_choice);
        WC()->session->set('cart_shipment_choice', $shipment_choice);
    }

    /* ===============================
       COLLECT TOTAL QTY PER PRODUCT
    =============================== */

    foreach ($prod_ids as $index => $prod_id_raw) {

        $parts      = explode('-', $prod_id_raw);
        $row_id     = $parts[1] ?? $prod_id_raw;
        $product_id = qot_get_product_id($row_id);

        $input_qty = max(0, intval($qty_updated[$index]));
        $requested_ship_date = $is_custom_shipment ? ($rship_dates[$index] ?? '') : '';

        $qty_values_by_product[$product_id][] = $input_qty;
        $qty_by_row[$row_id] = $input_qty;
        $rship_by_row[$row_id] = $requested_ship_date;
        $row_changed[$row_id] = !empty($row_changed_raw[$index]);

        if (!empty($requested_ship_date)) {
            $rship_by_product[$product_id] = $requested_ship_date;
        }
    }

    foreach ($qty_values_by_product as $product_id => $qty_values) {
        $qty_values = array_filter(array_map('intval', $qty_values), static function ($qty) {
            return $qty > 0;
        });

        if (empty($qty_values)) {
            $uniq_pro_ids[$product_id] = 0;
            continue;
        }

        $unique_qty_values = array_unique($qty_values);

        if (in_array($shipment_choice, ['single-shipment', 'two-shipment'], true) && count($unique_qty_values) === 1) {
            $uniq_pro_ids[$product_id] = max($qty_values);
        } else {
            $uniq_pro_ids[$product_id] = array_sum($qty_values);
        }
    }

    if (function_exists('rtcwp_get_adjusted_capacity_summary')) {
        foreach ($uniq_pro_ids as $product_id => $product_qty) {
            $capacity = rtcwp_get_adjusted_capacity_summary($product_id);

            if (!empty($capacity['has_table']) && $product_qty > (int) $capacity['capacity']) {
                $uniq_pro_ids[$product_id] = max(0, (int) $capacity['capacity']);
            }
        }
    }

    /* ===============================
       UPDATE CART
    =============================== */

    foreach ($uniq_pro_ids as $product_id => $product_qty) {

        $found = false;

        foreach (WC()->cart->get_cart() as $cart_item_key => $cart_item) {

            if ((int)$cart_item['product_id'] === (int)$product_id) {

                if ($product_qty > 0) {
                    WC()->cart->set_quantity($cart_item_key, $product_qty, false);
                } else {
                    WC()->cart->remove_cart_item($cart_item_key);
                }

                $found = true;
                break;
            }
        }

        if (!$found && $product_qty > 0) {
            WC()->cart->add_to_cart($product_id, $product_qty);
        }
    }

    WC()->cart->calculate_totals();

    /* ===============================
       UPDATE SESSION STRUCTURE
    =============================== */

    foreach ($uniq_pro_ids as $product_id => $product_qty) {

        if ($shipment_choice === 'single-shipment') {

            ric_wp_rebuild_single_shipment_structure($product_id, $product_qty);
        } elseif ($shipment_choice === 'two-shipment') {

            //  Only here we allow split
            ric_wp_rebuild_two_shipment_structure($product_id, $product_qty);
        } elseif ($shipment_choice === 'multiple-shipment') {

            ric_wp_rebuild_multiple_shipment_structure($product_id, $product_qty);
        } elseif ($shipment_choice === 'custom-shipment') {

            ric_wp_rebuild_custom_shipment_structure($product_id, $product_qty, $rship_by_row);
        } else {

            // Keep existing structure
            foreach ($_SESSION['quickorder'] as $row_id => $rows) {

                if ((int) qot_get_product_id($row_id) === (int) $product_id) {

                    $row_qty = $qty_by_row[$row_id] ?? $product_qty;
                    $requested_ship_date = $is_custom_shipment ? ($rship_by_row[$row_id] ?? ($rship_by_product[$product_id] ?? '')) : '';
                    $unit_price = (float) ric_wp_get_quickorder_row_value($_SESSION['quickorder'][$row_id], 'qorder_unit_price', 0);

                    if (!$is_custom_shipment || !empty($row_changed[$row_id])) {
                        ric_wp_set_quickorder_row_value($_SESSION['quickorder'][$row_id], 'qorder_qty_order', $row_qty);
                        ric_wp_set_quickorder_row_value($_SESSION['quickorder'][$row_id], 'qorder_qty_consider', $row_qty);
                        ric_wp_set_quickorder_row_value($_SESSION['quickorder'][$row_id], 'qorder_total_price', $row_qty * $unit_price);
                        ric_wp_set_quickorder_row_value($_SESSION['quickorder'][$row_id], 'qorder_qty_order_html', qot_ric_qty_order_field($row_id, $row_qty));
                    }

                    ric_wp_set_quickorder_row_value($_SESSION['quickorder'][$row_id], 'qorder_rship_date', $requested_ship_date);
                    ric_wp_set_quickorder_row_value($_SESSION['quickorder'][$row_id], 'qorder_rship_date_html', $is_custom_shipment ? qot_ric_rdate_field($row_id, $unit_price, $requested_ship_date) : '');
                }
            }
        }
    }

    $single_shipment_delivery_date = '';
    if ($shipment_choice === 'single-shipment') {
        $single_shipment_delivery_date = ric_wp_apply_single_shipment_max_date();
    } elseif ($shipment_choice === 'two-shipment') {
        ric_wp_apply_two_shipment_backorder_max_date();
    }

    foreach ($uniq_pro_ids as $product_id => $product_qty) {
        $cart_item_key = ric_wp_get_cart_item_key_by_product_id($product_id);

        if (!$cart_item_key || empty(WC()->cart->cart_contents[$cart_item_key])) {
            continue;
        }

        $existing_meta = ($shipment_choice === 'single-shipment')
            ? []
            : (WC()->cart->cart_contents[$cart_item_key]['ric_wp_order_meta'] ?? []);
        $product_level_eship = '';

        foreach ($_SESSION['quickorder'] as $row_id => $rows) {
            if ((int) qot_get_product_id($row_id) !== (int) $product_id) {
                continue;
            }

            $meta_key = (string) $row_id;
            $eship_date = ric_wp_get_quickorder_row_value($rows, 'qorder_eship_date', '');
            $requested_ship_date = $is_custom_shipment ? ric_wp_get_quickorder_row_value($rows, 'qorder_rship_date', '') : '';

            if (empty($existing_meta[$meta_key]) || !is_array($existing_meta[$meta_key])) {
                $existing_meta[$meta_key] = [];
            }

            if (!empty($eship_date)) {
                $existing_meta[$meta_key]['ric_wp_eship_date'] = $eship_date;
                if (empty($product_level_eship)) {
                    $product_level_eship = $eship_date;
                }
            }

            if (!empty($requested_ship_date)) {
                $existing_meta[$meta_key]['ric_wp_rship_date'] = $requested_ship_date;
            } else {
                unset($existing_meta[$meta_key]['ric_wp_rship_date']);
            }
        }

        if (empty($existing_meta[$product_id]) || !is_array($existing_meta[$product_id])) {
            $existing_meta[$product_id] = [];
        }

        if (!empty($product_level_eship)) {
            $existing_meta[$product_id]['ric_wp_eship_date'] = $product_level_eship;
        }

        if (!$is_custom_shipment) {
            foreach ($existing_meta as $meta_key => $meta_data) {
                $base_product_id = (strpos((string) $meta_key, '_') !== false) ? explode('_', (string) $meta_key)[0] : (string) $meta_key;
                if ((string) $base_product_id === (string) $product_id && is_array($meta_data)) {
                    unset($existing_meta[$meta_key]['ric_wp_rship_date']);
                }
            }
        }

        WC()->cart->cart_contents[$cart_item_key]['ric_wp_order_meta'] = $existing_meta;
        WC()->cart->cart_contents[$cart_item_key]['ric_shipment_choice'] = $shipment_choice;

        if ($shipment_choice === 'single-shipment' && !empty($single_shipment_delivery_date)) {
            WC()->cart->cart_contents[$cart_item_key]['delivery_date'] = $single_shipment_delivery_date;
            WC()->cart->cart_contents[$cart_item_key]['ric_eship_date'] = $single_shipment_delivery_date;
        } else {
            unset(WC()->cart->cart_contents[$cart_item_key]['delivery_date'], WC()->cart->cart_contents[$cart_item_key]['ric_eship_date']);
        }
    }

    $_SESSION['quickorder_original'] = $_SESSION['quickorder'];

    if (WC()->cart) {
        WC()->cart->calculate_totals();
        WC()->cart->set_session();
    }

    /* ===============================
       RESPONSE
    =============================== */

    wp_send_json([
        'message'    => 'success',
        'data'       => qot_ric_tbody_data($_SESSION['quickorder']),
        'all_order'  => $_SESSION['quickorder'],
        'cart_total' => WC()->cart->get_cart_total(),
        'cart_count' => WC()->cart->get_cart_contents_count(),
        'cart_totals_html' => ric_wp_get_cart_totals_html()
    ]);
}

function ric_wp_rebuild_single_shipment_structure($product_id, $cart_qty)
{
    global $field;

    $product = wc_get_product($product_id);
    if (!$product) return;

    foreach ($_SESSION['quickorder'] as $row_id => $rows) {
        if ((int) qot_get_product_id($row_id) === (int) $product_id) {
            unset($_SESSION['quickorder'][$row_id]);
        }
    }

    if ($cart_qty <= 0) return;

    $stock_qty  = max(0, (int) $product->get_stock_quantity());
    $unit_price = (float) $product->get_price();
    $currency   = get_woocommerce_currency_symbol();
    $ship_date  = qot_ric_date_cacl($product_id, $stock_qty, $cart_qty);
    $row_id     = (string) $product_id;

    $quickorder = [
        'qorder_id'             => $product_id,
        'qorder_did'            => $row_id,
        'qorder_quickview'      => '<button data-id="' . $row_id . '" class="qorder_quickview"><i class="fa fa-info-circle"></i></button>',
        'qorder_name'           => $product->get_name(),
        'qorder_sku'            => $product->get_sku(),
        'qorder_description'    => $product->get_short_description(),
        'qorder_qty_stock'      => $stock_qty,
        'qorder_qty_order'      => $cart_qty,
        'qorder_qty_consider'   => $cart_qty,
        'qorder_qty_order_html' => qot_ric_qty_order_field($row_id, $cart_qty),
        'qorder_unit_price'     => $unit_price,
        'qorder_currency'       => $currency,
        'qorder_total_price'    => $cart_qty * $unit_price,
        'qorder_eship_date'     => $ship_date,
        'qorder_rship_date'     => '',
        'qorder_rship_date_html' => '',
        'action'                => qot_ric_delete_order($row_id, true, true),
    ];

    foreach ($field as $index => $fname) {
        $_SESSION['quickorder'][$row_id][$index][$fname] = $quickorder[$fname] ?? '';
    }
}


function ric_wp_rebuild_two_shipment_structure($product_id, $cart_qty)
{
    global $field;

    $product = wc_get_product($product_id);
    if (!$product) return;

    $stock_qty  = max(0, (int)$product->get_stock_quantity());
    $unit_price = (float)$product->get_price();
    $currency   = get_woocommerce_currency_symbol();

    // Remove only this product rows
    foreach ($_SESSION['quickorder'] as $key => $val) {
        if (qot_get_product_id($key) == $product_id) {
            unset($_SESSION['quickorder'][$key]);
        }
    }

    if ($cart_qty <= 0) return;

    $stock_part     = min($cart_qty, $stock_qty);
    $backorder_part = max(0, $cart_qty - $stock_qty);

    $action = qot_ric_delete_order($product_id, false, false);

    /* ===== STOCK ROW ===== */
    if ($stock_part > 0) {

        $row_id = $product_id;

        $row = [
            'qorder_id'             => $product_id,
            'qorder_did'            => $row_id,
            'qorder_quickview'      => '<button data-id="' . $row_id . '" class="qorder_quickview"><i class="fa fa-info-circle"></i></button>',
            'qorder_name'           => $product->get_name(),
            'qorder_sku'            => $product->get_sku(),
            'qorder_qty_stock'      => $stock_qty,
            'qorder_qty_order'      => $stock_part,
            'qorder_qty_consider'   => $stock_part,
            'qorder_qty_order_html' => qot_ric_qty_order_field($row_id, $stock_part),
            'qorder_unit_price'     => $unit_price,
            'qorder_currency'       => $currency,
            'qorder_total_price'    => $stock_part * $unit_price,
            'qorder_eship_date'     => qot_ric_date_cacl($product_id, $stock_qty, $stock_part),
            'qorder_rship_date'     => '',
            'qorder_rship_date_html' => '',
            'action'                => $action
        ];

        foreach ($field as $fname) {
            $_SESSION['quickorder'][$row_id][][$fname] = $row[$fname] ?? '';
        }
    }

    /* ===== BACKORDER ROW ===== */
    if ($backorder_part > 0) {

        $row_id = $product_id . '_0';
        // $ship_date = qot_ric_date_cacl($product_id, 0, $backorder_part);
        $ship_date = qot_ric_date_cacl($product_id, $backorder_part, $cart_qty);
        $row = [
            'qorder_id'             => $product_id,
            'qorder_did'            => $row_id,
            'qorder_quickview'      => '<button data-id="' . $row_id . '" class="qorder_quickview"><i class="fa fa-info-circle"></i></button>',
            'qorder_name'           => $product->get_name(),
            'qorder_sku'            => $product->get_sku(),
            'qorder_qty_stock'      => 0,
            'qorder_qty_order'      => $backorder_part,
            'qorder_qty_consider'   => $backorder_part,
            'qorder_qty_order_html' => qot_ric_qty_order_field($row_id, $backorder_part),
            'qorder_unit_price'     => $unit_price,
            'qorder_currency'       => $currency,
            'qorder_total_price'    => $backorder_part * $unit_price,
            'qorder_eship_date'     => $ship_date,
            // 'qorder_rship_date'     => $ship_date,
            'qorder_rship_date'     => '',
            'qorder_rship_date_html' => '',
            // 'qorder_rship_date_html'=> qot_ric_rdate_field($row_id, $unit_price, $ship_date),
            'action'                => $action
        ];

        foreach ($field as $fname) {
            $_SESSION['quickorder'][$row_id][][$fname] = $row[$fname] ?? '';
        }
    }
}

function ric_wp_rebuild_custom_shipment_structure($product_id, $cart_qty, $requested_dates = [])
{
    global $field;

    $product = wc_get_product($product_id);
    if (!$product) return;

    $existing_requested_dates = [];
    foreach ($_SESSION['quickorder'] as $row_id => $rows) {
        if ((int) qot_get_product_id($row_id) === (int) $product_id) {
            $existing_requested_dates[$row_id] = ric_wp_get_quickorder_row_value($rows, 'qorder_rship_date', '');
            unset($_SESSION['quickorder'][$row_id]);
        }
    }

    if ($cart_qty <= 0) return;

    $stock_qty  = max(0, (int) $product->get_stock_quantity());
    $unit_price = (float) $product->get_price();
    $currency   = get_woocommerce_currency_symbol();

    $stock_row_qty     = min($cart_qty, $stock_qty);
    $backorder_row_qty = max(0, $cart_qty - $stock_qty);

    if ($stock_row_qty > 0) {
        $row_id = (string) $product_id;
        $ship_date = qot_ric_date_cacl($product_id, $stock_qty, $stock_row_qty);
        $requested_ship_date = $requested_dates[$row_id] ?? ($existing_requested_dates[$row_id] ?? '');

        $quickorder = [
            'qorder_id'             => $product_id,
            'qorder_did'            => $row_id,
            'qorder_quickview'      => '<button data-id="' . $row_id . '" class="qorder_quickview"><i class="fa fa-info-circle"></i></button>',
            'qorder_name'           => $product->get_name(),
            'qorder_sku'            => $product->get_sku(),
            'qorder_description'    => $product->get_short_description(),
            'qorder_qty_stock'      => $stock_qty,
            'qorder_qty_order'      => $stock_row_qty,
            'qorder_qty_consider'   => $stock_row_qty,
            'qorder_qty_order_html' => qot_ric_qty_order_field($row_id, $stock_row_qty),
            'qorder_unit_price'     => $unit_price,
            'qorder_currency'       => $currency,
            'qorder_total_price'    => $stock_row_qty * $unit_price,
            'qorder_eship_date'     => $ship_date,
            'qorder_rship_date'     => $requested_ship_date,
            'qorder_rship_date_html' => qot_ric_rdate_field($row_id, $unit_price, $requested_ship_date),
            'action'                => qot_ric_delete_order($row_id, true, true, 'custom-shipment'),
        ];

        foreach ($field as $index => $fname) {
            $_SESSION['quickorder'][$row_id][$index][$fname] = $quickorder[$fname] ?? '';
        }
    }

    if ($backorder_row_qty > 0) {
        $row_id = $product_id . '_0';
        // Use $cart_qty (total order qty) as desired_qty so the availability
        // table resolves to the correct date block for the full order.
        $ship_date = qot_ric_date_cacl($product_id, 0, $cart_qty);
        $requested_ship_date = $requested_dates[$row_id] ?? ($existing_requested_dates[$row_id] ?? $ship_date);

        $quickorder = [
            'qorder_id'             => $product_id,
            'qorder_did'            => $row_id,
            'qorder_quickview'      => '<button data-id="' . $row_id . '" class="qorder_quickview"><i class="fa fa-info-circle"></i></button>',
            'qorder_name'           => $product->get_name(),
            'qorder_sku'            => $product->get_sku(),
            'qorder_description'    => $product->get_short_description(),
            'qorder_qty_stock'      => 0,
            'qorder_qty_order'      => $backorder_row_qty,
            'qorder_qty_consider'   => $backorder_row_qty,
            'qorder_qty_order_html' => qot_ric_qty_order_field($row_id, $backorder_row_qty),
            'qorder_unit_price'     => $unit_price,
            'qorder_currency'       => $currency,
            'qorder_total_price'    => $backorder_row_qty * $unit_price,
            'qorder_eship_date'     => $ship_date,
            'qorder_rship_date'     => $requested_ship_date,
            'qorder_rship_date_html' => qot_ric_rdate_field($row_id, $unit_price, $requested_ship_date),
            'action'                => qot_ric_delete_order($row_id, true, true, 'custom-shipment'),
        ];

        foreach ($field as $index => $fname) {
            $_SESSION['quickorder'][$row_id][$index][$fname] = $quickorder[$fname] ?? '';
        }
    }
}

function ric_wp_rebuild_multiple_shipment_structure($product_id, $cart_qty)
{
    global $field;

    $product = wc_get_product($product_id);
    if (!$product) return;

    foreach ($_SESSION['quickorder'] as $row_id => $rows) {
        if ((int) qot_get_product_id($row_id) === (int) $product_id) {
            unset($_SESSION['quickorder'][$row_id]);
        }
    }

    if ($cart_qty <= 0) return;

    $stock_qty  = max(0, (int) $product->get_stock_quantity());
    $unit_price = (float) $product->get_price();
    $currency   = get_woocommerce_currency_symbol();
    $remaining  = (int) $cart_qty;
    $split_config = [];

    $availability_table = function_exists('rtcwp_get_adjusted_capacity')
        ? rtcwp_get_adjusted_capacity($product_id)
        : get_post_meta($product_id, 'availability_table', true);
    if (!empty($availability_table['get_capacity'])) {
        foreach ($availability_table['get_capacity'] as $item) {
            if ($remaining <= 0) {
                break;
            }

            $batch_qty = (int) ($item['qty'] ?? 0);
            if ($batch_qty <= 0) {
                continue;
            }

            $take = min($remaining, $batch_qty);
            $availability_type = $item['type'] ?? '';
            $ship_date = $item['date_available'] ?? '';
            $ship_case = 3;

            if ($availability_type === 'in_stock') {
                $ship_date = date('Y-m-d', strtotime('+2 days'));
                $ship_case = 1;
            } elseif ($availability_type === 'work_order') {
                $ship_case = 2;
            } elseif ($availability_type === 'capacity_to_work') {
                $ship_case = 3;
            } elseif ($availability_type === 'lead_time') {
                $ship_case = 4;
            }

            $split_config[] = [
                'qty'  => $take,
                'date' => !empty($ship_date) ? isHolidays($ship_date, $product_id, $ship_case) : qot_ric_date_cacl($product_id, 0, $take),
            ];
            $remaining -= $take;
        }
    }

    if ($remaining > 0) {
        $split_config[] = [
            'qty'  => $remaining,
            'date' => qot_ric_date_cacl($product_id, 0, $remaining),
        ];
    }

    foreach ($split_config as $index => $batch) {
        $row_id = $product_id . '_' . $index;
        $qty = (int) ($batch['qty'] ?? 0);
        if ($qty <= 0) {
            continue;
        }

        $quickorder = [
            'qorder_id'             => $product_id,
            'qorder_did'            => $row_id,
            'qorder_quickview'      => '<button data-id="' . $row_id . '" class="qorder_quickview"><i class="fa fa-info-circle"></i></button>',
            'qorder_name'           => $product->get_name(),
            'qorder_sku'            => $product->get_sku(),
            'qorder_description'    => $product->get_short_description(),
            'qorder_qty_stock'      => $stock_qty,
            'qorder_qty_order'      => $qty,
            'qorder_qty_consider'   => $qty,
            'qorder_qty_order_html' => qot_ric_qty_order_field($row_id, $qty),
            'qorder_unit_price'     => $unit_price,
            'qorder_currency'       => $currency,
            'qorder_total_price'    => $qty * $unit_price,
            'qorder_eship_date'     => $batch['date'] ?? '',
            'qorder_rship_date'     => '',
            'qorder_rship_date_html' => '',
            'action'                => qot_ric_delete_order($row_id, true, true, 'multiple-shipment'),
        ];

        foreach ($field as $field_index => $fname) {
            $_SESSION['quickorder'][$row_id][$field_index][$fname] = $quickorder[$fname] ?? '';
        }
    }
}


function ric_wp_rebuild_quickorder_from_cart_qty($product_id, $shipment_choice)
{
    global $field;

    $product = wc_get_product($product_id);
    if (!$product) return;

    $unit_price = (float) $product->get_price();
    $currency   = get_woocommerce_currency_symbol();
    $stock_qty  = (int) $product->get_stock_quantity();

    $cart_qty = 0;

    foreach (WC()->cart->get_cart() as $cart_item) {
        if ((int)$cart_item['product_id'] === (int)$product_id) {
            $cart_qty += (int)$cart_item['quantity'];
        }
    }

    // 🔹 Remove all existing session rows for this product
    foreach ($_SESSION['quickorder'] as $key => $val) {
        if (qot_get_product_id($key) == $product_id) {
            unset($_SESSION['quickorder'][$key]);
        }
    }

    if ($cart_qty <= 0) return;

    $stock_row_qty     = min($cart_qty, $stock_qty);
    $backorder_row_qty = max(0, $cart_qty - $stock_qty);


    if ($shipment_choice != 'custom-shipment') {
        $action = qot_ric_delete_order($product_id, false, false);
    } else {
        $action = qot_ric_delete_order($product_id, true, false);
    }

    /* =====================================================
    CREATE STOCK ROW
    ===================================================== */
    if ($stock_row_qty > 0) {

        $row_id = $product_id;

        $quickorder = [
            'qorder_id'             => $product_id,
            'qorder_did'            => $row_id,
            'qorder_quickview'      => '<button data-id="' . $row_id . '" class="qorder_quickview"><i class="fa fa-info-circle"></i></button>',
            'qorder_name'           => $product->get_name(),
            'qorder_sku'            => $product->get_sku(),
            'qorder_description'    => $product->get_short_description(),
            'qorder_qty_stock'      => $stock_qty,
            'qorder_qty_order'      => $stock_row_qty,
            'qorder_qty_consider'   => $stock_row_qty,
            'qorder_qty_order_html' => qot_ric_qty_order_field($row_id, $stock_row_qty),
            'qorder_unit_price'     => $unit_price,
            'qorder_currency'       => $currency,
            'qorder_total_price'    => $stock_row_qty * $unit_price,
            'qorder_eship_date'     => qot_ric_date_cacl($product_id, $stock_qty, $stock_row_qty),
            'qorder_rship_date'     => '',
            'qorder_rship_date_html' => '',
            'action'                => $action
        ];

        foreach ($field as $fname) {
            $_SESSION['quickorder'][$row_id][][$fname] = $quickorder[$fname] ?? '';
        }
    }

    /* =====================================================
    CREATE BACKORDER ROW
    ===================================================== */

    // echo $backorder_row_qty.'backorder_row_qty';
    if ($backorder_row_qty > 0) {

        $row_id = $product_id . '_0';

        $ship_date = qot_ric_date_cacl($product_id, 0, $backorder_row_qty);

        $quickorder = [
            'qorder_id'             => $product_id,
            'qorder_did'            => $row_id,
            'qorder_quickview'      => '<button data-id="' . $row_id . '" class="qorder_quickview"><i class="fa fa-info-circle"></i></button>',
            'qorder_name'           => $product->get_name(),
            'qorder_sku'            => $product->get_sku(),
            'qorder_description'    => $product->get_short_description(),
            'qorder_qty_stock'      => 0,
            'qorder_qty_order'      => $backorder_row_qty,
            'qorder_qty_consider'   => $backorder_row_qty,
            'qorder_qty_order_html' => qot_ric_qty_order_field($row_id, $backorder_row_qty),
            'qorder_unit_price'     => $unit_price,
            'qorder_currency'       => $currency,
            'qorder_total_price'    => $backorder_row_qty * $unit_price,
            'qorder_eship_date'     => $ship_date,
            'qorder_rship_date'     => $ship_date,
            'qorder_rship_date_html' => qot_ric_rdate_field($row_id, $unit_price, $ship_date),
            'action'                => $action
        ];

        foreach ($field as $fname) {
            $_SESSION['quickorder'][$row_id][][$fname] = $quickorder[$fname] ?? '';
        }
    }

    $_SESSION['quickorder_original'] = $_SESSION['quickorder'];
}


// Clear session on init hook or a custom action
// add_action('init', 'clear_session_on_custom_action');

// function clear_session_on_custom_action() {
    
//             session_unset();
//             session_destroy();
    
// }

/**
 * Function return total consider quanity along with same items added in QOT
 *
 *
 * @package Quick Order Table
 * @since 1.0.0
 */
function qot_get_consider_total_qty()
{
    /* Get all uniq id */
    $total_uniq_id = array();
    $exist_order_id = get_exist_order_id();

    foreach ($exist_order_id as $order_id) {
        $total_uniq_id[] = qot_get_product_id($order_id);
    }
    $total_uniq_id = array_unique($total_uniq_id);

    /* Get same product from unique id */
    $total = array();
    $consider_qty_id = array();

    foreach ($exist_order_id as $productid) {
        $consider_qty_id[$productid]['id'] = qot_get_product_id($productid);
        $consider_qty_id[$productid]['qty'] = qot_ric_get_product_qty($productid);
        $consider_qty_id[$productid]['consider_qty'] = qot_ric_get_exist_consider_qty($productid);
    }


    // Make Separate Consider Qty
    $total_consider = array();
    foreach ($consider_qty_id as $p_id => $qty) {
        $product_id = qot_get_product_id($p_id);
        if ($qty['id'] == $product_id) {
            $total[$product_id][] = (int)$qty['qty'];
        }
        $total_consider[$p_id]['consider_qty'] = array_sum($total[$product_id]);
    }



    return $total_consider;
}

function qot_apply_sum_qty($product_id)
{
    $get_qty = 0;
    foreach ($_SESSION['quickorder'] as $id => $quickorders) {
        if (strpos($id, $product_id) !== false) {
            $get_id = explode("_", $id);

            if ($get_id[0] == $product_id) {
                $i = 0;
                foreach ($field as $key) {
                    if ($key == 'qorder_qty_order') {
                        $total_get_qty = $_SESSION['quickorder'][$id][$i]['qorder_qty_order'];
                        $get_qty = $get_qty + $total_get_qty;


                        $shipdate = qot_ric_date_cacl($product_id, $qty_in_stock, $get_qty);
                    }

                    if ($key == 'qorder_eship_date') {
                        $_SESSION['quickorder'][$id][$i]['qorder_eship_date'] = $shipdate;
                    }

                    $i++;
                }
                // $get_qty[]=
            }
        }
        // if(!empty($total_get_qty)){
        //  //$total_get_qty= array_sum($get_qty);
        //  echo $total_get_qty. " ";
        //  $shipdate = qot_ric_date_cacl($product_id, $qty_in_stock, $total_get_qty);
        //  echo $shipdate;
        //  $i=0;
        //  foreach ($field as $key) {

        //      if($key=='qorder_eship_date'){
        //          $_SESSION['quickorder'][$prod_id][$i]['qorder_eship_date']= $shipdate;
        //      }



        //      $i++;
        //  }
        // }
    }
}

/**
 * Function return final shipping date after calculation
 *
 *
 * @package Quick Order Table
 * @since 1.0.0
 */
function qot_ric_date_cacl($product_id, $qty_in_stock, $desired_qty = 1)
{


    $qty_in_stock = max(0, intval($qty_in_stock));
    $desired_qty = max(0, intval($desired_qty));
    $get_availability = function_exists('rtcwp_get_adjusted_capacity')
        ? rtcwp_get_adjusted_capacity($product_id)
        : get_post_meta($product_id, 'availability_table', true);
    $final_ship_date = '';
    $avail_blocks = $get_availability['get_capacity'] ?? [];
    // if(!empty($qty_in_stock)){
    //     $desired_qty = $desired_qty + $qty_in_stock;
    // }

    $all_zero = true;

    foreach ($avail_blocks as $block) {
        if (intval($block['qty'] ?? 0) > 0) {
            $all_zero = false;
            break;
        }
    }
    if (!$all_zero) {


        // if (!empty($avail_blocks)) {
        $_product = wc_get_product($product_id);
        $in_stock_qty = $_product->get_stock_quantity();
        // Use actual stock (not meta)
        $remaining_qty = $desired_qty - $in_stock_qty;
        $remaining_qty = max(0, $remaining_qty); // don't allow negative

        $cumulative_qty = 0;
        $ship_case = 0;
        $ship_date = '';

        // Sort blocks by date ascending
        // usort($avail_blocks, function ($a, $b) {
        //     return strtotime($a['date_available'] ?? '2099-12-31') - strtotime($b['date_available'] ?? '2099-12-31');
        // });
        $ss = array();

        foreach ($avail_blocks as $block) {
            $block_type = $block['type'] ?? '';
            $block_qty = intval($block['qty'] ?? 0);
            $block_date = $block['date_available'] ?? '';

            if (!in_array($block_type, ['in_stock', 'work_order', 'capacity_to_work'])) continue;
            if (empty($block_date) || $block_qty <= 0) continue;

            // Add this block's quantity
            $cumulative_qty += $block_qty;

            // Check if this block satisfies the required quantity

            if ($cumulative_qty >= $desired_qty) {
                //  $ship_date = $block_date;
                // if ($block_type === 'in_stock') $ship_case = 1;
                // elseif ($block_type === 'work_order') $ship_case = 2;
                // elseif ($block_type === 'capacity_to_work') $ship_case = 3;
                if ($block_type === 'in_stock') {
                    $ship_case = 1;
                    $ship_date = date('Y-m-d', strtotime('+2 days')); // Force today + 2 days
                } elseif ($block_type === 'work_order') {
                    $ship_case = 2;
                    $ship_date = $block_date;
                } elseif ($block_type === 'capacity_to_work') {
                    $ship_case = 3;
                    $ship_date = $block_date;
                }
                $ss[] = $ship_case;
                break;
            }
        }

        // Fallback to lead_time if stock/work_order/capacity not enough
        if ($cumulative_qty < $desired_qty) {
            foreach ($avail_blocks as $block) {
                if ($block['type'] === 'lead_time' && !empty($block['date_available'])) {
                    $ship_date = $block['date_available'];
                    $ship_case = 4;
                    break;
                }
            }
        }

        // Skip for virtual products
        $get_product_type = get_post_meta($product_id, '_virtual', true);
        if ($get_product_type === 'yes') {
            $final_ship_date = '';
        } else {
            $final_ship_date = isHolidays($ship_date, $product_id, $ship_case);
        }
    } else {

        $_product = wc_get_product($product_id);
        $in_stock_qty = $_product->get_stock_quantity();


        if ($qty_in_stock <= $in_stock_qty && $in_stock_qty > 0) {
            $ship_date = date('Y-m-d', strtotime('+2 days'));
            $ship_case = 1;
        }

        $wip_qty = get_post_meta($product_id, '_ric_wp_wip_qty', true);

        $wip_qty = !empty($wip_qty) ? $wip_qty : 0;

        if ($qty_in_stock <= $wip_qty && $wip_qty <= ($qty_in_stock + $wip_qty) && $in_stock_qty < $desired_qty) {
            $ship_date = get_post_meta($product_id, '_ric_wp_wip_date', true);
            if (!empty($ship_date)) {
                $ship_date = date('Y-m-d', strtotime($ship_date));
            } else {
                $ship_date = '';
            }
            $ship_case = 2;
        }

        //If qty desired > qty in stock + qty in process, the earliest ship date is today + standard lead time
        if (($qty_in_stock + $wip_qty) > $wip_qty && $wip_qty < $qty_in_stock) {
            $wip_lead_time =  get_post_meta($product_id, '_ric_wp_wip_lead_time', true);
            $wip_lead_time = $wip_lead_time;
            if (!empty($wip_lead_time)) {
                $ship_date =  date('Y-m-d', strtotime('+' . $wip_lead_time . ' days'));
                $ship_date =  date('Y-m-d', strtotime($ship_date));
            } else {
                $ship_date = '';
            }
            $ship_case = 3;
        }
        // echo $qty_in_stock. " qty_in_stock ";
        // echo $wip_qty. " wip_qty ";
        $get_product_type = get_post_meta($product_id, '_virtual', true);

        if ($get_product_type == 'yes') {
            $final_ship_date = '';
        } else {

            // echo "ship_date: ".$ship_date." ship_case: ".$ship_case;
            $final_ship_date = isHolidays($ship_date, $product_id, $ship_case);
        }
    }
    //$getDays = isWeekend($final_ship_date);

    //$returnDate = date('Y-m-d', strtotime($final_ship_date . ' +'.$getDays.' day'));
    return $final_ship_date;
}



/**
 * Get product id from QOT
 *
 *
 * @package Quick Order Table
 * @since 1.0.0
 */
function qot_get_product_id($prod_id)
{
    if (strpos($prod_id, '_') !== false) {
        $exist_key = explode("_", $prod_id);
        $product_id = $exist_key[0];
    } else {
        $product_id = $prod_id;
    }
    return $product_id;
}

/**
 * Ajax function to upated date of QOT(Quick Order Table)
 *
 *
 * @package Quick Order Table
 * @since 1.0.0
 */
add_action('wp_ajax_ric_wp_qorder_update_date', 'ric_wp_qorder_update_date');
add_action('wp_ajax_nopriv_ric_wp_qorder_update_date', 'ric_wp_qorder_update_date');

function ric_wp_qorder_update_date()
{
    global $field;
    $resposnse = array();
    if (isset($_POST['prod_id']) && isset($_POST['date_updated'])) {
        $prod_id = $_POST['prod_id'];
        $product_id = qot_get_product_id($prod_id);
        $product = wc_get_product($product_id);
        $unit_price = $product->get_price();
        $date_updated = $_POST['date_updated'];

        $i = 0;
        foreach ($field as $key) {
            if ($key == 'qorder_rship_date') {
                $_SESSION['quickorder'][$prod_id][$i]['qorder_rship_date'] = $date_updated;
            }
            if ($key == 'qorder_rship_date_html') {
                $_SESSION['quickorder'][$prod_id][$i]['qorder_rship_date_html'] = qot_ric_rdate_field($prod_id, $unit_price, $date_updated);
            }
            $i++;
        }


        $response['message'] = 'success';

        wp_send_json($response);
        exit();
    }
}

/**
 * Ajax function to maximum quantity avalible on product api(Quick Order Table)
 *
 *
 * @package Quick Order Table
 * @since 1.0.0
 */

add_action('wp_ajax_ric_wp_get_total_quantity', 'ric_wp_get_total_quantity');
add_action('wp_ajax_nopriv_ric_wp_get_total_quantity', 'ric_wp_get_total_quantity');

function ric_wp_get_total_quantity()
{
    $product_get_id = $_POST['product_get_id'];
    $product            = wc_get_product($product_get_id);
    $ric_wp_get_total_quantity = get_post_meta($product_get_id, '_ric_wp_wip_qty', true);
    $total_qt = $_POST['total_qt'];
    $product_get_require_qty = $_POST['product_get_require_qty'];

    if (! empty(get_post_meta($product_get_id, 'availability_table', true))) {
        $availabilities_data = get_post_meta($product_get_id, 'availability_table', true);
        $availability_table_data = $availabilities_data['get_capacity'];
    } else {
        $availability_table_data = array();
    }

    $price = $product->get_price();

    if (empty($price) || $price <= 0 || ! $product->is_purchasable()) {

        wp_send_json(array(
            'message' => 'no_price',
            'product_id' => $product_get_id,
            'total_qty' => 0,
            'price' => '',
            'message_txt' => 'Sorry, this product cannot be purchased.'
        ));
    }

    if (! empty($availability_table_data)) {

        $price = $product->get_price();
        $availabilities = get_post_meta($product_get_id, 'availability_table', true);

        $availability_table = $availabilities['get_capacity'];
        $in_stock_date = $availability_table[0]['date_available'] ?? '';
        $in_stock_qty  = $availability_table[0]['qty'] ?? 0;

        $work_order_date = $availability_table[1]['date_available'] ?? '';
        $work_order_qty  = $availability_table[1]['qty'] ?? 0;

        $capacity_to_work_date = $availability_table[2]['date_available'] ?? '';
        $capacity_to_work_qty  = $availability_table[2]['qty'] ?? 0;

        $lead_time = $availability_table[3]['date_available'] ?? '';

        // Calculate the total quantity by summing all `qty` values
        $total_qty = 0;
        foreach ($availability_table as $availability) {
            if (isset($availability['qty']) && is_numeric($availability['qty'])) {
                $total_qty += $availability['qty'];
            }
        }

        $response = array(
            'message' => 'success',
            'product_id' => $product_get_id,
            'total_qty' => $total_qty,
            'price' => $price,

        );

        // WC()->cart->add_to_cart($product_get_id, $total_qty);

        // Optionally, print or use the total quantity
        wp_send_json($response);
    } elseif (!empty(get_post_meta($product_get_id, '_ric_wp_wip_qty', true))) {
        $price = $product->get_price();
        $total_qty      = $total_qty + $product->get_stock_quantity();
        $ric_wp_get_total_quantity = get_post_meta($product_get_id, '_ric_wp_wip_qty', true);
        if (!empty($ric_wp_get_total_quantity)) {
            $total_qty = $total_qty + $ric_wp_get_total_quantity;
        }

        $response = array(
            'message' => 'success',
            'product_id' => $product_get_id,
            'total_qty' => $total_qty,
            'price' => $price,

        );

        // WC()->cart->add_to_cart($product_get_id, $total_qty);

        // Optionally, print or use the total quantity
        wp_send_json($response);
    } else {
        $total_qty = 0;
        $response = array(
            'message' => 'insuccess',
            'product_id' => $product_get_id,
            'total_qty' => $total_qty,
            'price' => '',

        );
        wp_send_json($response);
    }
    exit();
}



/**
 * Woocommerce filter hook - to add custom data to cart
 *
 *
 * @package Quick Order Table
 * @since 1.0.0
 */
function qot_ric_individual_cart_items($cart_item_data, $product_id)
{
    global $woocommerce;
    $items = $woocommerce->cart->get_cart();
    $custom_data  = array();
    $rship_date = array();

    $availabilities = get_post_meta($product_id, 'availability_table', true);

    if (! empty($availabilities)) {
        // $availability_table = $availabilities['get_capacity'];


        // $in_stock_date = $availability_table[0]['date_available'] ?? '';
        // $in_stock_qty  = $availability_table[0]['qty'] ?? '';

        // $work_order_date = $availability_table[1]['date_available'] ?? '';
        // $work_order_qty  = $availability_table[1]['qty'] ?? '';

        // $capacity_to_work_date = $availability_table[2]['date_available'] ?? '';
        // $capacity_to_work_qty  = $availability_table[2]['qty'] ?? '';

        // $lead_time = $availability_table[3]['date_available'] ?? '';

        $in_stock_qty = 0;
        $in_stock_date = '';

        if (!empty($availabilities['get_capacity'])) {
            foreach ($availabilities['get_capacity'] as $capacity) {
                if (isset($capacity['type']) && $capacity['type'] === 'in_stock') {
                    $in_stock_qty = isset($capacity['qty']) ? (int)$capacity['qty'] : 0;
                    $in_stock_date = $capacity['date_available'] ?? '';
                    break;
                }
            }
        } else {
            $in_stock_qty = '';
        }
    } else {
        $in_stock_qty = '';
    }
    $total_quantity_in_cart = 0;
    foreach ($items as $cart_item) {
        if ($cart_item['product_id'] === $product_id) {
            $total_quantity_in_cart += $cart_item['quantity'];
        }
    }

    $product_details    = wc_get_product($product_id);

    $avail_qty_stock_data = $product_details->get_stock_quantity();
    $backorders_allowed = $product_details->backorders_allowed();
    // Check if the combined quantity is within the available stock
    if ($total_quantity_in_cart > $avail_qty_stock_data || $total_quantity_in_cart >= $in_stock_qty) {
        // Only add the unique key if the total quantity is within the available stock
        if ($avail_qty_stock_data <= 0 && $backorders_allowed) {
            $cart_item_data['backorders'] = 'yes';
        }
        $unique_cart_item_key = md5(microtime() . rand());
        $cart_item_data['unique_key_override'] = uniqid('split_', true);
    }
    $get_product_type = get_post_meta($product_id, '_virtual', true);

    if ($get_product_type == 'yes') {
        $cart_item_data['get_product_type'] = 'virtual';
    } else {
        $cart_item_data['get_product_type'] = 'physical';
    }


    if ((isset($_REQUEST['add-to-cart']) && !empty($_REQUEST['add-to-cart'])) || (isset($_REQUEST['wc-ajax']) && $_REQUEST['wc-ajax'] == 'add_to_cart')) {
        $cart = WC()->cart;
        $desired_qty = $_REQUEST['quantity'];
        $total_qty = $desired_qty;
        // Add the quantity already in the cart for this product
        $existing_qty = 0;
        foreach ($items as $cart_item) {
            if ($cart_item['product_id'] === $product_id) {
                $existing_qty += $cart_item['quantity'];
            }
        }

        if ($cart && !empty($cart->get_cart())) {
            foreach ($cart->get_cart() as $item) {
                if ($item['product_id'] == $product_id) {
                    $total_qty += $item['quantity'];
                }
            }
        }
        // Total desired quantity = existing + newly added
        $product    = wc_get_product($product_id);
        $avail_qty_stock = $product->get_stock_quantity();
        $desired_qty += $existing_qty;
        if ($desired_qty > $avail_qty_stock) {
            // Partially fulfill from stock, subtract available
            $desired_qty -= $avail_qty_stock_data;
        }

        $cart_item_data['custom_product_id'] = $product_id;
        $qorder_eship_date = qot_ric_date_cacl($product_id, $avail_qty_stock_data, $total_qty);
        $rship_date['ric_wp_eship_date'] = $qorder_eship_date;


        $custom_data[$product_id] = $rship_date;
        //$cart_item_data['ric_wp_order_meta_data'] = $custom_data;
        $cart_item_data['ric_wp_order_meta'] = $custom_data;

        // $cart_item_data['ric_eship_date'] = $qorder_eship_date;
    }

    // echo '<pre>';
    // print_r($cart_item_data);
    // '</pre>';

    return $cart_item_data;
}
add_filter('woocommerce_add_cart_item_data', 'qot_ric_individual_cart_items', 10, 2);


/**
 * Add a text field to each cart item
 */
function prefix_after_cart_item_name($cart_item, $cart_item_key)
{
    $qorder_qty_consider = array();

    $product_id = $cart_item['product_id'];
    $product    = wc_get_product($product_id);
    $desired_qty = $cart_item['quantity'];
    $total_consider = array();
    $avail_qty_stock = $product->get_stock_quantity();



    $qorder_eship_date = qot_ric_date_cacl($product_id, $avail_qty_stock, $desired_qty);
    echo " " . $qorder_eship_date;
}

//add_action( 'woocommerce_after_cart_item_name', 'prefix_after_cart_item_name', 10, 2 );


add_action('wp_ajax_qot_ric_add_tocart', 'qot_ric_add_tocart');
add_action('wp_ajax_nopriv_qot_ric_add_tocart', 'qot_ric_add_tocart');

function qot_ric_add_tocart()
{
    if (!isset($_SESSION['steps'])) {
        $_SESSION['steps'] = 1;
    }

    $response = array();

    if (isset($_SESSION['qot_index'])) {
        unset($_SESSION['qot_index']);
    }

    if (isset($_SESSION['quickorder']) && !empty($_SESSION['quickorder'])) {
        $quickorders = $_SESSION['quickorder'];
        $_SESSION['cart-type'] = 'quickorder';

        $merged_items = [];

        foreach ($quickorders as $row_id => $indexed_fields) {
            // Get the base product ID (e.g., 27563 from 27563_0)
            $product_id = (strpos($row_id, '_') !== false) ? explode("_", $row_id)[0] : $row_id;

            // Extract the quantity ONCE from this row
            $row_qty = 0;
            foreach ($indexed_fields as $field_data) {
                if (isset($field_data['qorder_qty_order'])) {
                    $row_qty = (int) $field_data['qorder_qty_order'];
                    break; // Stop looking once we find the qty field for this row
                }
            }

            if (!isset($merged_items[$product_id])) {
                $merged_items[$product_id] = 0;
            }
            $merged_items[$product_id] += $row_qty;
        }

        // echo 'total_qty'.$total_qty;
        // // Add to cart using the consolidated totals
        // foreach ($merged_items as $pid => $total_qty) {
        //     if ($total_qty > 0) {
        //         WC()->cart->add_to_cart($pid, $total_qty, 0, array(), array('custom_product_id' => $pid));
        //     }
        // }

        // unset($_SESSION['cart_shipment_choice']);

        $response['message'] = 'success';
        $response['url'] = wc_get_checkout_url();
        $_SESSION['steps'] = 4;

        wp_send_json($response);
        exit();
    }
}


/**
 * Woocommerce Filter hook to add custom data with shipping date, latest date of shipping, sorting
 *
 *
 * @package Quick Order Table
 * @since 1.0.0
 */
add_filter('woocommerce_add_cart_item_data', 'ric_wp_add_cart_item_data', 90, 2);

function ric_wp_add_cart_item_data($cart_item_meta, $product_id)
{


    // echo $product_id.'product_id';

    $get_product_type = get_post_meta($product_id, '_virtual', true);

    if ($get_product_type == 'yes') {
        return $cart_item_meta;
    }
    $custom_data  = array();
    $productid = array();

    //  ric_update_steps('1');

    $custom_product_id = '';
    if (!empty($_SESSION['quickorder']) && isset($_REQUEST['action']) && $_REQUEST['action'] == 'qot_ric_add_tocart') {
        if (isset($_REQUEST['shipment_choice'])) {
            $shipment_choice = $_REQUEST['shipment_choice'];
        } else {
            $shipment_choice = 'single-shipment';
        }

        $quickorders =  $_SESSION['quickorder'];


        // $i=0;

        // if (isset($_SESSION['qot_index'])) {
        //     $_SESSION['qot_index'] = $_SESSION['qot_index'] + 1;
        // } else {
        //     $_SESSION['qot_index'] = 0;
        // }
        // $j = 0;


        foreach ($quickorders as $key => $order) {
            $order = array_flatten($order);
            //  $custom_product_id = $key;


            // $clean_key = '';
            // if (strpos($key, '_') !== false) {
            //     $clean_key = explode('_', $key)[0];
            // }
            // if ($_SESSION['qot_index'] == $j) {
            // if ($order['qorder_eship_date']) {
            //     $ric_eship_date = $order['qorder_eship_date'];
            // }

            // if ($order['qorder_rship_date']) {
            //     $ric_eship_date = $order['qorder_rship_date'];
            // }
            // }

            if ($order['qorder_eship_date']) {
                $custom_data[$key]['ric_wp_eship_date'] = $order['qorder_eship_date'];
            }
            if ($order['qorder_rship_date']) {
                $custom_data[$key]['ric_wp_rship_date'] = $order['qorder_rship_date'];
                // if($clean_key !== ''){
                //     $custom_data[$clean_key]['ric_wp_rship_date'] = $order['qorder_rship_date'];
                // }
            }
            // break;
            // $j++;
        }


        //         echo '<pre>cart_item_meta';
        // print_r($cart_item_meta);
        // echo '</pre>cart_item_meta';
        // foreach ($_SESSION['quickorder'] as $key => $order) {

        //     $order = array_flatten($order);

        //     echo '<pre>';
        //     print_r($order);
        //     echo '</pre>';
        //     // if($order)
        //     // echo $order['qorder_did'].'prooisd';
        //     // Match the current product being added
        //     // if ((int) $order['product_id'] === (int) $product_id) {

        //     //     // THIS is all you need
        //     //     $cart_item_meta['custom_product_id'] = $key;

        //     //     // Optional: shipment dates
        //     //     if (!empty($order['qorder_eship_date'])) {
        //     //         $cart_item_meta['ric_eship_date'] = $order['qorder_eship_date'];
        //     //     }

        //     //     if ($order['qorder_rship_date']) {
        //     //         $cart_item_meta['ric_eship_date'] = $order['qorder_rship_date'];
        //     //     }

        //     //     break; // VERY IMPORTANT
        //     // }
        // }



        // $i++;
        //}
        // echo '<pre>custom_data';
        // print_r($custom_data);
        // echo '</pre>custom_data';
        if ($shipment_choice == 'single-shipment') {
            $custom_data_filter  =  one_shipment_of_all_items($custom_data);
        } elseif ($shipment_choice == 'two-shipment') {
            $custom_data_filter = $custom_data;
            // $custom_data_filter  =  two_shipment_of_all_items($custom_data);
        } elseif ($shipment_choice == 'multiple-shipment') {
            $custom_data_filter = $custom_data;
        } elseif ($shipment_choice == 'custom-shipment') {
            $custom_data_filter  =  $custom_data;
        } else {
            $custom_data_filter  = filter_same_product_with_latest_date($custom_data);
        }


        // echo '<pre>custom_data_filter_out';
        // print_r($custom_data_filter);
        // echo '</pre>custom_data_filter_out';


        $custom_data         = ric_wp_order_meta_sorting($custom_data_filter);
        // echo '<pre>custom_data_out';
        // print_r($custom_data);
        // echo '</pre>custom_data_out';
        $cart_item_meta['ric_wp_order_meta']  = $custom_data;
        $cart_item_meta['ric_shipment_choice'] = $shipment_choice;

        if ($shipment_choice == 'single-shipment') {
            $single_delivery_date = '';

            foreach ($custom_data as $ship_meta) {
                if (!empty($ship_meta['ric_wp_eship_date'])) {
                    $single_delivery_date = $ship_meta['ric_wp_eship_date'];
                    break;
                }
            }

            if (!empty($single_delivery_date)) {
                $cart_item_meta['delivery_date'] = $single_delivery_date;
                $cart_item_meta['ric_eship_date'] = $single_delivery_date;
            }
        }
        // $cart_item_meta['ric_eship_date']     = $ric_eship_date;
        // $cart_item_meta['custom_product_id']  = $custom_product_id;
        $_SESSION['cart-type']                = 'quickorder';
    }



    // echo '<pre>cart_item_meta';
    // print_r($cart_item_meta);
    // echo '</pre>cart_item_meta';
    return $cart_item_meta;
}


// Sorting date from custom order meta
function ric_wp_order_meta_sorting($ric_wp_order_meta)
{
    $_SESSION['steps'] = 3;

    $ric_wp_order_sort = array();

    foreach ($ric_wp_order_meta as $key => $value) {
        $value['product_id'] = $key;
        $ric_wp_order_sort[$key] = $value;
    }


    usort($ric_wp_order_sort, function ($a1, $a2) {
        if (array_key_exists('ric_wp_rship_date', $a1)) {
            $v1 = strtotime($a1['ric_wp_rship_date']);
        } else {
            $v1 = strtotime($a1['ric_wp_eship_date']);
        }

        if (array_key_exists('ric_wp_rship_date', $a2)) {
            $v2 = strtotime($a2['ric_wp_rship_date']);
        } else {
            $v2 = strtotime($a2['ric_wp_eship_date']);
        }

        return $v1 - $v2;
    });


    $ric_wp_meta_sort = array();
    foreach ($ric_wp_order_sort as $arr) {
        $product_id = $arr['product_id'];
        unset($arr['product_id']);
        $ric_wp_meta_sort[$product_id] = $arr;
    }
    return $ric_wp_meta_sort;
}

/**
 * Function return array from array into array
 *
 *
 * @package Quick Order Table
 * @since 1.0.0
 */
function array_flatten($array)
{
    if (!is_array($array)) {
        return false;
    }
    $result = array();
    foreach ($array as $key => $value) {
        if (is_array($value)) {
            $result = array_merge($result, array_flatten($value));
        } else {
            $result[$key] = $value;
        }
    }
    return $result;
}


function qot_ric_get_meta_data()
{
    $data = $_SESSION['quickorder'];
    $meta_data = array();
    $custom_data = array();



    if (is_array($data) && count($data) > 0) {
        foreach ($data as $key => $quickorder) {
            $meta_data[] = array_flatten($quickorder);
        }
    }

    foreach ($meta_data as $meta_data) {
        if ($meta_data['qorder_eship_date']) {
            $custom_data[$meta_data['qorder_did']]['ric_wp_eship_date'] = $meta_data['qorder_eship_date'];
        }
        if ($meta_data['qorder_rship_date']) {
            $custom_data[$meta_data['qorder_did']]['ric_wp_rship_date'] = $meta_data['qorder_rship_date'];
        }
    }


    return $custom_data;
}

/**
 * Woocommerce action hook to add order item meta like requested date, shipping date, delivery date
 *
 *
 * @package Quick Order Table
 * @since 1.0.0
 */
add_action('woocommerce_add_order_item_meta', 'qot_ric_order_item_meta', 90, 2);

function qot_ric_order_item_meta($item_id, $values)
{

    error_log('ORDER ITEM VALUES: ' . print_r($values, true));
    if (isset($values['custom_product_id'])) {
        // The corresponding Product Id for the item:
        $product_id = $values['custom_product_id'];
        $get_product_type = get_post_meta($product_id, '_virtual', true);


        if ($get_product_type == 'yes') {

            wc_add_order_item_meta($item_id, 'virtual_item', 'virtual');
            $order_id = wc_get_order_id_by_order_item_id($item_id);
            wc_add_order_item_meta($order_id, 'virtual_order', 'virtual');
        }
        if (isset($values['ric_wp_order_meta'])) {
            $custom_data = $values['ric_wp_order_meta'];

            $eship_date = $rship_date = '';

            if (isset($custom_data[$product_id]['ric_wp_eship_date'])) {
                $eship_date = $custom_data[$product_id]['ric_wp_eship_date'];
                wc_add_order_item_meta($item_id, esc_html__('Earliest Possible Ship Date', 'quickorder'), $eship_date);
            }

            if (isset($custom_data[$product_id]['ric_wp_rship_date'])) {
                $rship_date = $custom_data[$product_id]['ric_wp_rship_date'];
                wc_add_order_item_meta($item_id, esc_html__('Requested Ship Date', 'quickorder'), $rship_date);
            }

            $delivery_date = '';

            if (empty($rship_date)) {
                $delivery_date = $eship_date;
            } else {
                $delivery_date = $rship_date;
            }

            if (isset($custom_data[$product_id]['ric_wp_eship_date']) && $_SESSION['cart-type'] == 'wc-cart') {
                $delivery_date = $custom_data[$product_id]['ric_wp_eship_date'];
                wc_add_order_item_meta($item_id, esc_html__('Earliest Possible Ship Date', 'quickorder'), $delivery_date);
            }

            if (function_exists('rmg_get_selected_shipment_date')) {
                $shipment_type = (!empty($values['split_type']) && $values['split_type'] === 'backorder') ? 'backorder' : '';
                $delivery_date = rmg_get_selected_shipment_date($delivery_date, $shipment_type);
            }

            wc_add_order_item_meta($item_id, '_qot_delivery_date', $delivery_date);

            $order_id = wc_get_order_id_by_order_item_id($item_id);

            update_post_meta($order_id, 'requested_ship_date', $eship_date);
        }
    } elseif (isset($values['custom_cart_pro_id'])) {
        // The corresponding Product Id for the item:
        $product_id = $values['custom_cart_pro_id'];

        if (isset($values['ric_cart_order_meta'])) {
            $custom_data = $values['ric_cart_order_meta'];

            $eship_date = '';

            if (isset($custom_data[$product_id]['ric_wp_eship_date'])) {
                $eship_date = $custom_data[$product_id]['ric_wp_eship_date'];
                wc_add_order_item_meta($item_id, esc_html__('Earliest Possible Ship Date', 'quickorder'), $eship_date);
            }

            if (function_exists('rmg_get_selected_shipment_date')) {
                $eship_date = rmg_get_selected_shipment_date($eship_date);
            }

            wc_add_order_item_meta($item_id, '_qot_delivery_date', $eship_date);

            $order_id = wc_get_order_id_by_order_item_id($item_id);

            update_post_meta($order_id, 'requested_ship_date', $eship_date);
        }
    }
    // echo '<pre>';
    // print_r($values);
    // echo '</pre>';
}

// add_action( 'woocommerce_after_order_itemmeta', 'display_admin_order_item_custom_button', 10, 3 );
function display_admin_order_item_custom_button($item_id, $item, $product)
{
    // Only "line" items and backend order pages
    if (! (is_admin() && $item->is_type('line_item'))) {
        return;
    }

    // $product_id = $item->get_product_id();

    $get_rship_date = wc_get_order_item_meta($item_id, '_qorder_rship_date', true);
    $get_eship_date = wc_get_order_item_meta($item_id, '_qorder_eship_date', true);

    $ship_date = (!empty($get_rship_date)) ? '<tr><th>' . esc_html('Requested Ship Date:') . '</th><td><p>' . $get_rship_date . '</p></td>
    </tr>' : '';

    $req_date = (!empty($get_eship_date)) ? '<tr><th>' . esc_html('Earliest Possible Ship Date:') . '</th><td><p>' . $get_eship_date . '</p></td>
    </tr>' : '';


    echo '<div class="view">
    <table class="display_meta qot_ric_order_meta" cellspacing="0">
        <tbody>' . $ship_date . $req_date . '</tbody>
        </table>
    </div>';
}


function custom_shipment_of_all_items($custom_data)
{
    $eShip = array();
    $rShip = array();


    $custom_data_3 = array();
    $ric_wp_rship_date = array();
    $custom_data_new = $custom_data;
    return  $custom_data_new;
}

/**
 * Function convert into Two shipments - as one in-stock & backorder
 *
 *
 * @package Quick Order Table
 * @since 1.0.0
 */
function two_shipment_of_all_items($custom_data)
{
    $_SESSION['steps'] = 2;

    $in_stock_dates = array();
    $out_stock_dates = array();

    $custom_data_2 = array();

    foreach ($custom_data as $key => $data) {
        $product_id = qot_get_product_id($key);
        $product = wc_get_product($product_id);
        $qorder_qty_stock = $product->get_stock_quantity();

        $consider_qty = qot_ric_get_exist_consider_qty($key);

        if ($consider_qty > $qorder_qty_stock) {
            if (array_key_exists('ric_wp_eship_date', $data)) {
                $out_stock_dates[] = $data['ric_wp_eship_date'];
            }

            // if( array_key_exists('ric_wp_rship_date', $data) ){
            //  $out_stock_dates[] = $data['ric_wp_rship_date'];
            // }
        } else {
            if (array_key_exists('ric_wp_eship_date', $data)) {
                // $data['ric_wp_eship_date'];
                $in_stock_dates[] = $data['ric_wp_eship_date'];
            }

            // if( array_key_exists('ric_wp_rship_date', $data) ){
            //  $in_stock_dates[] = $data['ric_wp_rship_date'];
            // }
        }
    }

    $in_stock = '';
    if (is_array($in_stock_dates) && !empty($in_stock_dates)) {
        $in_stock  = max($in_stock_dates);
    }


    $out_stock = '';
    if (is_array($out_stock_dates) && !empty($out_stock_dates)) {
        $out_stock = max($out_stock_dates);
    }


    $temp_data = array();
    foreach ($custom_data as $key => $data_new) {
        $product_id = qot_get_product_id($key);
        $product = wc_get_product($product_id);
        $qorder_qty_stock = $product->get_stock_quantity();

        $consider_qty = qot_ric_get_exist_consider_qty($key);

        if ($consider_qty >  $qorder_qty_stock) {
            if (array_key_exists('ric_wp_eship_date', $data_new)) {
                $temp_data['ric_wp_eship_date'] = $out_stock;
                $custom_data_2[$key] = $temp_data;
            } else {
                $temp_data['ric_wp_eship_date'] = $out_stock;
                $custom_data_2[$key] = $temp_data;
            }
        } else {
            if (array_key_exists('ric_wp_eship_date', $data_new)) {
                $temp_data['ric_wp_eship_date'] = $in_stock;
                $custom_data_2[$key] = $temp_data;
            } else {
                $temp_data['ric_wp_eship_date'] = $in_stock;
                $custom_data_2[$key] = $temp_data;
            }
        }
    }

    return $custom_data_2;
}

/**
 * Function convert into One shipment when all items are ready
 *
 *
 * @package Quick Order Table
 * @since 1.0.0
 */
function one_shipment_of_all_items($custom_data)
{
    $_SESSION['steps'] = 2;

    $all_dates = array();

    $custom_data_1 = array();

    foreach ($custom_data as $key => $data) {
        if (array_key_exists('ric_wp_eship_date', $data)) {
            $all_dates[] = $data['ric_wp_eship_date'];
        }

        if (array_key_exists('ric_wp_rship_date', $data)) {
            $all_dates[] = $data['ric_wp_rship_date'];
        }
    }

    if (!empty($all_dates)) {
        $max_date = max($all_dates);
    } else {
        $max_date = '';
    }

    foreach ($custom_data as $key => $data_new) {
        $custom_data_1[$key] = array(
            'ric_wp_eship_date' => $max_date,
        );
    }

    return $custom_data_1;
}

/**
 * Function return items array with latest date
 *
 *
 * @package Quick Order Table
 * @since 1.0.0
 */
function filter_same_product_with_latest_date($custom_data)
{
    $_SESSION['steps'] = 2;

    $items_count = sizeof(WC()->cart->get_cart()) + 1;
    $quickorder_cart = count($custom_data);
    $filter = array();
    $product_with_date = array();


    $ship_dates = array();
    $pro_ids = array();
    $pro_ids_date = array();


    //  if($items_count == $quickorder_cart){
    $ric_wp_rship_date = array();
    $custom_data_new = $custom_data;

    foreach ($custom_data as $key => $value) {
        if (array_key_exists('ric_wp_rship_date', $value)) {
            $ric_wp_rship_date[$key] = $custom_data[$key]['ric_wp_rship_date'];
        } else {
            $ric_wp_rship_date[$key] = $custom_data[$key]['ric_wp_eship_date'];
        }
    }



    $null_ric_wp_rship_date = array();

    foreach ($custom_data as $key_id => $custom_val) {
        // Store in blank array which having requested date
        foreach ($ric_wp_rship_date as $ric_key => $ric_val) {
            if ($key_id == $ric_key) {
                if (array_key_exists('ric_wp_rship_date', $custom_val)) {
                    unset($ric_wp_rship_date[$key_id]);
                    $null_ric_wp_rship_date[$key_id] = $ric_val;
                }
            }
        }
    }


    foreach ($ric_wp_rship_date as $key => $date) {
        for ($i = 0; $i < 10; $i++) {
            if (array_key_exists($key . '_' . $i, $ric_wp_rship_date)) {
                if ($ric_wp_rship_date[$key] < $ric_wp_rship_date[$key . '_' . $i]) {
                    $ric_wp_rship_date[$key] = $ric_wp_rship_date[$key . '_' . $i];
                }
                // $ric_wp_rship_date[$key.'_'.$i] = $ric_wp_rship_date[$key];
            }
        }
        for ($i = 0; $i < 10; $i++) {
            if (array_key_exists($key . '_' . $i, $ric_wp_rship_date)) {
                $ric_wp_rship_date[$key . '_' . $i] = $ric_wp_rship_date[$key];
                // $ric_wp_rship_date[$key.'_'.$i] = $ric_wp_rship_date[$key];
            }
        }
    }

    foreach ($ric_wp_rship_date as $key => $date) {
        $match = false;
        // remove which are not duplicate
        for ($i = 0; $i < 10; $i++) {
            if (array_key_exists($key . '_' . $i, $ric_wp_rship_date)) {
                $match = true;
            }
        }
        if ($match == false && strpos($key, '_') === false) {
            unset($ric_wp_rship_date[$key]);
        }
    }



    if (!empty($ric_wp_rship_date)) {
        foreach ($custom_data_new as $key => $value) {
            foreach ($null_ric_wp_rship_date as $key_rq => $ric_rship_date) {
                if ($key == $key_rq) {
                    //  unset($custom_data_new[$key_rq]);
                    $custom_data_new[$key_rq]['ric_wp_rship_date'] = $ric_rship_date;
                }
            }

            foreach ($ric_wp_rship_date as $key1 => $exp_last_date) {
                if ($key == $key1) {
                    //unset($custom_data_new[$key1]);

                    $custom_data_new[$key1]['ric_wp_eship_date'] = $exp_last_date;
                }
            }
        }


        return $custom_data_new;
    } else {
        return $custom_data;
    }



    //  }
}

/**
 * Get product quantity based on product id
 *
 *
 * @package Quick Order Table
 * @since 1.0.0
 */
function qot_ric_get_product_qty($prod_id)
{
    global $field;
    $qty = 1;

    $i = 0;
    foreach ($field as $key) {
        if ($key == 'qorder_qty_order') {
            $qty =  $_SESSION['quickorder'][$prod_id][$i]['qorder_qty_order'];
        }

        $i++;
    }


    return $qty;
}


/**
 * Get consider final quantity of product id
 *
 *
 * @package Quick Order Table
 * @since 1.0.0
 */
function qot_ric_get_exist_consider_qty($prod_id)
{
    global $field;



    $quickorders = $_SESSION['quickorder'];

    $i = 0;
    foreach ($field as $key) {
        if ($key == 'qorder_qty_consider') {
            $qty = $quickorders[$prod_id][$i]['qorder_qty_consider'];
        }

        $i++;
    }

    return $qty;
}

/**
 * return duplicate product
 *
 *
 * @package Quick Order Table
 * @since 1.0.0
 */
function qot_ric_get_same_product($prod_id)
{
    //Call this function without underscore id (e.g. 7070)
    global $field;

    $get_all_products = array();
    $get_duplicate_pro = array();
    $quickorders = $_SESSION['quickorder'];

    foreach ($quickorders as $id => $quickorder) {
        // if(strpos($prod_id, $id) !== false) {
        $get_all_products[] = $id;
        // }
    }

    foreach ($get_all_products as $ids) {
        if (strpos($ids, '_') !== false && $prod_id == $ids) {
            $get_duplicate_pro[] = $ids;
        }
    }



    if (!empty($get_duplicate_pro) && count($get_duplicate_pro) > 0) {
        $temp = array($prod_id);
        $get_duplicate_pro = array_merge($temp, $get_duplicate_pro);


        return $get_duplicate_pro;
    }
}
