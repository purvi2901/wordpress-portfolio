<?php

/**
 * Get availability data for a product.
 *
 * @param int $product_id The ID of the product.
 * @return array|null Availability data or null if the product ID is invalid.
 */
function get_availability_data($product_id)
{
    // Validate product ID
    if (empty($product_id) || ! is_numeric($product_id)) {
        return null;
    }

    $availability_table = function_exists('rtcwp_get_adjusted_capacity')
        ? rtcwp_get_adjusted_capacity($product_id)
        : get_post_meta($product_id, 'availability_table', true);

    if (empty($availability_table) || empty($availability_table['get_capacity'])) {
        $current_date        = date('Y-m-d', strtotime('+2 days'));
        $ric_wp_wip_qty      = get_post_meta($product_id, '_ric_wp_wip_qty', true);
        $ric_wp_wip_date     = get_post_meta($product_id, '_ric_wp_wip_date', true);
        $wip_lead_time       = get_post_meta($product_id, '_ric_wp_wip_lead_time', true);
        $ship_date           = date('Y-m-d', strtotime('+' . $wip_lead_time . ' days'));

        $product = wc_get_product($product_id);
        if (! $product) {
            return null;
        }

        $qty_in_stock = $product->get_stock_quantity() ?: 0;

        $availability_table = [
            [
                'type'           => 'in_stock',
                'qty'            => $qty_in_stock,
                'date_available' => $current_date
            ],
            [
                'type'           => 'work_order',
                'qty'            => $ric_wp_wip_qty ?: 0,
                'date_available' => $ric_wp_wip_date ? $ric_wp_wip_date : $ship_date,
            ],
            [
                'type'           => 'lead_time',
                'date_available' => $ship_date,
            ],
        ];
    } else {
        $availability_table = $availability_table['get_capacity'];
    }

    return $availability_table;
}

/**
 * Get the delivery date based on the product ID and order quantity.
 *
 * @param int $product_id The ID of the product.
 * @param int $order_qty The quantity of the order.
 * @return string|null The delivery date if found, or null if not available.
 */
function get_delivery_shipping_date($product_id, $order_qty)
{
   
    if (empty($product_id) || empty($order_qty) || ! is_numeric($order_qty)) {
        return null;
    }

    $product = wc_get_product($product_id);
    if (! $product) {
        return null;
    }

   
    $get_capacity = get_availability_data($product_id);

    $total_qty    = 0;

    if (!empty($get_capacity)) {
        foreach ($get_capacity as $data) {
            if (isset($data['type'], $data['date_available'])) {
                if ($data['type'] === 'lead_time') {
                    $lead_time_date = $data['date_available'];
                }

                if (isset($data['qty'])) {
                    $total_qty += intval($data['qty']);

                    if ($total_qty >= $order_qty) {
                        return $data['date_available'];
                    }
                }
            }
        }
    }


    return $lead_time_date;
}
