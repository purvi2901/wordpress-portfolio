<?php

// Exit if accessed directly
if (! defined('ABSPATH')) {
    exit;
}

class Qot_Ric_Public
{
    function __construct()
    {
    }

    /**
     * Search products by sku and title using ajax
     */
    public function ric_wp_qorder_custom_search_products()
    {
                      
        global $qot_ric_model;

        $results = array();

        if (is_user_logged_in()) {
            $exclude_ids = get_user_meta(get_current_user_id(), 'cvf_hidden_products', true);
        } else {
            $exclude_ids = get_option('cvf_hidden_products_non_logged_in');
        }

        $excludeids = $qot_ric_model->get_hidden_product_id();
        $exclude_ids = array_merge($exclude_ids, $excludeids);
        
        $args = array(
            'post_type' => 'product',
            'post_status' => 'publish',
            'posts_per_page' => -1,
            'post__not_in' => [18178]
        );

        if (!empty($_POST['search_text'])) {
            $args['_meta_or_title'] = $_POST['search_text'];

            $args['meta_query'] = array(
                array(
                    'key' => '_sku',
                    'value' => $_POST['search_text'],
                    'compare' => 'LIKE'
                )
            );
        }

        $posts = get_posts($args);
              
        if (count($posts) > 0) {
            foreach ($posts as $key => $value) {
                $sku = get_post_meta($value->ID, '_sku', true);

                $product_title = $value->post_title;

                if (!empty($sku)) {
                    $product_title = '['.$sku.'] '.$value->post_title;
                }
                $results['results'][$key]['id'] = $value->ID;
                $results['results'][$key]['text'] = $product_title;
            }
        } else {
            $results['results'][0]['id'] ='';
            $results['results'][0]['text'] = 'Not found';
        }
        echo json_encode($results);
        exit();
    }

    /**
     * Search meta or title by pre get post query
     */
    public function ric_wp_pre_get_posts($q)
    {
        if ($title = $q->get('_meta_or_title')) {
            add_filter('get_meta_sql', function ($sql) use ($title) {
                global $wpdb;

                // Only run once:
                static $nr = 0;
                if (0 != $nr++) {
                    return $sql;
                }

                $sql['where'] = sprintf(
                    " AND ( %s OR %s ) ",
                    "{$wpdb->posts}.post_title LIKE '%$title%'",
                    mb_substr($sql['where'], 5, mb_strlen($sql['where']))
                );
                return $sql;
            });
        }
    }

   
    /**
     * Get Item Qty
     */
    public function get_item_qty($product)
    {
        foreach (WC()->cart->get_cart() as $cart_item) {
            $product_id = $product->get_parent_id();
        }
        if ($product_id == 0 || empty($product_id)) {
            $product_id = $product->get_id();
        }

        if ($product_id == $cart_item['product_id']) {
            return $cart_item['quantity'];
            // break;
        }
            
        return;
    }

     /**
     * Woocommerce Hook - Cart item Remove
     */
    public function ric_wp_cart_item_removed($removed_cart_item_key, $cart)
    {

        $line_item = $cart->removed_cart_contents[ $removed_cart_item_key ];
        $product_id = isset($line_item['custom_product_id']) ? $line_item['custom_product_id'] : $line_item[ 'product_id' ];

        unset($_SESSION['quickorder'][$product_id]);

        if (empty($cart->cart_contents)) {
            if (function_exists('rushabh_clear_shipment_date_session')) {
                rushabh_clear_shipment_date_session();
            } else {
                unset(
                    $_SESSION['shipment_choice'],
                    $_SESSION['cart_shipment_choice'],
                    $_SESSION['rushabh_cart_shipment_choice_manual'],
                    $_SESSION['split_order']
                );
            }
        }
    }

    /**
     * Woocommerce Hook - Thankyou to remove session items
    */
    public function ric_wp_quick_item_removed($order_get_id)
    {
        
        unset($_SESSION['quickorder']);
        unset($_SESSION['qorder_rship_date']);

        unset($_SESSION['shipment_choice']);
        unset($_SESSION['cart_shipment_choice']);
        unset($_SESSION['rushabh_cart_shipment_choice_manual']);

        if (function_exists('WC') && WC()->session) {
            WC()->session->__unset('shipment_choice');
            WC()->session->__unset('cart_shipment_choice');
            WC()->session->__unset('rushabh_cart_shipment_choice_manual');
            WC()->session->__unset('shipment_group_dates');
            WC()->session->__unset('_shipment_group_dates');
        }
      
        if (isset($_SESSION['quickorder_original'])) {
            unset($_SESSION['quickorder_original']);
        }
        if (isset($_SESSION['quickorder_working'])) {
            unset($_SESSION['quickorder_working']);
        }
    }
    
    /**
     * Woocommerce Hook - Switch to user to remove session items
    */
    public function ric_wp_switch_user_clear($user_id, $old_user_id, $new_token, $old_token)
    {
        unset($_SESSION['quickorder']);
        unset($_SESSION['qorder_rship_date']);
    }
    
    /**
     * Woocommerce Hook - Body Class to add class in Quick order page
     */
    function ric_wp_quickorder_body_class($class)
    {

        global $post;

        if (isset($post->post_content) && has_shortcode($post->post_content, 'quick_order')) {
            $class[] = 'quickorder-page';
        }
        return $class;
    }

    /**
     * Woocommerce Hook - Astra Head Bottom Class to add script
     */
    function ric_load_early_table()
    {
        ?>
        <script type="text/javascript">
            jQuery('.hfe-before-footer-wrap').hide();
            setTimeout(function(){
                jQuery('#quick_order_table_rushabh').fadeIn(1500);
                jQuery('body.quickorder-page .hfe-before-footer-wrap, .site-footer').fadeIn(1500);
            },600);
            
        </script>
        <?php
    }

    public function ric_wp_qorder_shipment()
    {
        global $field;

        unset($_SESSION['steps']);

        $response    = [];
        $custom_data = [];
        $parentData  = $_POST['parentData'] ?? [];
        $selectedShipment = $_POST['selectedShipment'] ?? '';

        if (empty($selectedShipment)) {
            wp_send_json($response);
        }

        /*
        |--------------------------------------------------------------------------
        | Initialize ORIGINAL snapshot ONCE
        |--------------------------------------------------------------------------
        */
        if (!isset($_SESSION['quickorder_original'])) {
            $_SESSION['quickorder_original'] = $_SESSION['quickorder'] ?? [];
        }else{
            $_SESSION['quickorder_original'] = $_SESSION['quickorder_original'];
        }

       
        /*
        |--------------------------------------------------------------------------
        | Always start from ORIGINAL snapshot
        |--------------------------------------------------------------------------
        */
        $_SESSION['quickorder'] = $_SESSION['quickorder_original'];
        $_SESSION['shipment_choice']    = $selectedShipment;
        $_SESSION['cart_shipment_choice'] = $selectedShipment;
        $_SESSION['rushabh_cart_shipment_choice_manual'] = true;

        if ($selectedShipment == 'custom-shipment') {
            $_SESSION['shipment_choice'] = $selectedShipment;
            $_SESSION['cart_shipment_choice'] = $selectedShipment;
            $selectedShipment = $_SESSION['shipment_choice'];
        } else {
                $_SESSION['shipment_choice'] = $selectedShipment;
                $_SESSION['cart_shipment_choice'] = $selectedShipment;
                $selectedShipment = $_SESSION['shipment_choice'];
        }

        if (function_exists('WC') && WC()->session) {
            WC()->session->set('shipment_choice', $selectedShipment);
            WC()->session->set('cart_shipment_choice', $selectedShipment);
            WC()->session->set('rushabh_cart_shipment_choice_manual', true);
        }


        $quickorders = $_SESSION['quickorder'];

        if (empty($quickorders)) {
            wp_send_json($response);
        }

        /*
        |--------------------------------------------------------------------------
        | Collect shipping dates (for pricing later)
        |--------------------------------------------------------------------------
        */
        foreach ($quickorders as $key => $order) {
            $flat = array_flatten($order);

            if (!empty($flat['qorder_eship_date'])) {
                $custom_data[$key]['ric_wp_eship_date'] = $flat['qorder_eship_date'];
            }
            if (!empty($flat['qorder_rship_date'])) {
                $custom_data[$key]['ric_wp_rship_date'] = $flat['qorder_rship_date'];
            }
        }

        /*
        |--------------------------------------------------------------------------
        | SINGLE SHIPMENT
        |--------------------------------------------------------------------------
        */
        if ($selectedShipment === 'single-shipment') {
            $_SESSION['shipment_choice'] = 'single-shipment';
             $_SESSION['cart_shipment_choice'] = 'single-shipment';
            // 1. We must rebuild from the clean Original Snapshot
            $source = !empty($_SESSION['quickorder_original']) ? $_SESSION['quickorder_original'] : $_SESSION['quickorder'];
            
            $merged = [];
            $all_dates = [];
            global $field; // Ensure we have access to the field index map
        
            foreach ($source as $key => $indexed_rows) {
                $product_id = qot_get_product_id($key);
        
                // Flatten the indexed structure into a temporary associative array for easy math
                $flat_row = [];
                foreach ($indexed_rows as $idx => $field_data) {
                    $fname = key($field_data); // Get 'qorder_qty_order', etc.
                    $flat_row[$fname] = $field_data[$fname];
                }
        
                // Collect dates
                if (!empty($flat_row['qorder_eship_date'])) $all_dates[] = $flat_row['qorder_eship_date'];
                // if (!empty($flat_row['qorder_rship_date'])) $all_dates[] = $flat_row['qorder_rship_date'];
                // if (!empty($flat_row['qorder_rship_date'])) $all_dates[] = '';
        
                if (!isset($merged[$product_id])) {
                    $flat_row['qorder_did'] = $product_id;
                    $merged[$product_id] = $flat_row;
                } else {
                    // Sum quantities and prices
                    $merged[$product_id]['qorder_qty_order'] += (int)$flat_row['qorder_qty_order'];
                }
            }
        
            $max_date = !empty($all_dates) ? max($all_dates) : '';
            $final_session = [];
        
            // 2. Re-wrap the data into the [$index][$fname] structure
            foreach ($merged as $pid => $data) {
                $unit_price = (float)$data['qorder_unit_price'];
                $total_qty  = (int)$data['qorder_qty_order'];
        
                // Update logic values
                $data['qorder_total_price']    = $total_qty * $unit_price;
                $data['qorder_qty_order_html'] = qot_ric_qty_order_field($pid, $total_qty);
                $data['qorder_eship_date']      = $max_date;
                // $data['qorder_rship_date']      = $max_date;
                $data['qorder_rship_date']      = '';
                $data['qorder_rship_date']      = '';   
                $data['qorder_rship_date_html']      = '';
                $data['action']                 = qot_ric_delete_order($pid, false, false, 'single-shipment');
        
                // Build the indexed array exactly like split_quick_order_table does
                foreach ($field as $index => $fname) {
                    $final_session[$pid][$index][$fname] = $data[$fname] ?? '';
                }
                
                // Sync footer display
                // qot_update_rship_date_html($pid, $unit_price, $max_date);
            }
        
            $_SESSION['quickorder'] = $final_session;
        }

        /*
        |--------------------------------------------------------------------------
        | TWO SHIPMENT
        |--------------------------------------------------------------------------
        */
        elseif ($selectedShipment === 'two-shipment') {

                

            $original_orders = $_SESSION['quickorder_original'];
            
            $_SESSION['shipment_choice'] = 'two-shipment';
            $_SESSION['cart_shipment_choice'] = 'two-shipment';
            $_SESSION['quickorder'] = $this->ric_wp_build_two_shipment_quickorder($_SESSION['quickorder_original']);
            // $out_stock_dates = $in_stock_dates = array();
            // $split_qty=[];
            // $ss= 1;

            // foreach ($original_orders as $key => $data) {

            //     $product_id = qot_get_product_id($key);
            //     $product    = wc_get_product($product_id);
            //     if (!$product) continue;
        
            //     $order_qty = (int) qot_ric_get_product_qty($key);
        
            //     // ---- Availability ----
            //     $availability_table = get_post_meta($product_id, 'availability_table', true);
        
            //     $quantities = [];
            //     $qorder_qty_stock = 0;
        
            //     if (!empty($availability_table['get_capacity'])) {
            //         foreach ($availability_table['get_capacity'] as $item) {
            //             if (
            //                 isset($item['qty']) &&
            //                 is_numeric($item['qty']) &&
            //                 $item['qty'] > 0
            //             ) {
            //                 $quantities[] = [
            //                     'qty'  => (int) $item['qty'],
            //                     'date' => $item['date_available']
            //                 ];
        
            //                 if ($item['type'] === 'in_stock') {
            //                     $qorder_qty_stock += (int) $item['qty'];
            //                 }
            //             }
            //         }
            //     } else {
            //         $stock = max(0, (int) $product->get_stock_quantity());
        
            //         if ($stock > 0) {
            //             $quantities[] = [
            //                 'qty'  => $stock,
            //                 'date' => date('Y-m-d', strtotime('+2 days'))
            //             ];
            //         }
                    
            //         $qorder_qty_stock = $stock;
            //     }
        
            //     // ---- No split needed ----
            //     if ($order_qty <= $qorder_qty_stock) {
            //         $new_orders[$key] = $data;
            //         continue;
            //     }
            
        
            //     // ---- Split logic ----
            //     // $split_qty = [];
        
            //     // if ($qorder_qty_stock > 0) {
            //     //     $split_qty[] = [
            //     //         'qty'  => $qorder_qty_stock,
            //     //         'date' => getDateBasedOnDemand($quantities, $qorder_qty_stock)
            //     //     ];
            //     // }
        
            //     // $backorder_qty = $order_qty - $qorder_qty_stock;
        
            //     // if ($backorder_qty > 0) {
            //     //     $split_qty[] = [
            //     //         'qty'  => $backorder_qty,
            //     //         'date' => getDateBasedOnDemand($quantities, $backorder_qty)
            //     //     ];
            //     // }
        
            //     //   echo '<pre>';
            //     //   print_r($split_qty);
            //     //   echo '</pre>';


            //     //     echo $backorder_qty.'backorder_qty'.'<br>';
            //     //     echo $product_id.'product_id'.'<br>';
                
            //     // $new_orders = split_quick_order_table(
            //     //     $split_qty,
            //     //     $product_id,
            //     //     $qorder_qty_stock,
            //     //     $backorder_qty,
            //     //     'two-shipment'
            //     // );

            //     // echo '<pre>';
            //     // print_r($new_orders);
            //     // echo '</pre>';
            // }
        
            // $_SESSION['quickorder'] = $new_orders;

                // $original_orders = $_SESSION['quickorder_original'];
            
                // $_SESSION['shipment_choice'] = 'two-shipment';
                // $out_stock_dates = $in_stock_dates = array();
                // $split_qty=[];
                // $ss= 1;


                // $uniq_pro_ids=[];

                // foreach ($original_orders as $key => $data) {

                //     $product_id = qot_get_product_id($key);
                //     $product    = wc_get_product($product_id);
                //     if (!$product) continue;
        
                //     $order_qty = (int) qot_ric_get_product_qty($key);
            
                //     if (!isset($uniq_pro_ids[$product_id])) {
                //         $uniq_pro_ids[$product_id] = 0;
                //     }
                
                //     $uniq_pro_ids[$product_id] += $order_qty;
            
                // }
            

                // foreach ($uniq_pro_ids as $product_id => $order_qty) {

                //     $availability_table = get_post_meta($product_id, 'availability_table', true);
            
                //     $quantities = [];
                //     $qorder_qty_stock = 0;
            
                //     if (!empty($availability_table['get_capacity'])) {
                //         foreach ($availability_table['get_capacity'] as $item) {
                //             if (
                //                 isset($item['qty']) &&
                //                 is_numeric($item['qty']) &&
                //                 $item['qty'] > 0
                //             ) {
                //                 $quantities[] = [
                //                     'qty'  => (int) $item['qty'],
                //                     'date' => $item['date_available']
                //                 ];
            
                //                 if ($item['type'] === 'in_stock') {
                //                     $qorder_qty_stock += (int) $item['qty'];
                //                 }
                //             }
                //         }
                //     } else {
                //         $stock = max(0, (int) $product->get_stock_quantity());
            
                //         if ($stock > 0) {
                //             $quantities[] = [
                //                 'qty'  => $stock,
                //                 'date' => date('Y-m-d', strtotime('+2 days'))
                //             ];
                //         }
                        
                //         $qorder_qty_stock = $stock;
                //     }
            
                //     // ---- No split needed ----
                //     if ($order_qty <= $qorder_qty_stock) {
                //         $new_orders[$key] = $data;
                //         continue;
                //     }
                
            
                //     // ---- Split logic ----
                //     $split_qty = [];
            
                //     if ($qorder_qty_stock > 0) {
                //         $split_qty[] = [
                //             'qty'  => $qorder_qty_stock,
                //             'date' => getDateBasedOnDemand($quantities, $qorder_qty_stock)
                //         ];
                //     }
            
                //     $backorder_qty = $order_qty - $qorder_qty_stock;
            
                //     if ($backorder_qty > 0) {
                //         $split_qty[] = [
                //             'qty'  => $backorder_qty,
                //             'date' => getDateBasedOnDemand($quantities, $backorder_qty)
                //         ];
                //     }
            
                    
                //     $new_orders = split_quick_order_table(
                //         $split_qty,
                //         $product_id,
                //         $qorder_qty_stock,
                //         $backorder_qty,
                //         'two-shipment'
                //     );

                //     // echo '<pre>';
                //     // print_r($new_orders);
                //     // echo '</pre>';
                // }
            
                // $_SESSION['quickorder'] = $new_orders;

        }

        /*
        |--------------------------------------------------------------------------
        | MULTIPLE / CUSTOM SHIPMENT
        |--------------------------------------------------------------------------
        */
        elseif ($selectedShipment === 'multiple-shipment') {

            $_SESSION['shipment_choice'] = 'multiple-shipment';
            $_SESSION['cart_shipment_choice'] = 'multiple-shipment';
            $_SESSION['quickorder'] = $this->ric_wp_build_multiple_shipment_quickorder($_SESSION['quickorder_original']);
            // $final_session   = [];
            
            // // 1. First, consolidate all original rows into unique product totals
            // $consolidated_totals = [];
            // foreach ($original_orders as $key => $indexed_data) {
            //     $product_id = qot_get_product_id($key);
                
            //     $row_qty = 0;
            //     foreach ($indexed_data as $field_item) {
            //         if (isset($field_item['qorder_qty_order'])) {
            //             $row_qty = (int)$field_item['qorder_qty_order'];
            //             break;
            //         }
            //     }
                
            //     if (!isset($consolidated_totals[$product_id])) {
            //         $consolidated_totals[$product_id] = 0;
            //     }
            //     $consolidated_totals[$product_id] += $row_qty;
            // }
        
            // // 2. Now loop through consolidated totals and perform the multi-split
            // foreach ($consolidated_totals as $product_id => $total_qty) {
            //     $product = wc_get_product($product_id);
            //     if (!$product) continue;
        
            //     $unit_price = (float) $product->get_price();
            //     $stock_qty  = (int) $product->get_stock_quantity();
            //     $currency   = get_woocommerce_currency_symbol();
        
            //     $availability_table = get_post_meta($product_id, 'availability_table', true);
            //     $split_config = [];
            //     $remaining    = $total_qty;
        
            //     if (!empty($availability_table['get_capacity'])) {
            //         foreach ($availability_table['get_capacity'] as $item) {
            //             if ($remaining <= 0) break;
        
            //             $batch_qty = (int) $item['qty'];
            //             if ($batch_qty <= 0) continue;
        
            //             $take = min($remaining, $batch_qty);
            //             $split_config[] = [
            //                 'qty'  => $take,
            //                 'date' => $item['date_available']
            //             ];
            //             $remaining -= $take;
            //         }
            //     }
        
            //     /* Fallback for remaining quantity */
            //     if ($remaining > 0) {
            //         $split_config[] = [
            //             'qty'  => $remaining,
            //             'date' => qot_ric_date_cacl($product_id, 0, $remaining)
            //         ];
            //     }
        
            //     /* ---------------- Generate Rows (27563_0, 27563_1, etc) ---------------- */
            //     $i = 0;
            //     foreach ($split_config as $batch) {
            //         $row_id = $product_id . '_' . $i;
        
            //         $quickorder = [
            //             'qorder_id'             => $product_id,
            //             'qorder_did'            => $row_id,
            //             'qorder_quickview'      => '<button data-id="'.$row_id.'" class="qorder_quickview"><i class="fa fa-info-circle"></i></button>',
            //             'qorder_name'           => $product->get_name(),
            //             'qorder_sku'            => $product->get_sku(),
            //             'qorder_qty_stock'      => $stock_qty,
            //             'qorder_qty_order'      => $batch['qty'],
            //             'qorder_qty_consider'   => $batch['qty'],
            //             'qorder_qty_order_html' => qot_ric_qty_order_field($row_id, $batch['qty']),
            //             'qorder_unit_price'     => $unit_price,
            //             'qorder_currency'       => $currency,
            //             'qorder_total_price'    => $batch['qty'] * $unit_price,
            //             'qorder_eship_date'     => $batch['date'],
            //             'qorder_rship_date'     => $batch['date'],
            //             'qorder_rship_date_html'=> qot_ric_rdate_field($row_id, $unit_price, $batch['date']),
            //             'action'                => qot_ric_delete_order($row_id, true, true, 'multiple-shipment')
            //         ];
        
            //         foreach ($field as $index => $fname) {
            //             $final_session[$row_id][$index][$fname] = $quickorder[$fname] ?? '';
            //         }
            //         $i++;
            //     }
            // }
        
            // $_SESSION['quickorder'] = $final_session;
        }
        
        elseif ($selectedShipment === 'custom-shipment') {

            $_SESSION['quickorder'] = $_SESSION['quickorder_original'];
            $_SESSION['shipment_choice'] = 'custom-shipment';

            $qty_values_by_product = [];
            $requested_dates_by_product = [];

            foreach ($_SESSION['quickorder_original'] as $row_id => $rows) {
                $product_id = qot_get_product_id($row_id);
                $row_qty = function_exists('ric_wp_get_quickorder_row_value')
                    ? (int) ric_wp_get_quickorder_row_value($rows, 'qorder_qty_order', 0)
                    : 0;
                $requested_ship_date = function_exists('ric_wp_get_quickorder_row_value')
                    ? ric_wp_get_quickorder_row_value($rows, 'qorder_rship_date', '')
                    : '';

                $qty_values_by_product[$product_id][] = $row_qty;

                if (!empty($requested_ship_date)) {
                    $requested_dates_by_product[$product_id][$row_id] = $requested_ship_date;
                }
            }

            foreach ($qty_values_by_product as $product_id => $qty_values) {
                $qty_values = array_filter(array_map('intval', $qty_values), static function($qty) {
                    return $qty > 0;
                });

                if (empty($qty_values)) {
                    continue;
                }

                $unique_qty_values = array_unique($qty_values);
                $total_qty = count($unique_qty_values) === 1 ? max($qty_values) : array_sum($qty_values);

                if (function_exists('ric_wp_rebuild_custom_shipment_structure')) {
                    ric_wp_rebuild_custom_shipment_structure($product_id, $total_qty, $requested_dates_by_product[$product_id] ?? []);
                }
            }
        }
        

        $response['message'] = 'success';
        $response['data']    = qot_ric_tbody_data($_SESSION['quickorder']);

        wp_send_json($response);
    }

    
    private function ric_wp_build_two_shipment_quickorder($original_orders)
    {
        global $field;

        if (empty($original_orders) || !is_array($original_orders)) {
            return [];
        }

        $final_session = [];
        $consolidated_totals = [];
        $qty_values_by_product = [];

        foreach ($original_orders as $key => $indexed_data) {
            $product_id = qot_get_product_id($key);
            $row_qty = 0;

            foreach ($indexed_data as $field_item) {
                if (isset($field_item['qorder_qty_order'])) {
                    $row_qty = (int) $field_item['qorder_qty_order'];
                    break;
                }
            }

            $qty_values_by_product[$product_id][] = $row_qty;
        }

        foreach ($qty_values_by_product as $product_id => $qty_values) {
            $qty_values = array_filter(array_map('intval', $qty_values), static function($qty) {
                return $qty > 0;
            });

            if (empty($qty_values)) {
                continue;
            }

            $unique_qty_values = array_unique($qty_values);
            $consolidated_totals[$product_id] = count($unique_qty_values) === 1 ? max($qty_values) : array_sum($qty_values);
        }

        foreach ($consolidated_totals as $product_id => $total_qty) {
            $product = wc_get_product($product_id);
            if (!$product || $total_qty <= 0) {
                continue;
            }

            $unit_price = (float) $product->get_price();
            $stock_qty  = max(0, (int) $product->get_stock_quantity());
            $currency   = get_woocommerce_currency_symbol();

            $stock_row_qty = min($total_qty, $stock_qty);
            $backorder_row_qty = max(0, $total_qty - $stock_qty);

            if ($stock_row_qty > 0) {
                $row_id = (string) $product_id;
                $ship_date = qot_ric_date_cacl($product_id, $stock_qty, $stock_row_qty);

                $quickorder = [
                    'qorder_id'             => $product_id,
                    'qorder_did'            => $row_id,
                    'qorder_quickview'      => '<button data-id="'.$row_id.'" class="qorder_quickview"><i class="fa fa-info-circle"></i></button>',
                    'qorder_name'           => $product->get_name(),
                    'qorder_sku'            => $product->get_sku(),
                    'qorder_description'    => $product->get_short_description(),
                    'qorder_qty_stock'      => $stock_qty,
                    'qorder_qty_order'      => $stock_row_qty,
                    'qorder_qty_consider'   => $stock_row_qty,
                    'qorder_qty_order_html' => qot_ric_qty_order_field($row_id, $stock_row_qty),
                    'qorder_unit_price'     => $unit_price,
                    'qorder_currency'       => $currency,
                    'qorder_total_price'    => $stock_row_qty * $unit_price,
                    'qorder_eship_date'     => $ship_date,
                    'qorder_rship_date'     => '',
                    'qorder_rship_date_html'=> '',
                    'action'                => qot_ric_delete_order($row_id, false, false, 'two-shipment')
                ];

                foreach ($field as $index => $fname) {
                    $final_session[$row_id][$index][$fname] = $quickorder[$fname] ?? '';
                }
            }

            if ($backorder_row_qty > 0) {
                $row_id = $product_id . '_0';
                $ship_date = qot_ric_date_cacl($product_id, $stock_qty, $total_qty);

                $quickorder = [
                    'qorder_id'             => $product_id,
                    'qorder_did'            => $row_id,
                    'qorder_quickview'      => '<button data-id="'.$row_id.'" class="qorder_quickview"><i class="fa fa-info-circle"></i></button>',
                    'qorder_name'           => $product->get_name(),
                    'qorder_sku'            => $product->get_sku(),
                    'qorder_description'    => $product->get_short_description(),
                    'qorder_qty_stock'      => 0,
                    'qorder_qty_order'      => $backorder_row_qty,
                    'qorder_qty_consider'   => $backorder_row_qty,
                    'qorder_qty_order_html' => qot_ric_qty_order_field($row_id, $backorder_row_qty),
                    'qorder_unit_price'     => $unit_price,
                    'qorder_currency'       => $currency,
                    'qorder_total_price'    => $backorder_row_qty * $unit_price,
                    'qorder_eship_date'     => $ship_date,
                    'qorder_rship_date'     => '',
                    // 'qorder_rship_date'     => $ship_date,
                    'qorder_rship_date_html'=> '',
                    // 'qorder_rship_date_html'=> qot_ric_rdate_field($row_id, $unit_price, $ship_date),
                    'action'                => qot_ric_delete_order($row_id, false, false, 'two-shipment')
                ];

                foreach ($field as $index => $fname) {
                    $final_session[$row_id][$index][$fname] = $quickorder[$fname] ?? '';
                }
            }
        }

        ric_wp_apply_two_shipment_backorder_max_date($final_session);

        return $final_session;
    }
    
    private function ric_wp_build_multiple_shipment_quickorder($original_orders)
    {
        global $field;

        if (empty($original_orders) || !is_array($original_orders)) {
            return [];
        }

        $final_session = [];
        $consolidated_totals = [];

        foreach ($original_orders as $key => $indexed_data) {
            $product_id = qot_get_product_id($key);
            $row_qty = 0;

            foreach ($indexed_data as $field_item) {
                if (isset($field_item['qorder_qty_order'])) {
                    $row_qty = (int) $field_item['qorder_qty_order'];
                    break;
                }
            }

            if (!isset($consolidated_totals[$product_id])) {
                $consolidated_totals[$product_id] = 0;
            }

            $consolidated_totals[$product_id] += $row_qty;
        }

        foreach ($consolidated_totals as $product_id => $total_qty) {
            $product = wc_get_product($product_id);
            if (!$product || $total_qty <= 0) {
                continue;
            }

            $unit_price = (float) $product->get_price();
            $stock_qty  = (int) $product->get_stock_quantity();
            $currency   = get_woocommerce_currency_symbol();

            $availability_table = get_post_meta($product_id, 'availability_table', true);
            $split_config = [];
            $remaining = $total_qty;

            if (!empty($availability_table['get_capacity'])) {
                foreach ($availability_table['get_capacity'] as $item) {
                    if ($remaining <= 0) {
                        break;
                    }

                    $batch_qty = (int) ($item['qty'] ?? 0);
                    if ($batch_qty <= 0) {
                        continue;
                    }

                    $take = min($remaining, $batch_qty);
                    $availability_type = $item['type'] ?? '';
                    $ship_date = $item['date_available'] ?? '';
                    $ship_case = 3;

                    if ($availability_type === 'in_stock') {
                        $ship_date = date('Y-m-d', strtotime('+2 days'));
                        $ship_case = 1;
                    } elseif ($availability_type === 'work_order') {
                        $ship_case = 2;
                    } elseif ($availability_type === 'capacity_to_work') {
                        $ship_case = 3;
                    } elseif ($availability_type === 'lead_time') {
                        $ship_case = 4;
                    }

                    $split_config[] = [
                        'qty'  => $take,
                        'date' => !empty($ship_date) ? isHolidays($ship_date, $product_id, $ship_case) : qot_ric_date_cacl($product_id, 0, $take)
                    ];
                    $remaining -= $take;
                }
            }

            if ($remaining > 0) {
                $split_config[] = [
                    'qty'  => $remaining,
                    'date' => qot_ric_date_cacl($product_id, 0, $remaining)
                ];
            }

            $i = 0;
            foreach ($split_config as $batch) {
                $row_id = $product_id . '_' . $i;

                $quickorder = [
                    'qorder_id'             => $product_id,
                    'qorder_did'            => $row_id,
                    'qorder_quickview'      => '<button data-id="'.$row_id.'" class="qorder_quickview"><i class="fa fa-info-circle"></i></button>',
                    'qorder_name'           => $product->get_name(),
                    'qorder_sku'            => $product->get_sku(),
                    'qorder_description'    => $product->get_short_description(),
                    'qorder_qty_stock'      => $stock_qty,
                    'qorder_qty_order'      => $batch['qty'],
                    'qorder_qty_consider'   => $batch['qty'],
                    'qorder_qty_order_html' => qot_ric_qty_order_field($row_id, $batch['qty']),
                    'qorder_unit_price'     => $unit_price,
                    'qorder_currency'       => $currency,
                    'qorder_total_price'    => $batch['qty'] * $unit_price,
                    'qorder_eship_date'     => $batch['date'],
                    // 'qorder_rship_date'     => $batch['date'],
                    'qorder_rship_date'     => '',
                    'qorder_rship_date_html'=> '',
                    // 'qorder_rship_date_html'=> qot_ric_rdate_field($row_id, $unit_price, $batch['date']),
                    'action'                => qot_ric_delete_order($row_id, true, true, 'multiple-shipment')
                ];

                foreach ($field as $index => $fname) {
                    $final_session[$row_id][$index][$fname] = $quickorder[$fname] ?? '';
                }

                $i++;
            }
        }

        return $final_session;
    }


    /**
     * WP Ajax Function - to update shipping on wc cart
     */
    public function ric_wp_qorder_shipment_cart()
    {
        $resposnse = array();
        $splitiorder_by_cart = b2bwoo_splitiorder_by_cart(WC()->cart->get_cart());
        $backorder_availble = $splitiorder_by_cart['total_backorder_count'];
        if (isset($_POST['selectedShipment']) && !empty($_POST['selectedShipment'])) {
                unset($_SESSION['shipment_choice']);
                unset($_SESSION['cart_shipment_choice']);

                $selected_shipment = sanitize_text_field($_POST['selectedShipment']);
                $_SESSION['cart_shipment_choice'] = $selected_shipment;
                $_SESSION['shipment_choice'] = $selected_shipment;
                $_SESSION['rushabh_cart_shipment_choice_manual'] = true;

                if ($selected_shipment === 'multiple-shipment') {
                    $_SESSION['cart_shipment_choice'] = 'multiple-shipment';
                    $_SESSION['shipment_choice'] = 'multiple-shipment';
                }

                if (function_exists('WC') && WC()->session) {
                    WC()->session->set('cart_shipment_choice', $_SESSION['cart_shipment_choice']);
                    WC()->session->set('shipment_choice', $_SESSION['shipment_choice']);
                    WC()->session->set('rushabh_cart_shipment_choice_manual', true);
                }
                // if(empty($splitiorder_by_cart['total_backorder_count'])){
                //     $_SESSION['cart_shipment_choice']= 'single-shipment';
                // }else{
                //     $_SESSION['cart_shipment_choice']=  sanitize_text_field($_POST['selectedShipment']);
                // }            
        }
            
            
        $resposnse['message'] = 'success';
                    
        wp_send_json($resposnse);
    }

    /**
     * Woocommerce Hook - to get session from wc cart
     */
    public function ric_wp_qorder_shipment_cart_update($item, $values, $key)
    {
        
        if (is_admin() && !wp_doing_ajax()) {
            return $item;
        }
    
        if (isset($_POST['update_cart'])) {
            return $item;
        }
    
        if (!is_cart()) {
            return $item;
        }
        
        $custom_data  = $resposnse =array();
        $productid    = array();
        
        $page_id      = wc_get_page_id('cart');
        $host         = (is_ssl())? "https://":"http://";
        $actual_link  =  $host.$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];
            $cart_url = wc_get_cart_url();
        
        if ($actual_link == $cart_url) {
            // if (!isset($_SESSION['cart_shipment_choice']) && empty($_SESSION['cart_shipment_choice'])) {
            //         $_SESSION['cart_shipment_choice'] = 'two-shipment';
            // }
                        

                $i=0;
            // if (isset($_SESSION['qot_index'])) {
            //     $_SESSION['qot_index'] = $_SESSION['qot_index'] + 1;
            // } else {
            //     $_SESSION['qot_index'] = 0;
            // }
                $j = 0;

            if (isset($_SESSION['quickorder'])) {
                $quickorders  = $_SESSION['quickorder'];


                foreach ($quickorders as $key => $order) {
                    $order = array_flatten($order);

                    // if ($_SESSION['qot_index'] == $j) {
                        // $custom_product_id = $key;
                        if ($order['qorder_eship_date']) {
                            $ric_eship_date = $order['qorder_eship_date'];
                        }

                        if ($order['qorder_rship_date']) {
                            $ric_eship_date = $order['qorder_rship_date'];
                        }
                    // }

                    if ($order['qorder_eship_date']) {
                        $custom_data[$key]['ric_wp_eship_date'] = $order['qorder_eship_date'];
                    }

                    if ($order['qorder_rship_date']) {
                        $custom_data[$key]['ric_wp_rship_date'] = $order['qorder_rship_date'];
                    }
                    $j++;
                }
                    // echo '<pre>';
                    // print_r( $custom_data );
                    // echo '</pre>';
                if (isset($_SESSION['cart_shipment_choice']) && !empty($_SESSION['cart_shipment_choice'])) {
                    $shipment_choice    = $_SESSION['cart_shipment_choice'];

    
                    if ($shipment_choice == 'single-shipment') {
                        $custom_data_filter  =  one_shipment_of_all_items($custom_data);
                    } elseif ($shipment_choice == 'two-shipment') {
                        $custom_data_filter  =  two_shipment_of_all_items($custom_data);
                    }

                    $custom_data         = ric_wp_order_meta_sorting($custom_data_filter);

                    $ric_wp_order_meta   = $item['ric_wp_order_meta'];

                    $temp_data = array();
                    foreach ($ric_wp_order_meta as $prod_id => $shipData) {
                        foreach ($custom_data as $c_prod_id => $c_shipData) {
                            if ($prod_id == $c_prod_id) {
                                if (array_key_exists('ric_wp_eship_date', $c_shipData)) {
                                    $temp_data[$prod_id]['ric_wp_eship_date'] = $c_shipData['ric_wp_eship_date'];
                                }
                            }
                        }
                    }

                    $item['ric_wp_order_meta']=$temp_data;
                }
            }
        }
        return $item;
    }



    public function ric_wp_custom_add_to_cart($cart_item_key, $product_id)
    {
        if (!session_id()) {
            session_start();
        }

        $this->ric_wp_rebuild_quickorder_from_cart($product_id);
    }

    public function ric_wp_after_cart_item_quantity_update($cart_item_key, $quantity, $old_quantity, $cart)
    {
        if ((isset($_REQUEST['add-to-cart']) && !empty($_REQUEST['add-to-cart'])) 
            || (isset($_REQUEST['wc-ajax']) && $_REQUEST['wc-ajax'] == 'add_to_cart')) {
            return;
        }

        if ((int)$quantity === (int)$old_quantity) {
            return;
        }
        if (!session_id()) {
            session_start();
        }



        $cart_item = $cart->get_cart()[$cart_item_key];
        $product_id = $cart_item['product_id'];
        
        if (!empty($_SESSION['quickorder'])) {
            $this->ric_wp_rebuild_quickorder_from_cart($product_id);
        }
    }

    public function ric_wp_rebuild_quickorder_from_cart($product_id)
    {
        global $field;

        $product = wc_get_product($product_id);
        if (!$product) return;

        $unit_price = (float) $product->get_price();
        $currency   = get_woocommerce_currency_symbol();
        $stock_qty  = (int) $product->get_stock_quantity();

        $cart_qty = 0;

        foreach (WC()->cart->get_cart() as $cart_item) {
            if ((int)$cart_item['product_id'] === (int)$product_id) {
                $cart_qty += (int)$cart_item['quantity'];
            }
        }

        // 🔹 Remove all existing session rows for this product
        foreach ($_SESSION['quickorder'] as $key => $val) {
            if (qot_get_product_id($key) == $product_id) {
                unset($_SESSION['quickorder'][$key]);
            }
        }

        if ($cart_qty <= 0) return;

        $stock_row_qty     = min($cart_qty, $stock_qty);
        $backorder_row_qty = max(0, $cart_qty - $stock_qty);

        // if ($backorder_row_qty > 0) {
        //     $_SESSION['shipment_choice'] = 'two-shipment';
        // }
        /* =====================================================
        CREATE STOCK ROW
        ===================================================== */
        if ($stock_row_qty > 0) {

            $row_id = $product_id;

            $quickorder = [
                'qorder_id'             => $product_id,
                'qorder_did'            => $row_id,
                'qorder_quickview'      => '<button data-id="'.$row_id.'" class="qorder_quickview"><i class="fa fa-info-circle"></i></button>',
                'qorder_name'           => $product->get_name(),
                'qorder_sku'            => $product->get_sku(),
                'qorder_description'    => $product->get_short_description(),
                'qorder_qty_stock'      => $stock_qty,
                'qorder_qty_order'      => $stock_row_qty,
                'qorder_qty_consider'   => $stock_row_qty,
                'qorder_qty_order_html' => qot_ric_qty_order_field($row_id, $stock_row_qty),
                'qorder_unit_price'     => $unit_price,
                'qorder_currency'       => $currency,
                'qorder_total_price'    => $stock_row_qty * $unit_price,
                'qorder_eship_date'     => qot_ric_date_cacl($product_id, $stock_qty, $stock_row_qty),
                'qorder_rship_date'     => '',
                'qorder_rship_date_html'=> '',
                'action'                => ''
            ];

            foreach ($field as $fname) {
                $_SESSION['quickorder'][$row_id][][$fname] = $quickorder[$fname] ?? '';
            }
        }

        /* =====================================================
        CREATE BACKORDER ROW
        ===================================================== */

        // echo $backorder_row_qty.'backorder_row_qty';
        if ($backorder_row_qty > 0) {
            $row_id = $product_id . '_0';

            $ship_date = qot_ric_date_cacl($product_id, $backorder_row_qty, $cart_qty);
            $quickorder = [
                'qorder_id'             => $product_id,
                'qorder_did'            => $row_id,
                'qorder_quickview'      => '<button data-id="'.$row_id.'" class="qorder_quickview"><i class="fa fa-info-circle"></i></button>',
                'qorder_name'           => $product->get_name(),
                'qorder_sku'            => $product->get_sku(),
                'qorder_description'    => $product->get_short_description(),
                'qorder_qty_stock'      => 0,
                'qorder_qty_order'      => $backorder_row_qty,
                'qorder_qty_consider'   => $backorder_row_qty,
                'qorder_qty_order_html' => qot_ric_qty_order_field($row_id, $backorder_row_qty),
                'qorder_unit_price'     => $unit_price,
                'qorder_currency'       => $currency,
                'qorder_total_price'    => $backorder_row_qty * $unit_price,
                'qorder_eship_date'     => $ship_date,
                'qorder_rship_date'     => '',
                // 'qorder_rship_date'     => $ship_date,
                // 'qorder_rship_date_html'=> qot_ric_rdate_field($row_id, $unit_price, $ship_date),
                'qorder_rship_date_html'=> '',
                'action'                => ''
            ];

            foreach ($field as $fname) {
                $_SESSION['quickorder'][$row_id][][$fname] = $quickorder[$fname] ?? '';
            }
        }

        $_SESSION['quickorder_original'] = $_SESSION['quickorder'];
    }

    public function ric_quick_sss(){
        if(!isset($_GET['check_session'])) return; 

        echo '<pre>';
        print_r($_SESSION['quickorder']);
        echo '</pre>';
        die;
    }


    public function add_hooks()
    {

        add_action('astra_head_bottom', array($this,'ric_load_early_table'));
        add_action('wp_ajax_ric_wp_qorder_custom_search_products', array($this, 'ric_wp_qorder_custom_search_products'));
        add_action('wp_ajax_nopriv_ric_wp_qorder_custom_search_products', array($this, 'ric_wp_qorder_custom_search_products'));

        add_filter('body_class', array($this,'ric_wp_quickorder_body_class'), 1);

        add_action('pre_get_posts', array($this, 'ric_wp_pre_get_posts'), 99);

        add_action('woocommerce_add_to_cart', array($this, 'ric_wp_custom_add_to_cart'), 10, 2);

        add_action('woocommerce_after_cart_item_quantity_update', array($this, 'ric_wp_after_cart_item_quantity_update'), 9, 4);

        add_action('woocommerce_cart_item_removed', array($this, 'ric_wp_cart_item_removed'), 10, 2);
        add_action('woocommerce_thankyou', array($this, 'ric_wp_quick_item_removed'), 10, 1);
        add_action('wp_logout', array($this, 'ric_wp_quick_item_removed' ));

        // add_action(' woocommerce_cart_updated', array($this, 'ric_wp_woocommerce_cart_updated'),10);

        add_action('switch_to_user', array($this, 'ric_wp_switch_user_clear' ), 10, 4);


        add_action('wp_ajax_ric_wp_qorder_shipment', array($this,'ric_wp_qorder_shipment'));
        add_action('wp_ajax_nopriv_ric_wp_qorder_shipment', array($this,'ric_wp_qorder_shipment'));

        add_action('wp_ajax_ric_wp_qorder_shipment_cart', array($this,'ric_wp_qorder_shipment_cart'));
        add_action('wp_ajax_nopriv_ric_wp_qorder_shipment_cart', array($this,'ric_wp_qorder_shipment_cart'));

        
        // add_action('woocommerce_get_cart_item_from_session', array($this,'ric_wp_qorder_shipment_cart_update'), 20, 3); // cart quantity update-- hard refresh



        add_action('init', array($this,'ric_quick_sss'), 20, 3);
    }
}


?>
