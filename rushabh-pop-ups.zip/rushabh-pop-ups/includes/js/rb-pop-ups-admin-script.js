jQuery(document).ready(function ($) {
    $("#loaderDropdown").hide();
    $("#productList").show();
    $("#cat").change(function () {
        var catId = $(this).val();
        console.log(catId,"CATID");
        $("#loaderDropdown").show();
        $("#productList").hide();
        $.ajax({
            url: ajax_object.ajax_url,
            method: 'POST',
            dataType: 'json',
            data: {
                action: 'rb_pop_ups_category_options',
                catId: catId,
               // nonce: ajax_object.nonce,
            },
            success: function (res) {
              
                if(res.status == true){
                    var productList = res.products;
                    // console.log(productList,"productList");
                    var select='';
                    var id='';
                    var name='';
                    for (let index = 0; index < productList.length; index++) {
                        console.log(productList[index].id,"id");
                         id = parseInt(productList[index].id);
                         name = productList[index].name;
                         select += "<option value="+id+">"+name+"</option>";
             
                    }
                    // console.log(select,"select");
                     $('#rb_pop_up_product_id').html(select);
                     $("#loaderDropdown").hide();
                     $("#productList").show();
                }
            },
        }).catch((error) => {
            console.error('Error:', error);
            $("#loaderDropdown").hide();
            $("#productList").show();
        });
    });
  
    // Add Variant Repeater
    var repeater_variant_count = Number($('#rb-pop-up-variant-count').val()) + 1;
    $(document).on('click', '#rb-pop-up-variant-add-button', function (e) {
        e.preventDefault();
        var defaultDiv = $('.rb-pop-up-variant-repeater-default-div').clone();
        var extraDiv = defaultDiv.removeClass('rb-pop-up-variant-repeater-default-div hidden');
        extraDiv.find('#rb-pop-up-variant-name').attr('name', '_rb_pop_ups_variant_repeater[' + repeater_variant_count + '][name]');
        extraDiv.find('#rb-pop-up-variant-sku').attr('name', '_rb_pop_ups_variant_repeater[' + repeater_variant_count + '][variant_id]');
        extraDiv.find('.rb-pop-up-variant-icon-url').attr('name', '_rb_pop_ups_variant_repeater[' + repeater_variant_count + '][icon_url]');
        extraDiv.find('#rb-pop-up-variant-desc').attr('name', '_rb_pop_ups_variant_repeater[' + repeater_variant_count + '][desc]');
        extraDiv.find('#rb-pop-up-variant-btn-name').attr('name', '_rb_pop_ups_variant_repeater[' + repeater_variant_count + '][btn_name]');
        extraDiv.find('#rb-pop-up-variant-btn-url').attr('name', '_rb_pop_ups_variant_repeater[' + repeater_variant_count + '][btn_url]');
        $(extraDiv).insertBefore('#rb-pop-up-variant-add-button');
        repeater_variant_count = repeater_variant_count + 1;
    });

    // Remove Variant Repeater
    $(document).on('click', '.rb-pop-ups-remove-btn', function () {
        $(this).closest('.rb-pop-ups-repeater-block').remove();
    });

    // upload pop product image
    $(document).on('click', '#rb-pop-up-image-upload-btn', function (e) {
        var mediaUploader;
        e.preventDefault();

        if (mediaUploader) {
            mediaUploader.open();
            return;
        }

        mediaUploader = wp.media.frames.file_frame = wp.media({
            title: "Choose Pop Image",
            button: {
                text: "Choose Image",
            },
            multiple: false,
        });

        mediaUploader.on("select", function () {
            var attachment = mediaUploader.state().get("selection").first().toJSON();
            $("#rb-pop-up-image-url").val(attachment.url);
            $("#rb-pop-up-image-preview-tag").attr("src", attachment.url);
            $('#rb-pop-up-image-preview-div').removeClass('hidden');
            $('#rb-pop-up-image-remove-btn').removeClass('hidden');

        });

        mediaUploader.open();
    });

    $(document).on('click', '#rb-pop-up-image-remove-btn', function (e) {
        e.preventDefault();
        $('#rb-pop-up-image-preview-div').addClass('hidden');
        $('#rb-pop-up-image-remove-btn').addClass('hidden');
        $("#rb-pop-up-image-url").val('');
        $("#rb-pop-up-image-preview-tag").attr("src", '');
    });


    // upload variant icon image
    $(document).on('click', '.rb-pop-up-variant-icon-upload-btn', function (e) {
        var mediaUploader;
        var current_element = $(this);
        e.preventDefault();

        if (mediaUploader) {
            mediaUploader.open();
            return;
        }

        mediaUploader = wp.media.frames.file_frame = wp.media({
            title: "Choose Variant Icon",
            button: {
                text: "Choose Image",
            },
            multiple: false,
        });

        mediaUploader.on("select", function () {
            var attachment = mediaUploader.state().get("selection").first().toJSON();
            current_element.closest("td").find('.rb-pop-up-variant-icon-url').val(attachment.url);
            current_element.closest("td").find('.rb-pop-up-variant-icon-preview-tag').attr("src", attachment.url);
            current_element.closest("td").find('.rb-pop-up-variant-icon-preview-div').removeClass('hidden');
            current_element.closest("td").find('.rb-pop-up-variant-icon-remove-btn').removeClass('hidden');
        });

        mediaUploader.open();
    });

    $(document).on('click', '.rb-pop-up-variant-icon-remove-btn', function (e) {
        e.preventDefault();
        $(this).closest("td").find('.rb-pop-up-variant-icon-preview-div').addClass('hidden');
        $(this).closest("td").find('.rb-pop-up-variant-icon-remove-btn').addClass('hidden');
        $(this).closest("td").find(".rb-pop-up-variant-icon-url").val('');
        $(this).closest("td").find(".rb-pop-up-variant-icon-preview-tag").attr("src", '');
    });

    // On Pop up product change
    $(document).on('change', '#rb_pop_up_product_id', function (e) {
        $('.rb-pop-ups-repeater-main-div div').remove();
        var product_id = $(this).val();
        $.ajax({
            url: ajax_object.ajax_url,
            method: 'POST',
            dataType: 'json',
            data: {
                action: 'rb_pop_ups_variant_options',
                product_id: product_id,
                nonce: ajax_object.nonce,
            },
            success: function (res) {

                if ($('.rb-pop-ups-repeater-block-sku.hidden').length > 0) {
                    $('.rb-pop-ups-repeater-block-sku').removeClass('hidden');
                }
                if (res.status) {
                    $('#rb-pop-up-variant-sku').html(res.html);
                } else {
                    $('.rb-pop-ups-repeater-block-sku').addClass('hidden');
                }
            },
        }).catch((error) => {
            console.error('Error:', error);
        });
    });

    $(document).on('click', '#publish', function (e) {
        var pop_up_name = $('#rb_pop_up_name');
        if (pop_up_name.length && pop_up_name.val() == '') {
            e.preventDefault();
            $('.rb_pop_up_error').removeClass('hidden');
        }
    });

});

