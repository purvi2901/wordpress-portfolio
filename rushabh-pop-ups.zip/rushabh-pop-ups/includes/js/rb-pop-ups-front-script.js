"use strict";

jQuery(document).ready(function ($) {

    $(document).on('click', '#rb-pop-up-btn', function (e) {
        e.preventDefault();
        var pop_up_id = $(this).data('pop-up-id');
        $('.rb-pop-up-product-modal').addClass('show-modal');
        $('#rb-pop-up-btn-loader').removeClass('hidden');
        $.ajax({
            url: ajax_object.ajax_url,
            method: 'POST',
            dataType: 'json',
            data: {
                action: 'rb_pop_ups_content',
                pop_up_id: pop_up_id,
                nonce: ajax_object.nonce,
            },
            success: function (res) {
                
                $('#rb-pop-up-btn').removeClass('pointer-null');
                if (res.status) {
                    $('#rb-pop-up-btn-loader').addClass('hidden');
                    var modal = $(".rb-pop-up-product-modal .modal-content");
                    modal.append(res.pop_up_html);
                }
            },
        }).catch((error) => {
            console.error('Error:', error);
        });
    });

    // close Pop up
    $(document).on("click", "#rb-pop-up-modal-close", function () {
        $('#rb-pop-up-btn-loader').removeClass('hidden');
        $('.rb-pop-up-product-modal').removeClass('show-modal');
        $(".rb-pop-up-content-main").remove();
    });
});