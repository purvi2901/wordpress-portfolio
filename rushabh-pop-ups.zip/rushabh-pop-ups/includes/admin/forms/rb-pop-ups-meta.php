<?php
/**
 * Handles the pop ups meta box functionality
 *
 * @package Rushabh Pop Ups
 * @since   1.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

global $post, $rb_pop_ups_model;
$model  = $rb_pop_ups_model;
$prefix = RB_POP_UPS_META_PREFIX;
wp_nonce_field( RB_POP_UPS_BASENAME, 'rb_pop_ups_meta_box_nonce' );

$rb_pop_up_name              = get_post_meta( $post->ID, $prefix . 'name', true );
$rb_pop_up_product_id        = get_post_meta( $post->ID, $prefix . 'product_id', true );
$rb_pop_up_shortcode         = get_post_meta( $post->ID, $prefix . 'shortcode', true );
$shortcode_btn_txt           = get_post_meta( $post->ID, $prefix . 'shortcode_btn_txt', true );
$rb_pop_up_heading           = get_post_meta( $post->ID, $prefix . 'heading', true );
$rb_pop_up_desc              = get_post_meta( $post->ID, $prefix . 'desc', true );
$rb_pop_up_image_url         = get_post_meta( $post->ID, $prefix . 'image_url', true );
$rb_pop_ups_variant_repeater = get_post_meta( $post->ID, $prefix . 'variant_repeater', true );
?>
<table class="form-table" id="rb-pop-ups-table">
	<tbody>
		<tr>
			<th scope="row">
				<label for="rb_pop_up_name"><strong><?php echo esc_html__( 'Pop up name ', 'rbpopups' ); ?><span class="required">*</strong></label>
			</th>
			<td>
				<input type="text" id="rb_pop_up_name" class="rb-pop-up-name regular-text" name="<?php echo $prefix; ?>name" value="<?php echo $model->rb_pop_ups_escape_attr( $rb_pop_up_name ); ?>" />
				<span class="rb_pop_up_error hidden"><?php esc_html_e( 'Pleases Enter Pop up name.', 'rbpopups' ); ?></span>
			</td>
			</th>
			
		</tr>

		<?php if ( ! empty( $rb_pop_up_shortcode ) ) { ?>
		<tr>
			<th scope="row">
				<label for="rb_pop_up_shortcode"><strong><?php echo esc_html__( 'Short code', 'rbpopups' ); ?></strong></label>
			</th>
			<td>
				<input type="hidden" id="rb_pop_up_shortcode" class="rb-pop-up-shortcode regular-text" name="<?php echo $prefix; ?>shortcode" value="<?php echo $model->rb_pop_ups_escape_attr( $rb_pop_up_shortcode ); ?>" readonly />
				<span><?php echo esc_html( '[' . $rb_pop_up_shortcode . ']' ); ?></span>
			</td>
		</tr>
		<?php } ?>
		<tr>
			<th scope="row">
				<label for="rb_pop_up_shortcode_btn_txt"><strong><?php echo esc_html__( 'Short Code Button Name', 'rbpopups' ); ?></strong></label>
			</th>
			<td>
				<input type="text" id="rb_pop_up_shortcode_btn_txt" class="rb-pop-up-shortcode-btn-txt regular-text" name="<?php echo $prefix; ?>shortcode_btn_txt" value="<?php echo $model->rb_pop_ups_escape_attr( $shortcode_btn_txt ); ?>" />
			</td>
		</tr>
		<tr>
			<th scope="row">
				<label for="rb_pop_up_heading"><strong><?php echo esc_html__( 'Heading', 'rbpopups' ); ?></strong></label>
			</th>
			<td>
				<input type="text" id="rb_pop_up_heading" class="rb-pop-up-name regular-text" name="<?php echo $prefix; ?>heading" value="<?php echo $model->rb_pop_ups_escape_attr( $rb_pop_up_heading ); ?>" />
			</td>
		</tr>
		<tr>
			<th scope="row">
				<label for="rb_pop_up_image"><strong><?php echo esc_html__( 'Image', 'rbpopups' ); ?></strong></label>
				<input type="hidden" name="<?php echo $prefix; ?>image_url" id="rb-pop-up-image-url" value="<?php echo $model->rb_pop_ups_escape_attr( $rb_pop_up_image_url ); ?>">
			</th>
			<td>
				<div class="rb-pop-up-image-upload">
					<button class="button" id="rb-pop-up-image-upload-btn"><?php echo esc_html__( 'Upload Image', 'rbpopups' ); ?></button>
					<button class="button <?php echo empty( $rb_pop_up_image_url ) ? 'hidden' : ''; ?>" id="rb-pop-up-image-remove-btn"><?php echo esc_html__( 'Remove Image', 'rbpopups' ); ?></button>
					<div id="rb-pop-up-image-preview-div" class="<?php echo empty( $rb_pop_up_image_url ) ? 'hidden' : ''; ?>">
						<img src="<?php echo esc_url( $rb_pop_up_image_url ); ?>" id="rb-pop-up-image-preview-tag" alt="pop_up_image" width="200px" height="200px">
					</div>
				</div>
			</td>
		</tr>
		<tr>
			<th scope="row">
				<label for="rb_pop_up_desc"><strong><?php echo esc_html__( 'Description', 'rbpopups' ); ?></strong></label>
			</th>
			<td>
				<textarea id="rb_pop_up_desc" class="rb-pop-ups-desc" name="<?php echo $prefix; ?>desc" cols="49"><?php echo $model->rb_pop_ups_escape_attr( $rb_pop_up_desc ); ?></textarea>
			</td>
		</tr>
		<tr>
		<th scope="row">
				<label for="rb_pop_up_product_id"><strong><?php echo esc_html__( 'Category ', 'rbpopups' ); ?><span class="required">*</strong></label>
			</th>
			<?php
			$cat_id = get_post_meta( $post->ID, 'cat', true );
			// Get all WooCommerce products.
			$args = array(
				'selected'           => $cat_id,
				'hierarchical'       => 1, 
				'taxonomy'           => 'product_cat',
			)
			
			?>
			<td>
				<?php 
					wp_dropdown_categories( $args ); 
				?>
			
			</td>
		</tr>
		<tr id="loaderDropdown" style="display:none">
			<th scope="row">
				<label for="rb_pop_up_product_id"><strong><?php echo esc_html__( 'Product name ', 'rbpopups' ); ?><span class="required">*</strong></label>
			</th>
			<td>
				<img src="<?php echo RB_POP_UPS_PLUGIN_URL.'includes/images/loader.gif'?>" />
			</td>
		</tr>
		<tr id="productList">

			<th scope="row">
				<label for="rb_pop_up_product_id"><strong><?php echo esc_html__( 'Product name ', 'rbpopups' ); ?><span class="required">*</strong></label>
			</th>
			<?php
			// Get all WooCommerce products.
			$products = get_posts(
				array(
					'post_type'   => 'product',
					'numberposts' => -1,
				)
			);
			?>
			<td>
				<select name="<?php echo $prefix; ?>product_id" class="rb-pop-up-product-id regular-text" id="rb_pop_up_product_id">
					<?php
					if ( ! empty( $products ) ) {
						foreach ( $products as $product ) {
							?>
						<option value="<?php echo $model->rb_pop_ups_escape_attr( $product->ID ); ?>" <?php selected( $rb_pop_up_product_id, $product->ID, true ); ?> ><?php echo esc_html( $product->post_title ); ?></option>
							<?php
						}
					}
					?>
				</select>	
				<?php if ( isset( $rb_pop_ups_error['product_id'] ) && ! empty( $rb_pop_ups_error['product_id'] ) ) { ?>
						<span class="rb_pop_up_error"><?php echo esc_html( $rb_pop_ups_error['product_id'] ); ?></span>
				<?php } ?>
			</td>
		</tr>
		<tr>
			<th>
				<label for="rb_pop_ups_variant_repeater"><strong><?php echo esc_html__( 'Add Variant', 'rbpopups' ); ?></strong></label>
			</th>
			<td>
				<div class="rb-pop-up-variant-repeater-default-div hidden">
					<div class="rb-pop-ups-repeater-block">
						<table class="repeater-table">
							<tbody>
								<tr scope="row">
									<th>
										<label><?php echo esc_html__( 'Name:', 'rbpopups' ); ?></label>
									</th>
									<td><input id="rb-pop-up-variant-name" type="text" class="regular-text" value=""></td>
								</tr>
								<?php
								$variations_ids = '';
								if ( ! empty( $rb_pop_up_product_id ) ) {
									$product = wc_get_product( $rb_pop_up_product_id );
									if ( $product && $product->is_type( 'variable' ) ) {
										$variations_ids = $product->get_children();
									}
								}
								?>
								<tr class="rb-pop-ups-repeater-block-sku <?php echo empty( $variations_ids ) ? 'hidden' : ''; ?>" scope="row">
									<th>
										<label><?php echo esc_html__( 'SKU:', 'rbpopups' ); ?></label>
									</th>
									<td>
									<select id="rb-pop-up-variant-sku">
										<?php
										if ( ! empty( $variations_ids ) ) {
											foreach ( $variations_ids as $variation_id ) {
												$variation = wc_get_product( $variation_id );
												if ( $variation ) {
													?>
													<option value="<?php echo $model->rb_pop_ups_escape_attr( $variation->get_id() ); ?>"><?php echo esc_html( $variation->get_sku() ); ?></option>
													<?php
												}
											}
										}
										?>
									</select>
									</td>
								</tr>
								</tr>
								<tr scope="row">
									<th>
										<label><?php echo esc_html__( 'Icon:', 'rbpopups' ); ?></label>
									</th>
									<td>
										<div class="rb-pop-up-image-upload">
											<input type="hidden" class="rb-pop-up-variant-icon-url" value="">
											<button class="rb-pop-up-variant-icon-upload-btn button"><?php echo esc_html__( 'Upload Icon', 'rbpopups' ); ?></button>
											<button class="rb-pop-up-variant-icon-remove-btn button hidden"><?php echo esc_html__( 'Remove Image', 'rbpopups' ); ?></button>
											<div class="rb-pop-up-variant-icon-preview-div hidden">
												<img src="" class="rb-pop-up-variant-icon-preview-tag" alt="pop_up_variant_icon" width="200px" height="200px">
											</div>
										</div>
									</td>
								</tr>
								<tr scope="row">
									<th>
										<label><?php echo esc_html__( 'Description:', 'rbpopups' ); ?></label>
									</th>
									<td><textarea id="rb-pop-up-variant-desc" class="regular-text" value="" cols="20" rows="3"></textarea></td>
								</tr>
								<!-- <tr scope="row">
									<th>
										<label><?php //echo esc_html__( 'Button Name:', 'rbpopups' ); ?></label>
									</th>
									<td><input id="rb-pop-up-variant-btn-name" type="text" class="regular-text" value=""></td>
								</tr> -->
								<tr scope="row">
									<th>
										<label><?php echo esc_html__( 'Button URL:', 'rbpopups' ); ?></label>
									</th>
									<td><input placeholder="Enter URL for Technical Specs" id="rb-pop-up-variant-btn-url" type="url" class="regular-text" value=""></td>
								</tr>
							</tbody>
						</table>
						<button type="button" class="rb-pop-ups-remove-btn button"><?php echo esc_html__( 'Remove Variant', 'rbpopups' ); ?></button>
					</div>
				</div>
				<div class="rb-pop-ups-repeater-main-div">
					<?php
					if ( ! empty( $rb_pop_ups_variant_repeater ) ) {
						$rb_pop_ups_repeater_count = 0;
						foreach ( $rb_pop_ups_variant_repeater as $key => $value ) {
							$rb_pop_ups_repeater_count = $key;
							$variant_name              = $value['name'] ?? '';
							$variant_id                = $value['variant_id'] ?? '';
							$variant_icon_url          = $value['icon_url'] ?? '';
							$variant_desc              = $value['desc'] ?? '';
							$variant_btn_name          = $value['btn_name'] ?? '';
							$variant_btn_url           = $value['btn_url'] ?? '';

							?>
							<div class="rb-pop-ups-repeater-block">
								<table class="repeater-table">
									<tbody>
										<tr scope="row">
											<th>
												<label for="_rb_pop_ups_variant_repeater[<?php echo $key; ?>][name]"><?php echo esc_html__( 'Name:', 'rbpopups' ); ?></label>
											</th>
											<td><input type="text" class="regular-text" name="_rb_pop_ups_variant_repeater[<?php echo $key; ?>][name]" value="<?php echo $model->rb_pop_ups_escape_attr( $variant_name ); ?>"></td>
										</tr>

										<?php
										$variations_ids = '';
										if ( ! empty( $rb_pop_up_product_id ) ) {
											$product = wc_get_product( $rb_pop_up_product_id );
											if ( $product && $product->is_type( 'variable' ) ) {
												$variations_ids = $product->get_children();
											}
										}
										if ( ! empty( $variations_ids ) ) {
											?>
										<tr scope="row">
											<th>
												<label for="_rb_pop_ups_variant_repeater[<?php echo $key; ?>][variant_id]"><?php echo esc_html__( 'SKU:', 'rbpopups' ); ?></label>
											</th>
											<td>
											<select name="_rb_pop_ups_variant_repeater[<?php echo $key; ?>][variant_id]" id="rb-pop-up-variant-id">
												<?php
												foreach ( $variations_ids as $variation_id ) {
													$variation = wc_get_product( $variation_id );
													if ( $variation ) {
														?>
																<option value="<?php echo $model->rb_pop_ups_escape_attr( $variation->get_id() ); ?>" <?php selected( $variant_id, $variation->get_id(), true ); ?>><?php echo esc_html( $variation->get_sku() ); ?></option>
															<?php
													}
												}
												?>
											</select>
											</td>
										</tr>
										<?php } ?>
										<tr scope="row">
											<th>
												<label><?php echo esc_html__( 'Icon:', 'rbpopups' ); ?></label>
											</th>
											<td>
												<div class="rb-pop-up-image-upload">
													<input type="hidden" class="rb-pop-up-variant-icon-url" name="_rb_pop_ups_variant_repeater[<?php echo $key; ?>][icon_url]" value="<?php echo esc_url( $variant_icon_url ); ?>">
													<button class="rb-pop-up-variant-icon-upload-btn button"><?php echo esc_html__( 'Upload Icon', 'rbpopups' ); ?></button>
													<button class="rb-pop-up-variant-icon-remove-btn button <?php echo empty( $variant_icon_url ) ? 'hidden' : ''; ?>"><?php echo esc_html__( 'Remove Image', 'rbpopups' ); ?></button>
													<div class="rb-pop-up-variant-icon-preview-div <?php echo empty( $variant_icon_url ) ? 'hidden' : ''; ?>">
														<img src="<?php echo esc_url( $variant_icon_url ); ?>" class="rb-pop-up-variant-icon-preview-tag" alt="pop_up_variant_icon" width="200px" height="200px">
													</div>
												</div>
											</td>
										</tr>
										<tr scope="row">
											<th>
												<label for="_rb_pop_ups_variant_repeater[<?php echo $key; ?>][desc]"><?php echo esc_html__( 'Description:', 'rbpopups' ); ?></label>
											</th>
											<td><textarea class="regular-text" name="_rb_pop_ups_variant_repeater[<?php echo $key; ?>][desc]" value="" cols="20" rows="3"><?php echo $model->rb_pop_ups_escape_attr( $variant_desc ); ?></textarea></td>
										</tr>
										<tr scope="row">
											<th>
												<label for="_rb_pop_ups_variant_repeater[<?php echo $key; ?>][btn_name]"><?php echo esc_html__( 'Button Name:', 'rbpopups' ); ?></label>
											</th>
											<td><input type="text" class="regular-text" name="_rb_pop_ups_variant_repeater[<?php echo $key; ?>][btn_name]" value="<?php echo $model->rb_pop_ups_escape_attr( $variant_btn_name ); ?>"></td>
										</tr>
										<tr scope="row">
											<th>
												<label for="_rb_pop_ups_variant_repeater[<?php echo $key; ?>][btn_url]"><?php echo esc_html__( 'Button URL:', 'rbpopups' ); ?></label>
											</th>
											<td><input type="text" class="regular-text" name="_rb_pop_ups_variant_repeater[<?php echo $key; ?>][btn_url]" value="<?php echo $model->rb_pop_ups_escape_attr( $variant_btn_url ); ?>"></td>
										</tr>
									</tbody>
								</table>
								<button type="button" id="rb-pop-ups-remove-btn" class="rb-pop-ups-remove-btn button button"><?php echo esc_html__( 'Remove Variant', 'rbpopups' ); ?></button>
							</div>
							<?php
						}
					}
					?>
					<input type="hidden" id="rb-pop-up-variant-count" name="rb_pop_ups_repeater_count" class="rb_pop_ups_repeater_count" value="<?php echo isset( $rb_pop_ups_repeater_count ) ? esc_html( $rb_pop_ups_repeater_count ) : 0; ?>">
					<button id="rb-pop-up-variant-add-button" class="rb-pop-up-variant-add-button button"><?php echo esc_html__( 'Add New Variant' ); ?></button>
				</div>
			</td>
		</tr>
	</tbody>
</table>