<?php
/**
 * Shortcode File
 *
 * @author  Wpweb
 * @package Rushabh Pop Ups
 * @version 1.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Shortcode Class
 *
 * Handles generic shortcode functionailties
 *
 * @package Rushabh Pop Ups
 * @since 1.0.0
 */
class Rb_Pop_Ups_Shortcode {

	/**
	 * Model variable
	 *
	 * @var   object
	 * @since 1.0.0
	 */
	public $model;

	/**
	 * Class Constructer
	 *
	 * @package Rushabh Pop Ups
	 * @since 1.0.0
	 */
	public function __construct() {

		global $rb_pop_up_model;
		$this->model = $rb_pop_up_model;
	}

	/**
	 * Pop up ShortCode button.
	 *
	 * @package Rushabh Pop Ups
	 * @since 1.0.0
	 */
	public function rb_pop_up_button( $atts, $content, $post_id ) {
		ob_start();
		$shortcode_btn_txt = get_post_meta( $post_id, '_rb_pop_ups_shortcode_btn_txt', true );
		?>
		<div class="rb-pop-up-btn-wrap">
			<a id="rb-pop-up-btn" href="javascript:void(0)" data-pop-up-id="<?php echo esc_html( $post_id ); ?>"><?php echo ! empty( $shortcode_btn_txt ) ? esc_html( $shortcode_btn_txt ) : esc_html__( 'View Product', 'rbpopups' ); ?></a>
		</div>
		<?php
		return ob_get_clean();
	}

	/**
	 * Add pop up ShortCode.
	 *
	 * @package Rushabh Pop Ups
	 * @since 1.0.0
	 */
	public function rb_pop_ups_shortcodes() {

		$prefix = RB_POP_UPS_META_PREFIX;

		$args = array(
			'post_type'      => 'rushabh_pop_ups',
			'posts_per_page' => -1,
		);

		$custom_query = new WP_Query( $args );

		if ( $custom_query->have_posts() ) {
			while ( $custom_query->have_posts() ) {

				$custom_query->the_post();

				$post_id = get_the_ID();

				$pop_up_shortcode_name = get_post_meta( $post_id, $prefix . 'shortcode', true );

				if ( ! empty( $pop_up_shortcode_name ) ) {

					add_shortcode(
						$pop_up_shortcode_name,
						function ( $atts, $content = null ) use ( $post_id ) {

							// Call the actual shortcode function with the additional argument.
							return $this->rb_pop_up_button( $atts, $content, $post_id );
						}
					);
				}
			}
		}
		wp_reset_postdata(); // Reset post data to the main query.
	}

	/**
	 * Pop up ShortCode content.
	 *
	 * @package Rushabh Pop Ups
	 * @since 1.0.0
	 */
	public function rb_pop_ups_content() {

		if ( isset( $_POST['nonce'] ) && wp_verify_nonce( $_POST['nonce'], 'ajax-nonce' ) ) {

			$pop_up_id = isset( $_POST['pop_up_id'] ) && ! empty( $_POST['pop_up_id'] ) ? sanitize_text_field( wp_unslash( $_POST['pop_up_id'] ) ) : '';
			$prefix    = RB_POP_UPS_META_PREFIX;

			$rb_pop_up_name              = get_post_meta( $pop_up_id, $prefix . 'name', true );
			$rb_pop_up_product_id        = get_post_meta( $pop_up_id, $prefix . 'product_id', true );
			$rb_pop_up_shortcode         = get_post_meta( $pop_up_id, $prefix . 'shortcode', true );
			$rb_pop_up_heading           = get_post_meta( $pop_up_id, $prefix . 'heading', true );
			$rb_pop_up_desc              = get_post_meta( $pop_up_id, $prefix . 'desc', true );
			$rb_pop_up_image_url         = get_post_meta( $pop_up_id, $prefix . 'image_url', true );
			$rb_pop_ups_variant_repeater = get_post_meta( $pop_up_id, $prefix . 'variant_repeater', true );
			$product = wc_get_product($rb_pop_up_product_id);
			$learn_more_url = site_url().'/learn-more-product/?product_id='.$rb_pop_up_product_id;
			$product_url = wc_get_product($rb_pop_up_product_id)->add_to_cart_url();
			ob_start();
			?>
				<div class="rb-pop-up-content-main">
					<div class="rb-pop-up-head">
						<div class="rb-pop-up-heading">
							<?php
							if ( ! empty( $rb_pop_up_heading ) ) {
								echo esc_html( $rb_pop_up_heading );
							}
							?>
						</div>
					</div>
					<div class="rb-pop-up-product">
						<div class="rb-pop-up-product-image left">
							<?php if ( ! empty( $rb_pop_up_image_url ) ) { ?>
								<img src="<?php echo esc_url( $rb_pop_up_image_url ); ?>" alt="rb_pop_up_image">
							<?php } ?>
						</div>
						<div class="right">
							<?php if ( ! empty( $rb_pop_up_name ) ) { ?>
								<h4 class="rb-pop-up-product-name" ><?php echo esc_html( $rb_pop_up_name ); ?></h4>
							<?php } ?>
							<?php if ( ! empty( $rb_pop_up_desc ) ) { ?>
								<p class="rb-pop-up-product-desc">
									<?php echo esc_html( $rb_pop_up_desc ); ?>
								</p>
							<?php } ?>
							<?php
								$product_terms = wp_get_post_terms( $rb_pop_up_product_id, 'product_cat' );
								// Check if any categories were found.
							if ( ! empty( $product_terms ) ) {
								?>
								<div class="rb-pop-up-product-category">
									<?php
									esc_html_e( 'Categories: ', 'rbpopups' );
									// Loop through each category.
									foreach ( $product_terms as $term ) {
										$link = get_term_link( $term->term_id, 'product_cat' );	
																																					
										echo "<a href=".esc_url($link).">".esc_html( $term->name . ' ' )."</a> ";
									}
									?>
								</div>
								<?php
							}
							?>
						</div>
					</div>
					<div class="rb-pop-ups-variant-repeater">
						<?php
						if ( ! empty( $rb_pop_ups_variant_repeater ) ) {
							foreach ( $rb_pop_ups_variant_repeater as $variant ) {

								// get variant object if sku exist.
								$variant_price           = '';
								$variant_add_to_cart_url = '';
								if ( isset( $variant['variant_id'] ) && ! empty( $variant['variant_id'] ) ) {

									$variant_id   = $variant['variant_id'];
									$variant_data = wc_get_product( $variant_id );

									if ( ! empty( $variant_data ) ) {
										$variant_price = ! empty( $variant_data->price ) ? $variant_data->price : '';
										$variant_id_val = $variant_id;

										if ( ! empty( $rb_pop_up_product_id ) && ! empty( $variant_price ) ) {

											$product_permalink = get_permalink( $rb_pop_up_product_id );

											// Build the add to cart URL.
											$variant_add_to_cart_url = $product_permalink . '?add-to-cart=' . $rb_pop_up_product_id . '&variation_id=' . $variant_id;

										}
									}
								}
								?>
							<div class="rb-pop-up-variant">
								<div class="rb-pop-up-variant-info">
									<div>
										<?php if ( ! empty( $variant['icon_url'] ) ) { ?>
											<div class="rb-pop-up-variant-image">
												<img src="<?php echo esc_url( $variant['icon_url'] ); ?>" alt="icon_url">
											</div>
										<?php } ?>
										<?php if ( ! empty( $variant['name'] ) ) { ?>
											<div class="rb-pop-up-variant-name">
												<?php echo esc_html( $variant['name'] ); ?>
											</div>
										<?php } ?>
									</div>
										<?php if ( ! empty( $variant_price ) ) { ?>
											<div class="rb-pop-up-variant-price">
												<?php echo esc_html( 'Price: ' . $variant_price ); ?>
											</div>
										<?php } ?>

								</div>
								<div class="rb-pop-up-variant-buttons">
									<?php
									 if ( ! empty( $variant['btn_name'] ) ) {
										 $variant_btn_url = ! empty( $variant['btn_url'] ) ? $variant['btn_url'] : $product_permalink;
										?>
										<div class="variant-btn">
											<a href="<?php echo esc_url( $variant_btn_url ); ?>"><i class="fa-solid fa-gear"></i><?php echo esc_html( $variant['btn_name'] ); ?></a>
										</div>
										
										<?php if ( ! empty( $variant_id_val ) && ! empty( $rb_pop_up_product_id ) ) { ?>
										<div class="variant-add-to-cart-btn">
											<a href="javascript:;" class="rb-ajax-add-to-cart"
												data-product-id="<?php echo esc_attr( $rb_pop_up_product_id ); ?>"
												data-variation-id="<?php echo esc_attr( $variant_id_val ); ?>" data-quantity="1">
												<i class="fa fa-shopping-bag"></i>
												<?php esc_html_e( 'Add to Cart', 'rbpopups' ); ?>
											</a>
										</div>
										<?php } ?>
										
										<?php /* if ( ! empty( $variant_add_to_cart_url ) ) { ?>
											<div class="variant-add-to-cart-btn">
												<a href="<?php echo esc_url( $variant_add_to_cart_url ); ?>"><i class="fa fa-shopping-bag"> </i><?php esc_html_e( 'Add to Cart', 'rbpopups' ); ?></a>
											</div>
											<?php
										}  */ ?>
									<?php }
									?>
								</div>
							</div>
								<?php
							}
						}else{?>
							<div class="rb-pop-up-variant">
								<div class="rb-pop-up-variant-info">
									<?php if ( ! empty( $product ) ) { ?>
											<div class="rb-pop-up-variant-price">
												<?php echo $product->get_price_html(); ?>
											</div>
										<?php } ?>
								</div>
								<div class="rb-pop-up-variant-buttons">
									<div class="variant-add-to-cart-btn">
										<a href="<?php echo esc_url( $learn_more_url ); ?>"><i class="fa fa-shopping-bag"> </i><?php esc_html_e( 'Learn Morw', 'rbpopups' ); ?></a>
									</div>
									<!-- <div class="variant-add-to-cart-btn">
										<?php 
										//echo do_shortcode('[add_to_cart id="'.$rb_pop_up_product_id.'"]');
										?>
									</div> -->
									<div class="variant-add-to-cart-btn">
										<a href="javascript:;" class="rb-ajax-add-to-cart"
												data-product-id="<?php echo esc_attr( $rb_pop_up_product_id ); ?>"
												data-variation-id="" data-quantity="1">
												<i class="fa fa-shopping-bag"></i>
												<?php esc_html_e( 'Add to Cart', 'rbpopups' ); ?>
										</a>
									</div>
								</div>
							</div>
						<?php }
						?>
					</div>
				</div>
			<?php
			$pop_up_html = ob_get_clean();
			$response    = wp_json_encode(
				array(
					'status'      => true,
					'pop_up_html' => $pop_up_html,
				)
			);
			echo $response;
			wp_die();
		} else {

			$response = wp_json_encode( array( 'status' => false ) );
			echo $response;
			wp_die();
		}
	}

	/**
	 * Pop up html for pop up.
	 *
	 * @package Rushabh Pop Ups
	 * @since 1.0.0
	 */
	public function rb_pop_ups_html_for_footer() {
		?>
		<div class="rb-pop-up-modal">
				<div class="rb-pop-up-product-modal modal">
					<div class="modal-content">
						<span class="close-button" id="rb-pop-up-modal-close">×</span>
							<img id="rb-pop-up-btn-loader" class="rb-pop-up-btn-loader" src="<?php echo esc_url( RB_POP_UPS_PLUGIN_URL . 'includes/images/loading.gif' ); ?>" alt="ajax_loader">
						</div>
				</div>
			</div>	
		<?php
	}

	/**
	 * Adding Hooks
	 *
	 * @package Rushabh Pop Ups
	 * @since 1.0.0
	 */
	public function add_hooks() {

		// add pop ups buttons shortcode.
		add_action( 'init', array( $this, 'rb_pop_ups_shortcodes' ) );

		// ajax hook for pop up content.
		add_action( 'wp_ajax_rb_pop_ups_content', array( $this, 'rb_pop_ups_content' ) );
		add_action( 'wp_ajax_nopriv_rb_pop_ups_content', array( $this, 'rb_pop_ups_content' ) );
		add_action( 'wp_footer', array( $this, 'rb_pop_ups_html_for_footer' ) );
	}
}
