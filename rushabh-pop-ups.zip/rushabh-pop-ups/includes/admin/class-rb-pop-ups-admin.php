<?php
/**
 * Admin Main File
 *
 * @author  Wpweb
 * @package Rushabh Pop Ups
 * @version 1.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Admin Pages Class
 *
 * Handles generic Admin functionailties
 *
 * @package Rushabh Pop Ups
 * @since 1.0.0
 */
class Rb_Pop_Ups_Admin {

	/**
	 * Model variable
	 *
	 * @var   object
	 * @since 1.0.0
	 */
	public $model;

	/**
	 * Class Constructer
	 *
	 * @package Rushabh Pop Ups
	 * @since 1.0.0
	 */
	public function __construct() {

		global $rb_pop_ups_model;
		$this->model = $rb_pop_ups_model;
	}

	/**
	 * Add Pop Ups Fields in meta box
	 *
	 * Handles to add Pop Ups field
	 * with Pop Ups html in meta box
	 *
	 * @package Rushabh Pop Ups
	 * @since 1.0.0
	 */
	public function rb_pop_ups_content( $post ) {

		include RB_POP_UPS_ADMIN_DIR . '/forms/rb-pop-ups-meta.php';
	}

	/**
	 * Add Pop Ups Meta Box
	 *
	 * Handles to add Pop Ups meta box
	 * in post and page
	 *
	 * @package Rushabh Pop Ups
	 * @since 1.0.0
	 */
	public function rb_pop_ups_add_meta_box() {

		$screen = array( RB_POP_UPS_POST_TYPE );
		add_meta_box( 'rb_pop_ups_meta_box', esc_html__( 'Product Pop Up', 'rbpopups' ), array( $this, 'rb_pop_ups_content' ), $screen, 'advanced', 'high' );
	}

	/**
	 * Save Pop Ups Meta
	 *
	 * Handles to save Pop Ups meta
	 *
	 * @package Rushabh Pop Ups
	 * @since 1.0.0
	 */
	public function rb_pop_ups_save_meta( $post_id ) {

		$post_type = RB_POP_UPS_POST_TYPE;
		$prefix    = RB_POP_UPS_META_PREFIX;

		$post_type_object = get_post_type_object( $post_type );

		if ( isset( $_POST['rushabh-pop-ups'] ) && ! wp_verify_nonce( $_POST['rushabh-pop-ups'], 'rb_pop_ups_meta_box_nonce' ) ) {
			return false;
		}

		// Update Pop Ups name.
		if ( isset( $_POST[ $prefix . 'name' ] ) && ! empty( $_POST[ $prefix . 'name' ] ) ) {

			$name_field_value = $this->model->rb_pop_ups_escape_slashes_deep( $_POST[ $prefix . 'name' ] );
			update_post_meta( $post_id, $prefix . 'name', $name_field_value );

			// Create shortcode.
			$pop_up_name = sanitize_title( preg_replace( '/\s+/', '-', strtolower( $name_field_value ) ) );
			$shortcode   = $pop_up_name . '-popup-' . $post_id;
			update_post_meta( $post_id, $prefix . 'shortcode', $shortcode );

		} else {
			return $post_id;
		}

		if ( ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE )                // Check Autosave.
		|| ( ! isset( $_POST['post_ID'] ) || $post_id != $_POST['post_ID'] )        // Check Revision.
		|| ( ! current_user_can( $post_type_object->cap->edit_post, $post_id ) ) ) {
			return $post_id;
		}

		// Update Pop Ups product id.
		if ( isset( $_POST[ 'cat' ] ) ) {

			$cat_id = $this->model->rb_pop_ups_escape_slashes_deep( $_POST[ 'cat' ] );
			update_post_meta( $post_id, 'cat', $cat_id );
		}

		// Update Pop Ups product id.
		if ( isset( $_POST[ $prefix . 'product_id' ] ) ) {

			$product_id = $this->model->rb_pop_ups_escape_slashes_deep( $_POST[ $prefix . 'product_id' ] );
			update_post_meta( $post_id, $prefix . 'product_id', $product_id );
		}

		// Update Pop Ups shortcode button text.
		if ( isset( $_POST[ $prefix . 'shortcode_btn_txt' ] ) ) {

			$shortcode_btn_txt = $this->model->rb_pop_ups_escape_slashes_deep( $_POST[ $prefix . 'shortcode_btn_txt' ] );
			update_post_meta( $post_id, $prefix . 'shortcode_btn_txt', $shortcode_btn_txt );
		}

		// Update Pop Ups heading.
		if ( isset( $_POST[ $prefix . 'heading' ] ) ) {

			$heading = $this->model->rb_pop_ups_escape_slashes_deep( $_POST[ $prefix . 'heading' ] );
			update_post_meta( $post_id, $prefix . 'heading', $heading );
		}
		// Update Pop Ups Description.
		if ( isset( $_POST[ $prefix . 'desc' ] ) ) {

			$description = $this->model->rb_pop_ups_escape_slashes_deep( $_POST[ $prefix . 'desc' ] );
			update_post_meta( $post_id, $prefix . 'desc', $description );
		}

		// Update Pop Ups image url.
		if ( isset( $_POST[ $prefix . 'image_url' ] ) ) {

			$image_url = $this->model->rb_pop_ups_escape_slashes_deep( $_POST[ $prefix . 'image_url' ] );
			update_post_meta( $post_id, $prefix . 'image_url', $image_url );
		}

		// Update and Delete Pop Ups Variant Repeater.
		if ( isset( $_POST['_rb_pop_ups_variant_repeater'] ) ) {

			$rb_pop_ups_variant_repeater = $this->model->rb_pop_ups_escape_slashes_deep( $_POST['_rb_pop_ups_variant_repeater'] );
			$repeater_variant_data       = array();
			foreach ( $rb_pop_ups_variant_repeater as $key => $variant ) {

				// update variant name.
				if ( isset( $variant['name'] ) && ! empty( $variant['name'] ) ) {
					$repeater_variant_data[ $key ]['name'] = $variant['name'];
				}

				// update variant sku.
				if ( isset( $variant['variant_id'] ) && ! empty( $variant['variant_id'] ) ) {
					$repeater_variant_data[ $key ]['variant_id'] = $variant['variant_id'];
				}

				// update variant icon url.
				if ( isset( $variant['icon_url'] ) && ! empty( $variant['icon_url'] ) ) {

					$repeater_variant_data[ $key ]['icon_url'] = $variant['icon_url'];
				}

				// update variant description.
				if ( isset( $variant['desc'] ) && ! empty( $variant['desc'] ) ) {
					$repeater_variant_data[ $key ]['desc'] = $variant['desc'];
				}

				// update variant Button Name.
				if ( isset( $variant['btn_name'] ) && ! empty( $variant['btn_name'] ) ) {
					$repeater_variant_data[ $key ]['btn_name'] = $variant['btn_name'];
				}

				// update variant Button Name.
				if ( isset( $variant['btn_url'] ) && ! empty( $variant['btn_url'] ) ) {
					$repeater_variant_data[ $key ]['btn_url'] = $variant['btn_url'];
				}
			}
			update_post_meta( $post_id, $prefix . 'variant_repeater', $repeater_variant_data );
		} else {
			delete_post_meta( $post_id, $prefix . 'variant_repeater' );
		}
	}

	/**
	 * Register Post Type.
	 *
	 * @package Rushabh Pop Ups
	 * @since 1.0.0
	 */
	public function rb_pop_ups_register_post_types() {

		// Create Pop Ups Post Type For POP UPs.
		$labels = array(
			'name'               => __( 'Pop Ups', 'rbpopups' ),
			'singular_name'      => __( 'Pop Ups', 'rbpopups' ),
			'add_new'            => __( 'Add New', 'rbpopups' ),
			'add_new_item'       => __( 'Add New Pop Ups', 'rbpopups' ),
			'edit_item'          => __( 'Edit Pop Ups', 'rbpopups' ),
			'new_item'           => __( 'New Pop Ups', 'rbpopups' ),
			'all_items'          => __( 'Pop Ups', 'rbpopups' ),
			'view_item'          => __( 'View Pop Ups', 'rbpopups' ),
			'search_items'       => __( 'Search Pop Ups', 'rbpopups' ),
			'not_found'          => __( 'No Pop Ups found', 'rbpopups' ),
			'not_found_in_trash' => __( 'No Pop Ups found in Trash', 'rbpopups' ),
			'parent_item_colon'  => '',
			'menu_name'          => __( 'Pop Ups', 'rbpopups' ),
		);

		$args = array(
			'labels'             => $labels,
			'public'             => false,
			'publicly_queryable' => false,
			'show_ui'            => true,
			'show_in_menu'       => true,
			'query_var'          => true,
			'rewrite'            => array( 'slug' => RB_POP_UPS_POST_TYPE ),
			'capability_type'    => 'post',
			'map_meta_cap'       => true,
			'has_archive'        => true,
			'hierarchical'       => false,
			'supports'           => array( 'title', 'thumbnail' ),
		);

		register_post_type( RB_POP_UPS_POST_TYPE, $args );
	}

	/**
	 * Create ShortCode header for rushabh_pop_ups post type.
	 *
	 * @package Rushabh Pop Ups
	 * @since 1.0.0
	 */
	public function rb_pop_ups_post_shortcode_column_header( $column ) {

		// Get and remove the last element with key.
		$last_key   = key( array_slice( $column, -1, 1, true ) );
		$last_value = array_pop( $column );

		// Add Shortcode Field.
		$column['rb_pop_up_shortcode'] = esc_html__( 'Shortcode', 'rbpopups' );
		$column[ $last_key ]           = $last_value;
		return $column;
	}

	/**
	 * Add ShortCode Column data.
	 *
	 * @package Rushabh Pop Ups
	 * @since 1.0.0
	 */
	public function rb_pop_ups_post_shortcode_column_data( $column, $post_id ) {

		$prefix = RB_POP_UPS_META_PREFIX;

		if ( 'rb_pop_up_shortcode' === $column ) {

			$rb_pop_up_shortcode = get_post_meta( $post_id, $prefix . 'shortcode', true );

			if ( ! empty( $rb_pop_up_shortcode ) ) {

				// Add your custom column data here.
				echo esc_html( '[' . $rb_pop_up_shortcode . ']' );
			}
		}
	}

	/**
	 * Pop up variant options.
	 *
	 * @package Rushabh Pop Ups
	 * @since 1.0.0
	 */
	public function rb_pop_ups_variant_options() {

		if ( isset( $_POST['nonce'] ) && wp_verify_nonce( $_POST['nonce'], 'ajax-nonce' ) ) {

			$html       = '';
			$product_id = isset( $_POST['product_id'] ) && ! empty( $_POST['product_id'] ) ? sanitize_text_field( wp_unslash( $_POST['product_id'] ) ) : '';
			if ( ! empty( $product_id ) ) {
				$product = wc_get_product( $product_id );
				if ( $product && $product->is_type( 'variable' ) ) {
					$variations_ids = $product->get_children();
					foreach ( $variations_ids as $variation_id ) {
						$variation = wc_get_product( $variation_id );
						if ( $variation ) {

							$html .= '<option value="' . esc_attr( $variation->get_id() ) . '">' . esc_html( $variation->get_sku() ) . '</option>';
							?>
							<?php
						}
					}

					$respnse = wp_json_encode(
						array(
							'status' => true,
							'html'   => $html,
						)
					);

					echo $respnse;
					wp_die();
				}
			}

			$respnse = wp_json_encode(
				array(
					'status' => false,
				)
			);

			echo $respnse;
			wp_die();
		}
	}

	/**
	 * Pop up Category to product options.
	 *
	 * @package Rushabh Pop Ups
	 * @since 1.0.0
	 */
	public function rb_pop_ups_category_options() {

		// if ( isset( $_POST['nonce'] ) && wp_verify_nonce( $_POST['nonce'], 'ajax-nonce' ) ) {

			$products       = '';
			$catId = isset( $_POST['catId'] ) && ! empty( $_POST['catId'] ) ? sanitize_text_field( wp_unslash( $_POST['catId'] ) ) : '';
			if ( ! empty( $catId ) ) {
				$products = wc_get_products([
					'category' => get_term($catId, 'product_cat')->slug,
					'limit' => -1
				 ]);

				$getProduct=[];
				foreach ($products as $key => $product) {
					$getProduct[$key]['id'] =	$product->get_id();
					$getProduct[$key]['name'] =	$product->get_name();			
				}

			}
			
			$return = array(
				'products'  => $getProduct,
				'status'       => true
			);
			
			wp_send_json($return);

		//}
	}

	/**
	 * Adding Hooks
	 *
	 * @package Rushabh Pop Ups
	 * @since 1.0.0
	 */
	public function add_hooks() {

		// Register Post Type for pop ups.
		add_action( 'init', array( $this, 'rb_pop_ups_register_post_types' ) );

		// Add Shortcode Column to pop up post type.
		add_filter( 'manage_rushabh_pop_ups_posts_columns', array( $this, 'rb_pop_ups_post_shortcode_column_header' ) );

		// Add Content for Shortcode Column.
		add_action( 'manage_rushabh_pop_ups_posts_custom_column', array( $this, 'rb_pop_ups_post_shortcode_column_data' ), 10, 2 );

		// add action to save Pop Ups meta.
		add_action( 'save_post', array( $this, 'rb_pop_ups_save_meta' ) );

		// add action to add Pop Ups meta box in post and page.
		add_action( 'add_meta_boxes', array( $this, 'rb_pop_ups_add_meta_box' ) );

		// Ajax hook for variant options.
		add_action( 'wp_ajax_rb_pop_ups_variant_options', array( $this, 'rb_pop_ups_variant_options' ) );
		add_action( 'wp_ajax_rb_pop_ups_category_options', array( $this, 'rb_pop_ups_category_options' ) );
	}
}
