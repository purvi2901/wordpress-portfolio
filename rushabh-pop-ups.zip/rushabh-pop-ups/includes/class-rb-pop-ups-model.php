<?php
/**
 * Plugin Model
 *
 * @author  Wpweb
 * @package Rushabh Pop Ups
 * @version 1.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Plugin Model Class
 *
 * Handles generic functionailties
 *
 * @package Rushabh Pop Ups
 * @since 1.0.0
 */
class Rb_Pop_Ups_Model {

	/**
	 * Class Constructor.
	 *
	 * @package Rushabh Pop Ups
	 * @since 1.0.0
	 */
	public function __construct() {
	}

	/**
	 * Escape Tags & Slashes
	 *
	 * Handles escapping the slashes and tags
	 *
	 * @package Rushabh Pop Ups
	 * @since 1.0.0
	 */
	public function rb_pop_ups_escape_attr( $data ) {

		return esc_attr( stripslashes( $data ) );
	}

	/**
	 * Stripslashes
	 *
	 * It will strip slashes from the content
	 *
	 * @package Rushabh Pop Ups
	 * @since 1.0.0
	 */
	public function rb_pop_ups_escape_slashes_deep( $data = array(), $flag = false ) {

		if ( $flag != true ) {
			$data = $this->rb_pop_ups_nohtml_kses( $data );
		}
		$data = stripslashes_deep( $data );
		return $data;
	}

	/**
	 * Strip Html Tags
	 *
	 * It will sanitize text input (strip html tags, and escape characters)
	 *
	 * @package Rushabh Pop Ups
	 * @since 1.0.0
	 */
	public function rb_pop_ups_nohtml_kses( $data = array() ) {

		if ( is_array( $data ) ) {

			$data = array_map( array( $this, 'rb_pop_ups_nohtml_kses' ), $data );

		} elseif ( is_string( $data ) ) {

			$data = wp_filter_nohtml_kses( $data );
		}

		return $data;
	}
}
