<?php
/**
 * Plugin Script File
 *
 * @author  Wpweb
 * @package Rushabh Pop Ups
 * @version 1.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class for Register and enqueue and dequeue script.
 *
 * @package Rushabh Pop Ups
 * @version 1.0.0
 */
class Rb_Pop_Ups_Scripts {

	/**
	 * Class Constructer.
	 *
	 * @package Rushabh Pop Ups
	 * @version 1.0.0
	 */
	public function __construct() {
	}

	/**
	 * Add admin script.
	 *
	 * @package Rushabh Pop Ups
	 * @version 1.0.0
	 */
	public function rb_pop_ups_admin_scripts() {

		$localize = array(
			'ajax_url' => admin_url( 'admin-ajax.php' ),
			'nonce'    => wp_create_nonce( 'ajax-nonce' ),
		);

		// Register Script.
		wp_register_script( 'rb-pop-ups-admin-script', RB_POP_UPS_PLUGIN_URL . 'includes/js/rb-pop-ups-admin-script.js', array( 'jquery' ), RB_POP_UPS_PLUGIN_VERSION, true );

		// Register Style.
		wp_register_style( 'rb-pop-ups-admin-style', RB_POP_UPS_PLUGIN_URL . 'includes/css/rb-pop-ups-admin-style.css', array(), RB_POP_UPS_PLUGIN_VERSION );

		// enqueue script.
		wp_enqueue_script( 'rb-pop-ups-admin-script' );
		wp_localize_script( 'rb-pop-ups-admin-script', 'ajax_object', $localize );

		// enqueue Style.
		wp_enqueue_style( 'rb-pop-ups-admin-style' );
	}

	/**
	 * Add front script.
	 *
	 * @package Rushabh Pop Ups
	 * @version 1.0.0
	 */
	public function rb_pop_ups_front_scripts() {

		$localize = array(
			'ajax_url' => admin_url( 'admin-ajax.php' ),
			'nonce'    => wp_create_nonce( 'ajax-nonce' ),
		);

		// Register Script.
		wp_register_script( 'rb-pop-ups-front-script', RB_POP_UPS_PLUGIN_URL . 'includes/js/rb-pop-ups-front-script.js', array( 'jquery' ), RB_POP_UPS_PLUGIN_VERSION, true );

		// Register Style.
		wp_register_style( 'rb-pop-ups-front-style', RB_POP_UPS_PLUGIN_URL . 'includes/css/rb-pop-ups-front-style.css', array(), time() );

		// enqueue script.
		wp_enqueue_script( 'rb-pop-ups-front-script' );
		wp_localize_script( 'rb-pop-ups-front-script', 'ajax_object', $localize );

		// enqueue Style.
		wp_enqueue_style( 'rb-pop-ups-front-style' );
	}

	/**
	 * Add Various hooks.
	 *
	 * @package Rushabh Pop Ups
	 * @version 1.0.0
	 */
	public function add_hooks() {
		add_action( 'admin_enqueue_scripts', array( $this, 'rb_pop_ups_admin_scripts' ) );
		add_action( 'wp_enqueue_scripts', array( $this, 'rb_pop_ups_front_scripts' ) );
	}
}
