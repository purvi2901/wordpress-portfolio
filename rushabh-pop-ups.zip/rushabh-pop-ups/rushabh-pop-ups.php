<?php
/**
 * Plugin Name: Rushabh Pop Ups
 * Plugin URI: https://www.wpwebelite.com/
 * Description: Create New Pop ups Shortcode for products.
 * Version: 1.0.0
 * Author: WPWeb
 * Author URI: https://www.wpwebelite.com/
 * Text Domain: rbpopups
 * Domain Path: languages
 *
 * @package Rushabh Pop Ups
 * @category Core
 * @author WPWeb
 */

/**
 * Basic plugin definitions
 *
 * @package Rushabh Pop Ups
 * @since 1.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

global $wpdb;

if ( ! defined( 'RB_POP_UPS_PLUGIN_URL' ) ) {
	define( 'RB_POP_UPS_PLUGIN_URL', plugin_dir_url( __FILE__ ) ); // plugin url.
}
if ( ! defined( 'RB_POP_UPS_DIR' ) ) {
	define( 'RB_POP_UPS_DIR', __DIR__ ); // plugin dir.
}
if ( ! defined( 'RB_POP_UPS_ADMIN_DIR' ) ) {
	define( 'RB_POP_UPS_ADMIN_DIR', RB_POP_UPS_DIR . '/includes/admin' ); // plugin admin dir.
}
if ( ! defined( 'RB_POP_UPS_BASENAME' ) ) {
	define( 'RB_POP_UPS_BASENAME', 'rushabh-pop-ups' );
}
if ( ! defined( 'RB_POP_UPS_POST_TYPE' ) ) {
	define( 'RB_POP_UPS_POST_TYPE', 'rushabh_pop_ups' );
}
if ( ! defined( 'RB_POP_UPS_META_PREFIX' ) ) {
	define( 'RB_POP_UPS_META_PREFIX', '_rb_pop_ups_' );
}
if ( ! defined( 'RB_POP_UPS_PLUGIN_BASENAME' ) ) {
	define( 'RB_POP_UPS_PLUGIN_BASENAME', basename( RB_POP_UPS_DIR ) ); // Plugin base name.
}
if ( ! defined( 'RB_POP_UPS_PLUGIN_VERSION' ) ) {
	define( 'RB_POP_UPS_PLUGIN_VERSION', '1.0.0' ); // plugin version.
}

/**
 * Load Text Domain
 *
 * This gets the plugin ready for translation.
 *
 * @package Rushabh Pop Ups
 * @since 1.0.0
 */
function rb_pop_ups_load_textdomain() {

	// Set filter for plugin's languages director.
	$rb_pop_ups_lang_dir = dirname( plugin_basename( __FILE__ ) ) . '/languages/';
	$rb_pop_ups_lang_dir = apply_filters( 'rb_pop_ups_languages_directory', $rb_pop_ups_lang_dir );

	// Traditional WordPress plugin locale filter.
	$locale = apply_filters( 'plugin_locale', get_locale(), 'rbpopups' );
	$mofile = sprintf( '%1$s-%2$s.mo', 'rbpopups', $locale );

	// Setup paths to current locale file.
	$mofile_local  = $rb_pop_ups_lang_dir . $mofile;
	$mofile_global = WP_LANG_DIR . '/' . RB_POP_UPS_BASENAME . '/' . $mofile;

	if ( file_exists( $mofile_global ) ) { // Look in global /wp-content/languages/wp-meta-box-custom folder.
		load_textdomain( 'rbpopups', $mofile_global );
	} elseif ( file_exists( $mofile_local ) ) { // Look in local /wp-content/plugins/wp-meta-box-custom/languages/ folder.
		load_textdomain( 'rbpopups', $mofile_local );
	} else { // Load the default language files.
		load_plugin_textdomain( 'rbpopups', false, $rb_pop_ups_lang_dir );
	}
}

/**
 * Activation hook
 *
 * Register plugin activation hook.
 *
 * @package Rushabh Pop Ups
 * @since 1.0.0
 */
register_activation_hook( __FILE__, 'rb_pop_ups_install' );

/**
 * Deactivation hook
 *
 * Register plugin deactivation hook.
 *
 * @package Rushabh Pop Ups
 * @since 1.0.0
 */
register_deactivation_hook( __FILE__, 'rb_pop_ups_uninstall' );

/**
 * Plugin Setup Activation hook call back
 *
 * Initial setup of the plugin setting default options
 * and database tables creations.
 *
 * @package Rushabh Pop Ups
 * @since 1.0.0
 */
function rb_pop_ups_install() {

	global $wpdb;
}

/**
 * Plugin Setup (On Deactivation)
 *
 * Does the drop tables in the database and
 * delete  plugin options.
 *
 * @package Rushabh Pop Ups
 * @since 1.0.0
 */
function rb_pop_ups_uninstall() {

	global $wpdb;
}

/**
 * Load Plugin
 *
 * Handles to load plugin after
 * dependent plugin is loaded
 * successfully
 *
 * @package Rushabh Pop Ups
 * @since 1.0.0
 */
function rb_pop_ups_plugin_loaded() {

	// load first plugin text domain.
	rb_pop_ups_load_textdomain();
}

// add action to load plugin.
add_action( 'plugins_loaded', 'rb_pop_ups_plugin_loaded' );

/**
 * Initialize all global variables
 *
 * @package Rushabh Pop Ups
 * @since 1.0.0
 */
global $rb_pop_ups_model, $rb_pop_ups_admin, $rb_pop_ups_error;

/**
 * Includes
 *
 * Includes all the needed files for our plugin
 *
 * @package Rushabh Pop Ups
 * @since 1.0.0
 */

// includes model class file.
require_once RB_POP_UPS_DIR . '/includes/class-rb-pop-ups-model.php';
$rb_pop_ups_model = new Rb_Pop_Ups_Model();

// includes Script class file.
require_once RB_POP_UPS_DIR . '/includes/class-rb-pop-ups-scripts.php';
$rb_pop_ups_script = new Rb_Pop_Ups_Scripts();
$rb_pop_ups_script->add_hooks();

require_once RB_POP_UPS_ADMIN_DIR . '/class-rb-pop-ups-admin.php';
$rb_pop_ups_admin = new Rb_Pop_Ups_Admin();
$rb_pop_ups_admin->add_hooks();


require_once RB_POP_UPS_ADMIN_DIR . '/class-rb-pop-ups-shortcode.php';
$rb_pop_ups_shortcode = new Rb_Pop_Ups_Shortcode();
$rb_pop_ups_shortcode->add_hooks();
